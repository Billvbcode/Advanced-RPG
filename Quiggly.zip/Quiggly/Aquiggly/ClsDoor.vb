﻿Public Class ClsDoor
    Private iDooriX As Integer
    Private iDooriY As Integer
    Private iDooriToY As Integer
    Private iDooriToX As Integer
    Private strName As String
    Private strMytype As String
    Public Property Mytype() As String      'Foe Description
        Get
            Return strMytype
        End Get
        Set(ByVal Value As String)
            strMytype = Value
        End Set
    End Property
    Public Property Name() As String      'Foe Description
        Get
            Return strName
        End Get
        Set(ByVal Value As String)
            strName = Value
        End Set
    End Property
    Public Property DooriToX() As Integer       ' Melt time
        Get
            Return iDooriToX
        End Get
        Set(ByVal Value As Integer)
            iDooriToX = Value
        End Set
    End Property
    Public Property DooriToY() As Integer       ' Melt time
        Get
            Return iDooriToY
        End Get
        Set(ByVal Value As Integer)
            iDooriToY = Value
        End Set
    End Property
    Public Property DooriY() As Integer       ' Melt time
        Get
            Return iDooriY
        End Get
        Set(ByVal Value As Integer)
            iDooriY = Value
        End Set
    End Property
    Public Property DooriX() As Integer       ' Melt time
        Get
            Return iDooriX
        End Get
        Set(ByVal Value As Integer)
            iDooriX = Value
        End Set
    End Property
End Class
