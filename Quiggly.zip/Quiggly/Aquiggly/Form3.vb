﻿Public Class Form3

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        i = 1
        For Each poko In nPoko
            Select Case i
                Case 1
                    Label1.Text = poko.Name & " Val=" & poko.Value & " Max=" & poko.Max & " Win=" & poko.Wins & " Lvl=" & poko.Level & " hl=" & poko.Hit1 & " h1m=" & poko.Hit1M
                Case 2
                    Label2.Text = poko.Name & " Val=" & poko.Value & " Max=" & poko.Max & " Win=" & poko.Wins & " Lvl=" & poko.Level
                Case 3
                    Label3.Text = poko.Name & " Val=" & poko.Value & " Max=" & poko.Max & " Win=" & poko.Wins & " Lvl=" & poko.Level
                Case 4
                    Label4.Text = poko.Name & " Val=" & poko.Value & " Max=" & poko.Max & " Win=" & poko.Wins & " Lvl=" & poko.Level
                Case 5
                    Label5.Text = poko.Name & " Val=" & poko.Value & " Max=" & poko.Max & " Win=" & poko.Wins & " Lvl=" & poko.Level
            End Select
            i = i + 1
        Next
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
        Me.Dispose()
    End Sub
End Class