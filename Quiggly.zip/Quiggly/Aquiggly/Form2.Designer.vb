﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCopy
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtY = New System.Windows.Forms.TextBox()
        Me.txtX = New System.Windows.Forms.TextBox()
        Me.XSB = New System.Windows.Forms.HScrollBar()
        Me.YSB = New System.Windows.Forms.VScrollBar()
        Me.TxtMap = New System.Windows.Forms.TextBox()
        Me.TxtMapNew = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(829, 125)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(117, 147)
        Me.ListBox1.TabIndex = 27
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(843, 93)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 13)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Map List"
        '
        'TxtY
        '
        Me.TxtY.Location = New System.Drawing.Point(840, 12)
        Me.TxtY.Name = "TxtY"
        Me.TxtY.Size = New System.Drawing.Size(58, 20)
        Me.TxtY.TabIndex = 42
        '
        'txtX
        '
        Me.txtX.Location = New System.Drawing.Point(840, 50)
        Me.txtX.Name = "txtX"
        Me.txtX.Size = New System.Drawing.Size(58, 20)
        Me.txtX.TabIndex = 41
        '
        'XSB
        '
        Me.XSB.Location = New System.Drawing.Point(9, 445)
        Me.XSB.Maximum = 90
        Me.XSB.Name = "XSB"
        Me.XSB.Size = New System.Drawing.Size(749, 25)
        Me.XSB.TabIndex = 43
        '
        'YSB
        '
        Me.YSB.Location = New System.Drawing.Point(794, 50)
        Me.YSB.Maximum = 90
        Me.YSB.Name = "YSB"
        Me.YSB.Size = New System.Drawing.Size(32, 361)
        Me.YSB.TabIndex = 44
        '
        'TxtMap
        '
        Me.TxtMap.Location = New System.Drawing.Point(247, 2)
        Me.TxtMap.Name = "TxtMap"
        Me.TxtMap.Size = New System.Drawing.Size(71, 20)
        Me.TxtMap.TabIndex = 45
        '
        'TxtMapNew
        '
        Me.TxtMapNew.Location = New System.Drawing.Point(888, 322)
        Me.TxtMapNew.Name = "TxtMapNew"
        Me.TxtMapNew.Size = New System.Drawing.Size(93, 20)
        Me.TxtMapNew.TabIndex = 46
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(210, 2)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 47
        Me.Label2.Text = "Map"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(813, 325)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 13)
        Me.Label3.TabIndex = 48
        Me.Label3.Text = "New Map"
        '
        'BtnSave
        '
        Me.BtnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSave.Location = New System.Drawing.Point(877, 378)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(87, 33)
        Me.BtnSave.TabIndex = 59
        Me.BtnSave.Text = "Save"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'FrmCopy
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(993, 502)
        Me.Controls.Add(Me.BtnSave)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TxtMapNew)
        Me.Controls.Add(Me.TxtMap)
        Me.Controls.Add(Me.YSB)
        Me.Controls.Add(Me.XSB)
        Me.Controls.Add(Me.TxtY)
        Me.Controls.Add(Me.txtX)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ListBox1)
        Me.Name = "FrmCopy"
        Me.Text = "Copy Map"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtY As System.Windows.Forms.TextBox
    Friend WithEvents txtX As System.Windows.Forms.TextBox
    Friend WithEvents XSB As System.Windows.Forms.HScrollBar
    Friend WithEvents YSB As System.Windows.Forms.VScrollBar
    Friend WithEvents TxtMap As System.Windows.Forms.TextBox
    Friend WithEvents TxtMapNew As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents BtnSave As System.Windows.Forms.Button
End Class
