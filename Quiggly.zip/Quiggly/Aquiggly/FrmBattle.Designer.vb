﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmBattle
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.lblPP3 = New System.Windows.Forms.Label()
        Me.optAttack3 = New System.Windows.Forms.RadioButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblPP2 = New System.Windows.Forms.Label()
        Me.optAttack2 = New System.Windows.Forms.RadioButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblPP1 = New System.Windows.Forms.Label()
        Me.optAttack1 = New System.Windows.Forms.RadioButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblPP0 = New System.Windows.Forms.Label()
        Me.optAttack0 = New System.Windows.Forms.RadioButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmdAttack = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.urName = New System.Windows.Forms.Label()
        Me.enName = New System.Windows.Forms.Label()
        Me.LblEnType = New System.Windows.Forms.Label()
        Me.CmdCatch = New System.Windows.Forms.Button()
        Me.EnDisplay = New System.Windows.Forms.Label()
        Me.UrDisplay = New System.Windows.Forms.Label()
        Me.enTmr = New System.Windows.Forms.Timer(Me.components)
        Me.urTmr = New System.Windows.Forms.Timer(Me.components)
        Me.CmdRun = New System.Windows.Forms.Button()
        Me.tmrCatch = New System.Windows.Forms.Timer(Me.components)
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.imgPokeball2 = New System.Windows.Forms.PictureBox()
        Me.imgPokeball = New System.Windows.Forms.PictureBox()
        Me.enActivePkmn = New System.Windows.Forms.PictureBox()
        Me.urActivePkmn = New System.Windows.Forms.PictureBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.enLyfOver = New System.Windows.Forms.Label()
        Me.enStat = New System.Windows.Forms.Label()
        Me.enLyf = New System.Windows.Forms.ProgressBar()
        Me.enLvl = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblUrType = New System.Windows.Forms.Label()
        Me.urLyfOver = New System.Windows.Forms.Label()
        Me.urStat = New System.Windows.Forms.Label()
        Me.urLyf = New System.Windows.Forms.ProgressBar()
        Me.urLvl = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.imgPokeball2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgPokeball, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.enActivePkmn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.urActivePkmn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(17, 289)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(699, 248)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Panel4)
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.Controls.Add(Me.Panel2)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.cmdAttack)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(691, 222)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Fight"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel4.Controls.Add(Me.lblPP3)
        Me.Panel4.Controls.Add(Me.optAttack3)
        Me.Panel4.Location = New System.Drawing.Point(345, 137)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(186, 49)
        Me.Panel4.TabIndex = 16
        '
        'lblPP3
        '
        Me.lblPP3.AutoSize = True
        Me.lblPP3.BackColor = System.Drawing.Color.White
        Me.lblPP3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPP3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblPP3.Location = New System.Drawing.Point(122, 16)
        Me.lblPP3.Name = "lblPP3"
        Me.lblPP3.Size = New System.Drawing.Size(55, 16)
        Me.lblPP3.TabIndex = 14
        Me.lblPP3.Text = "Label4"
        '
        'optAttack3
        '
        Me.optAttack3.AutoSize = True
        Me.optAttack3.Location = New System.Drawing.Point(9, 16)
        Me.optAttack3.Name = "optAttack3"
        Me.optAttack3.Size = New System.Drawing.Size(90, 17)
        Me.optAttack3.TabIndex = 13
        Me.optAttack3.Text = "RadioButton4"
        Me.optAttack3.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel3.Controls.Add(Me.lblPP2)
        Me.Panel3.Controls.Add(Me.optAttack2)
        Me.Panel3.Location = New System.Drawing.Point(345, 59)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(186, 49)
        Me.Panel3.TabIndex = 15
        '
        'lblPP2
        '
        Me.lblPP2.AutoSize = True
        Me.lblPP2.BackColor = System.Drawing.Color.White
        Me.lblPP2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPP2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblPP2.Location = New System.Drawing.Point(122, 17)
        Me.lblPP2.Name = "lblPP2"
        Me.lblPP2.Size = New System.Drawing.Size(55, 16)
        Me.lblPP2.TabIndex = 9
        Me.lblPP2.Text = "Label1"
        '
        'optAttack2
        '
        Me.optAttack2.AutoSize = True
        Me.optAttack2.Location = New System.Drawing.Point(9, 16)
        Me.optAttack2.Name = "optAttack2"
        Me.optAttack2.Size = New System.Drawing.Size(90, 17)
        Me.optAttack2.TabIndex = 8
        Me.optAttack2.Text = "RadioButton1"
        Me.optAttack2.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel2.Controls.Add(Me.lblPP1)
        Me.Panel2.Controls.Add(Me.optAttack1)
        Me.Panel2.Location = New System.Drawing.Point(21, 137)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(186, 49)
        Me.Panel2.TabIndex = 14
        '
        'lblPP1
        '
        Me.lblPP1.AutoSize = True
        Me.lblPP1.BackColor = System.Drawing.Color.White
        Me.lblPP1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPP1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblPP1.Location = New System.Drawing.Point(119, 16)
        Me.lblPP1.Name = "lblPP1"
        Me.lblPP1.Size = New System.Drawing.Size(55, 16)
        Me.lblPP1.TabIndex = 13
        Me.lblPP1.Text = "Label3"
        '
        'optAttack1
        '
        Me.optAttack1.AutoSize = True
        Me.optAttack1.Location = New System.Drawing.Point(13, 16)
        Me.optAttack1.Name = "optAttack1"
        Me.optAttack1.Size = New System.Drawing.Size(90, 17)
        Me.optAttack1.TabIndex = 12
        Me.optAttack1.Text = "RadioButton3"
        Me.optAttack1.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel1.Controls.Add(Me.lblPP0)
        Me.Panel1.Controls.Add(Me.optAttack0)
        Me.Panel1.Location = New System.Drawing.Point(16, 66)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(186, 49)
        Me.Panel1.TabIndex = 13
        '
        'lblPP0
        '
        Me.lblPP0.AutoSize = True
        Me.lblPP0.BackColor = System.Drawing.Color.White
        Me.lblPP0.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPP0.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblPP0.Location = New System.Drawing.Point(119, 17)
        Me.lblPP0.Name = "lblPP0"
        Me.lblPP0.Size = New System.Drawing.Size(55, 16)
        Me.lblPP0.TabIndex = 12
        Me.lblPP0.Text = "Label2"
        '
        'optAttack0
        '
        Me.optAttack0.AutoSize = True
        Me.optAttack0.Location = New System.Drawing.Point(13, 16)
        Me.optAttack0.Name = "optAttack0"
        Me.optAttack0.Size = New System.Drawing.Size(90, 17)
        Me.optAttack0.TabIndex = 11
        Me.optAttack0.Text = "RadioButton2"
        Me.optAttack0.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(95, 36)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(39, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Label7"
        '
        'cmdAttack
        '
        Me.cmdAttack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAttack.Location = New System.Drawing.Point(600, 116)
        Me.cmdAttack.Name = "cmdAttack"
        Me.cmdAttack.Size = New System.Drawing.Size(70, 35)
        Me.cmdAttack.TabIndex = 11
        Me.cmdAttack.Text = "Attack"
        Me.cmdAttack.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(691, 222)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Pokeman"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'urName
        '
        Me.urName.AutoSize = True
        Me.urName.BackColor = System.Drawing.Color.PaleGreen
        Me.urName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.urName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.urName.Location = New System.Drawing.Point(69, 9)
        Me.urName.Name = "urName"
        Me.urName.Size = New System.Drawing.Size(63, 20)
        Me.urName.TabIndex = 8
        Me.urName.Text = "Label1"
        '
        'enName
        '
        Me.enName.AutoSize = True
        Me.enName.BackColor = System.Drawing.Color.LightSalmon
        Me.enName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.enName.Location = New System.Drawing.Point(405, 9)
        Me.enName.Name = "enName"
        Me.enName.Size = New System.Drawing.Size(63, 20)
        Me.enName.TabIndex = 9
        Me.enName.Text = "Label1"
        '
        'LblEnType
        '
        Me.LblEnType.AutoSize = True
        Me.LblEnType.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.LblEnType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblEnType.ForeColor = System.Drawing.Color.Green
        Me.LblEnType.Location = New System.Drawing.Point(93, 21)
        Me.LblEnType.Name = "LblEnType"
        Me.LblEnType.Size = New System.Drawing.Size(0, 13)
        Me.LblEnType.TabIndex = 18
        '
        'CmdCatch
        '
        Me.CmdCatch.Location = New System.Drawing.Point(294, 543)
        Me.CmdCatch.Name = "CmdCatch"
        Me.CmdCatch.Size = New System.Drawing.Size(109, 60)
        Me.CmdCatch.TabIndex = 22
        Me.CmdCatch.Text = "Catch"
        Me.CmdCatch.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.CmdCatch.UseVisualStyleBackColor = True
        '
        'EnDisplay
        '
        Me.EnDisplay.BackColor = System.Drawing.Color.White
        Me.EnDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EnDisplay.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.EnDisplay.Location = New System.Drawing.Point(443, 567)
        Me.EnDisplay.Name = "EnDisplay"
        Me.EnDisplay.Size = New System.Drawing.Size(132, 76)
        Me.EnDisplay.TabIndex = 11
        '
        'UrDisplay
        '
        Me.UrDisplay.BackColor = System.Drawing.SystemColors.Window
        Me.UrDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UrDisplay.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.UrDisplay.Location = New System.Drawing.Point(53, 567)
        Me.UrDisplay.Name = "UrDisplay"
        Me.UrDisplay.Size = New System.Drawing.Size(164, 76)
        Me.UrDisplay.TabIndex = 23
        '
        'enTmr
        '
        Me.enTmr.Interval = 50
        '
        'urTmr
        '
        Me.urTmr.Interval = 50
        '
        'CmdRun
        '
        Me.CmdRun.Location = New System.Drawing.Point(171, 543)
        Me.CmdRun.Name = "CmdRun"
        Me.CmdRun.Size = New System.Drawing.Size(109, 60)
        Me.CmdRun.TabIndex = 24
        Me.CmdRun.Text = "Run"
        Me.CmdRun.UseVisualStyleBackColor = True
        '
        'tmrCatch
        '
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(629, 556)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "Label3"
        Me.Label3.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(629, 590)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Label4"
        Me.Label4.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 543)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(39, 13)
        Me.Label5.TabIndex = 29
        Me.Label5.Text = "Label5"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Khaki
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(234, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 16)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Label1"
        '
        'imgPokeball2
        '
        Me.imgPokeball2.Location = New System.Drawing.Point(314, 556)
        Me.imgPokeball2.Name = "imgPokeball2"
        Me.imgPokeball2.Size = New System.Drawing.Size(31, 28)
        Me.imgPokeball2.TabIndex = 26
        Me.imgPokeball2.TabStop = False
        '
        'imgPokeball
        '
        Me.imgPokeball.Location = New System.Drawing.Point(559, 556)
        Me.imgPokeball.Name = "imgPokeball"
        Me.imgPokeball.Size = New System.Drawing.Size(31, 28)
        Me.imgPokeball.TabIndex = 25
        Me.imgPokeball.TabStop = False
        Me.imgPokeball.Visible = False
        '
        'enActivePkmn
        '
        Me.enActivePkmn.Location = New System.Drawing.Point(399, 47)
        Me.enActivePkmn.Name = "enActivePkmn"
        Me.enActivePkmn.Size = New System.Drawing.Size(113, 80)
        Me.enActivePkmn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.enActivePkmn.TabIndex = 19
        Me.enActivePkmn.TabStop = False
        '
        'urActivePkmn
        '
        Me.urActivePkmn.Location = New System.Drawing.Point(63, 47)
        Me.urActivePkmn.Name = "urActivePkmn"
        Me.urActivePkmn.Size = New System.Drawing.Size(113, 80)
        Me.urActivePkmn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.urActivePkmn.TabIndex = 14
        Me.urActivePkmn.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel5.Controls.Add(Me.Label2)
        Me.Panel5.Controls.Add(Me.enLyfOver)
        Me.Panel5.Controls.Add(Me.enStat)
        Me.Panel5.Controls.Add(Me.enLyf)
        Me.Panel5.Controls.Add(Me.enLvl)
        Me.Panel5.Controls.Add(Me.LblEnType)
        Me.Panel5.Location = New System.Drawing.Point(375, 175)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(262, 79)
        Me.Panel5.TabIndex = 31
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(8, 46)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(24, 13)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "HP"
        '
        'enLyfOver
        '
        Me.enLyfOver.AutoSize = True
        Me.enLyfOver.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.enLyfOver.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enLyfOver.ForeColor = System.Drawing.Color.Green
        Me.enLyfOver.Location = New System.Drawing.Point(210, 43)
        Me.enLyfOver.Name = "enLyfOver"
        Me.enLyfOver.Size = New System.Drawing.Size(45, 13)
        Me.enLyfOver.TabIndex = 30
        Me.enLyfOver.Text = "Label1"
        '
        'enStat
        '
        Me.enStat.AutoSize = True
        Me.enStat.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.enStat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enStat.ForeColor = System.Drawing.Color.Green
        Me.enStat.Location = New System.Drawing.Point(185, 7)
        Me.enStat.Name = "enStat"
        Me.enStat.Size = New System.Drawing.Size(40, 16)
        Me.enStat.TabIndex = 29
        Me.enStat.Text = "Nrml"
        '
        'enLyf
        '
        Me.enLyf.Location = New System.Drawing.Point(38, 44)
        Me.enLyf.Name = "enLyf"
        Me.enLyf.Size = New System.Drawing.Size(166, 15)
        Me.enLyf.TabIndex = 28
        '
        'enLvl
        '
        Me.enLvl.AutoSize = True
        Me.enLvl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enLvl.Location = New System.Drawing.Point(28, 11)
        Me.enLvl.Name = "enLvl"
        Me.enLvl.Size = New System.Drawing.Size(55, 16)
        Me.enLvl.TabIndex = 27
        Me.enLvl.Text = "Label1"
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel6.Controls.Add(Me.Label1)
        Me.Panel6.Controls.Add(Me.lblUrType)
        Me.Panel6.Controls.Add(Me.urLyfOver)
        Me.Panel6.Controls.Add(Me.urStat)
        Me.Panel6.Controls.Add(Me.urLyf)
        Me.Panel6.Controls.Add(Me.urLvl)
        Me.Panel6.Location = New System.Drawing.Point(37, 167)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(287, 87)
        Me.Panel6.TabIndex = 32
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(15, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 13)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "HP"
        '
        'lblUrType
        '
        Me.lblUrType.AutoSize = True
        Me.lblUrType.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblUrType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUrType.ForeColor = System.Drawing.Color.Green
        Me.lblUrType.Location = New System.Drawing.Point(107, 33)
        Me.lblUrType.Name = "lblUrType"
        Me.lblUrType.Size = New System.Drawing.Size(45, 13)
        Me.lblUrType.TabIndex = 31
        Me.lblUrType.Text = "Label1"
        '
        'urLyfOver
        '
        Me.urLyfOver.AutoSize = True
        Me.urLyfOver.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.urLyfOver.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.urLyfOver.ForeColor = System.Drawing.Color.Green
        Me.urLyfOver.Location = New System.Drawing.Point(226, 53)
        Me.urLyfOver.Name = "urLyfOver"
        Me.urLyfOver.Size = New System.Drawing.Size(45, 13)
        Me.urLyfOver.TabIndex = 30
        Me.urLyfOver.Text = "Label1"
        '
        'urStat
        '
        Me.urStat.AutoSize = True
        Me.urStat.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.urStat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.urStat.ForeColor = System.Drawing.Color.Green
        Me.urStat.Location = New System.Drawing.Point(194, 20)
        Me.urStat.Name = "urStat"
        Me.urStat.Size = New System.Drawing.Size(55, 16)
        Me.urStat.TabIndex = 29
        Me.urStat.Text = "Label1"
        '
        'urLyf
        '
        Me.urLyf.Location = New System.Drawing.Point(54, 51)
        Me.urLyf.Name = "urLyf"
        Me.urLyf.Size = New System.Drawing.Size(166, 15)
        Me.urLyf.TabIndex = 28
        '
        'urLvl
        '
        Me.urLvl.AutoSize = True
        Me.urLvl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.urLvl.Location = New System.Drawing.Point(30, 24)
        Me.urLvl.Name = "urLvl"
        Me.urLvl.Size = New System.Drawing.Size(55, 16)
        Me.urLvl.TabIndex = 27
        Me.urLvl.Text = "Label1"
        '
        'FrmBattle
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(737, 652)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.imgPokeball2)
        Me.Controls.Add(Me.imgPokeball)
        Me.Controls.Add(Me.CmdRun)
        Me.Controls.Add(Me.UrDisplay)
        Me.Controls.Add(Me.EnDisplay)
        Me.Controls.Add(Me.CmdCatch)
        Me.Controls.Add(Me.enActivePkmn)
        Me.Controls.Add(Me.urActivePkmn)
        Me.Controls.Add(Me.enName)
        Me.Controls.Add(Me.urName)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "FrmBattle"
        Me.Text = "FrmBattle"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.imgPokeball2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgPokeball, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.enActivePkmn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.urActivePkmn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents urName As System.Windows.Forms.Label
    Friend WithEvents enName As System.Windows.Forms.Label
    Friend WithEvents urActivePkmn As System.Windows.Forms.PictureBox
    Friend WithEvents LblEnType As System.Windows.Forms.Label
    Friend WithEvents enActivePkmn As System.Windows.Forms.PictureBox
    Friend WithEvents CmdCatch As System.Windows.Forms.Button
    Friend WithEvents EnDisplay As System.Windows.Forms.Label
    Friend WithEvents UrDisplay As System.Windows.Forms.Label
    Friend WithEvents cmdAttack As System.Windows.Forms.Button
    Friend WithEvents enTmr As System.Windows.Forms.Timer
    Friend WithEvents urTmr As System.Windows.Forms.Timer
    Friend WithEvents CmdRun As System.Windows.Forms.Button
    Friend WithEvents tmrCatch As System.Windows.Forms.Timer
    Friend WithEvents imgPokeball As System.Windows.Forms.PictureBox
    Friend WithEvents imgPokeball2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblPP0 As System.Windows.Forms.Label
    Friend WithEvents optAttack0 As System.Windows.Forms.RadioButton
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblPP1 As System.Windows.Forms.Label
    Friend WithEvents optAttack1 As System.Windows.Forms.RadioButton
    Friend WithEvents lblPP2 As System.Windows.Forms.Label
    Friend WithEvents optAttack2 As System.Windows.Forms.RadioButton
    Friend WithEvents lblPP3 As System.Windows.Forms.Label
    Friend WithEvents optAttack3 As System.Windows.Forms.RadioButton
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents enLyfOver As System.Windows.Forms.Label
    Friend WithEvents enStat As System.Windows.Forms.Label
    Friend WithEvents enLyf As System.Windows.Forms.ProgressBar
    Friend WithEvents enLvl As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblUrType As System.Windows.Forms.Label
    Friend WithEvents urLyfOver As System.Windows.Forms.Label
    Friend WithEvents urStat As System.Windows.Forms.Label
    Friend WithEvents urLyf As System.Windows.Forms.ProgressBar
    Friend WithEvents urLvl As System.Windows.Forms.Label
End Class
