﻿Public Class FrmFight
    Private Sub MyRedo()
        ' Read all the levels
        '
        Dim value As String = My.Application.Info.DirectoryPath & "\images\PokemonPics\"
        Dim di As New IO.DirectoryInfo(value)
        Dim diar1 As IO.FileInfo() = di.GetFiles("*.*")
        Dim dra As IO.FileInfo
        Dim sMsg As String
        Dim l As Integer
        sMsg = value
        'list the names of all files in the specified directory
       
        'My.Application.Info.DirectoryPath
        'File1.Path = App.Path & "\images\PokemonPics\"
        'File1.Pattern = "*.txt"
        'File1.Path = App.Path & "\images\PokemonPics\"
        'File1.Pattern = "*.gif"
        FlexPoko.Clear()
        FlexPoko.Rows = 1
        FlexPoko.FormatString = "Name                   " & vbTab & "Level"
        FlexSelect.Clear()
        FlexSelect.Rows = 1
        FlexSelect.FormatString = "Name                   " & vbTab & "Level"
        TxtMyPoko.Text = ""
        TxtMyLevel.Text = ""
        For Each dra In diar1
            l = Val(TxtLevel.Text) + Rnd() * 8
            FlexPoko.AddItem(Mid(dra.ToString, 1, Len(dra.ToString) - 4) & vbTab & l)
        Next
        'For i = 0 To File1.ListCount - 1
        '    l = TxtLevel.Text + Rnd() * 8
        '    FlexPoko.AddItem(Mid(File1.List(i), 1, Len(File1.List(i)) - 4) & vbTab & l)
    End Sub
    Private Sub FrmFight_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MyRedo()
    End Sub

    Private Sub BtnRedo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRedo.Click
        MyRedo()
    End Sub

    Private Sub BntClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BntClear.Click
        TxtMyPoko.Text = ""
        TxtMyLevel.Text = ""
        FlexSelect.Clear()
        FlexSelect.Rows = 1
    End Sub

    Private Sub FlexPoko_ClickEvent(ByVal sender As Object, ByVal e As System.EventArgs) Handles FlexPoko.ClickEvent
        Dim i As Integer
        Dim cMsg As String
        If FlexSelect.Rows < 7 Then
            FlexPoko.Col = 0
            cMsg = FlexPoko.Text
            FlexPoko.Col = 1
            FlexSelect.AddItem(cMsg & vbTab & FlexPoko.Text)
            LblName.Text = cMsg
            FileTile = My.Application.Info.DirectoryPath & "\images\PokemonPics\" & cMsg & ".gif"
            enActivePkmn.Image = Image.FromFile(FileTile)
            ' Image1.Picture = LoadPicture(App.Path & "\images\PokemonPics\" & cMsg & ".gif")
            If TxtMyPoko.Text = "" Then
                TxtMyPoko.Text = cMsg & ","
                TxtMyLevel.Text = FlexPoko.Text & ","
            Else
                TxtMyPoko.Text = TxtMyPoko.Text & cMsg & ","
                TxtMyLevel.Text = TxtMyLevel.Text & FlexPoko.Text & ","
            End If
        End If
    End Sub

    Private Sub FlexPoko_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlexPoko.Enter

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDone.Click
        If TxtMyPoko.Text <> "" Then
            FrmSpeech.RichTextBox1.Text = FrmSpeech.RichTextBox1.Text & "Pokemon!" & TxtMyPoko.Text & vbCrLf
            FrmSpeech.RichTextBox1.Text = FrmSpeech.RichTextBox1.Text & "PokeLevel!" & TxtMyLevel.Text & vbCrLf
            FrmSpeech.RichTextBox1.Text = FrmSpeech.RichTextBox1.Text & "Poke=Do you want to fight?" & vbCrLf
        End If
        Me.Close()
        Me.Dispose()
    End Sub
End Class