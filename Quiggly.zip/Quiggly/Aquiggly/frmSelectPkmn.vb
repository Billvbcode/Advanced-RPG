﻿Public Class frmSelectPkmn

    Private Sub frmSelectPkmn_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim Kud As Integer
        Dim kLR As Integer
        Dim m As Integer
        Dim attacks() As String = {"dog", "cat", "fish"}
        attacks = {"Bulbasaur", "Charmander", "Squirtle", "Chicorita", "Cyndaquil", "Totodile", "Treeko", "Torchic", "Mudkip", "Turtwig", "Chimchar", "Piplup"}
        For Kud = 1 To 4
            For kLR = 1 To 3
                m = kLR + Kud * 3 - 3
                PB(m) = New System.Windows.Forms.PictureBox()
                With PB(m)
                    .Name = m
                    .Location = New System.Drawing.Point(150 * kLR - 80, 120 * Kud - 90)
                    .Size = New Size(70, 70)
                    .SizeMode = PictureBoxSizeMode.StretchImage
                End With

                ' This is the line that sometimes catches people out!
                '  This is the line that sometimes catches people out!
                Panel1.Controls.Add(PB(m))
                'AddHandler PB(m).Click, AddressOf pbe_Click
                FileTile = My.Application.Info.DirectoryPath & "\Images\PokemonPics\" & attacks(m - 1) & ".gif"
                PB(m).Image = Image.FromFile(FileTile)
            Next
        Next
        For Kud = 1 To 4
            For kLR = 1 To 3
                m = kLR + Kud * 3 - 3
                RB(m) = New System.Windows.Forms.RadioButton
                With RB(m)
                    .Name = m
                    .Location = New System.Drawing.Point(150 * kLR - 80, 120 * Kud - 10)
                    ' .Size = New Size(90, 90)
                    .AutoSize = True
                    .Font = New Font("Arial", 10, FontStyle.Bold)
                    '.SizeMode = PictureBoxSizeMode.StretchImage
                End With

                '  This is the line that sometimes catches people out!
                '  This is the line that sometimes catches people out!
                Panel1.Controls.Add(RB(m))
                RB(m).Text = attacks(m - 1)
                'AddHandler PB(m).Click, AddressOf pbe_Click
                'FileTile = My.Application.Info.DirectoryPath & "\Images\PokemonPics\" & attacks(m - 1) & ".gif"
                'PB(m).Image = Image.FromFile(FileTile)
            Next
        Next
        RB(1).Checked = True
    End Sub

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim i As Integer
        nPoko = New Collection
        poko = New ClsPoko
        For i = 1 To 12
            If RB(i).Checked Then poko.Name = RB(i).Text
        Next
        poko.Level = 9
        poko.Status = "Nrml"
        poko.Value = poko.Level * 7
        poko.Max = poko.Level * 7
        poko.Wins = 0
        poko.Hit1M = 0
        poko.Hit2M = 0
        poko.Hit3M = 0
        poko.Hit4M = 0
        nPoko.Add(poko)

        Pokeballs = 10
        'Form1.Show()
        Me.Hide()
        'Me.Close()
        'Me.Dispose()
        ''Unload(Me)
        'Form1.Show()
    End Sub
End Class