﻿Public Class FrmB22

    Private Sub RectangleShape9_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim i As Integer
        DGrid.Rows.Clear()
        DGrid.Columns.Clear()
        DGrid.ColumnCount = 6
        DGrid.Columns(0).Name = "Mfg"
        DGrid.Columns(1).Name = "Style"
        DGrid.Columns(2).Name = "Color"
        DGrid.Columns(3).Name = "Year"
        DGrid.Columns(4).Name = "Doors"
        DGrid.Columns(5).Name = "Cost"
        DGrid.Rows.Insert(0, New String() {"Chevy", "Car", "Blue", _
                                          "2015", "4 Door", "$20,000"})
        DGrid.Rows.Insert(1, New String() {"Ford", "Car", "Red", _
                                          "2011", "4 Door", "$18,000"})
        For i = 0 To DGrid.Rows.Count - 1
            '    Label1.Text = DGrid.Item(0, i).Value()

        Next
    End Sub

    Private Sub DGrid_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGrid.CellClick
        Dim i As Integer
        Label1.Text = DGrid.Item(e.ColumnIndex, e.RowIndex).Value()
        Label3.Text = ""
        For i = 0 To DGrid.ColumnCount - 1
            Label3.Text = Label3.Text & " " & DGrid.Item(i, e.RowIndex).Value()
        Next
        For i = 0 To 1
            DGrid.Item(i, e.RowIndex).Style.BackColor = Color.Aqua
        Next
    End Sub

    Private Sub DGrid_CellContentClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGrid.CellContentClick

    End Sub
End Class