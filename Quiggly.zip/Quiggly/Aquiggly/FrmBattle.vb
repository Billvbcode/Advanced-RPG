﻿Public Class FrmBattle
    Dim optAttackIndex As Integer
    Dim prev As Integer
    Dim myWins As Integer
    Dim enPkmnList As Integer, urPkmnList As Integer
    Dim prevLyfValue As Integer, tt As String
    Dim current As Integer
    Dim firstturn As Integer
    Dim a As Integer
    Dim Mycatch As Integer
    'Dim sFilebug As String
    'Dim srFilebug As System.IO.StreamWriter
    'Dim sBugOut As String
    Function urDead()
        On Error GoTo outOfPkmn
        MsgBox(urName.Text & " fainted", , tt)
        enTmr.Enabled = False
        For Each poko In nPoko
            urName.Text = poko.Name
            FileTile = My.Application.Info.DirectoryPath & "\Images\PokemonPics\" & poko.Name & ".gif"
            urActivePkmn.Image = Image.FromFile(FileTile)
            urLvl.Text = poko.Level
            urStat.Text = poko.Status
            urLyf.Maximum = poko.Level * 7
            urLyf.Value = poko.Value
            urLyfOver.Text = urLyf.Value & "/" & urLyf.Maximum
            urLvl.Text = "Lv. " & poko.Level
            myWins = poko.Wins
            If poko.Value >= 1 Then Exit For
        Next
        sBugOut = "urdead " & urName.Text & " " & urLyfOver.Text
        srFilebug.WriteLine(sBugOut)
        Label7.Text = "Wins = " & myWins
        If Val(urLyf.Value) <= 1 Then GoTo outOfPkmn
        Call Pokedex(urName.Text, 1)
        If iErr > 0 Then
            a = 0

        End If
        iErr = 99
        'Call Pokedex(urName.Text, 1)
        Call descAttack(optAttack0.Text, 3, 0)
        lblPP0.Text = "x" & pp
        Call descAttack(optAttack1.Text, 3, 0)
        lblPP1.Text = "x" & pp
        Call descAttack(optAttack2.Text, 3, 0)
        lblPP2.Text = "x" & pp
        Call descAttack(optAttack3.Text, 3, 0)
        lblPP3.Text = "x" & pp
       
        Randomize()
        firstturn = Int(Rnd * 3)
        firstturn = 1
        If firstturn = 1 Then
            MsgBox("Foe " & enName.Text & " attacked first", , tt)
            iErr = 150
            enTurn()
            iErr = 251
            urDisplay.Text = ""
        End If


        Exit Function
outOfPkmn:
        enPkmnList = 0
        MsgBox("You have ran out of Pokemon. You have been defeated", , tt)
        sGiveBadge = ""
        bYouWin = False
        Me.Close()
        Me.Dispose()


    End Function

    Function setBoolean(ByVal bol As Boolean)
        cmdCatch.Enabled = bol
        ' cmdRun.Enabled = bol
        'cmdAttack.Enabled = bol
        ' cmdUse.Enabled = bol
        'cmdSendOut.Enabled = bol
        ' SSTab1.TabEnabled(2) = bol
    End Function
    Function levelUp()
        Dim myMax As Integer
        Dim iVal As Integer
        Dim iLvl As Integer
        For Each poko In nPoko
            If urName.Text = poko.Name Then
                myWins = poko.Wins + 1
                myMax = poko.Value
                iVal = Val(Mid(lblPP0.Text, 2, Len(lblPP0.Text)))
                poko.Hit1 = iVal
                iVal = Val(Mid(lblPP1.Text, 2, Len(lblPP0.Text)))
                poko.Hit2 = iVal
                iVal = Val(Mid(lblPP3.Text, 2, Len(lblPP0.Text)))
                poko.Hit3 = iVal
                iVal = Val(Mid(lblPP3.Text, 2, Len(lblPP0.Text)))
                poko.Hit4 = iVal
                Exit For
            End If
        Next
        sBugOut = "LevelUp " & urName.Text & " " & urLyfOver.Text
        srFilebug.WriteLine(sBugOut)
        iLvl = Val(Mid(urLvl.Text, 4, Len(urLvl.Text) - 3))
         If myWins >= 4 Then
            iLvl = Val(Mid(urLvl.Text, 4, Len(urLvl.Text) - 3)) + 1
            MsgBox(urName.Text & " grew to level " & iLvl)
            urLvl.Text = "Lv. " & iLvl
            myWins = 0
            poko.Hit1 = poko.Hit1M
            poko.Hit2 = poko.Hit2M
            poko.Hit3 = poko.Hit3M
            poko.Hit4 = poko.Hit4M
            myMax = Val(iLvl) * 7
            urStat.Text = "Nrml"
            preEvolutionName = urName.Text
            evolutionName = urName.Text
            Call evolution(urPkmnList, iLvl)
            urName.Text = evolutionName
        End If
        For Each poko In nPoko
            If urName.Text = poko.Name Then
                poko.Wins = myWins
                poko.Level = Val(Mid(urLvl.Text, 4, Len(urLvl.Text) - 3))
                poko.Value = urLyf.Value
                poko.Max = Val(iLvl) * 7
                poko.Status = urStat.Text
                urLyfOver.Text = urLyf.Value & "/" & poko.Max
                Exit For
            End If
        Next
        Label7.Text = "Wins = " & myWins
    End Function
    Function functionEnemyDead()
        On Error GoTo outOfPkmn
        Dim i As Integer
        urTmr.Enabled = False
        levelUp()

        MsgBox("Foe " & enName.Text & " fainted", , tt)
        enPkmnList = enPkmnList + 1
        If enParty(enPkmnList) = "" Then GoTo outOfPkmn
        FileTile = My.Application.Info.DirectoryPath & "\Images\PokemonPics\" & enParty(enPkmnList) & ".gif"
        enActivePkmn.Image = Image.FromFile(FileTile)
        enName.Text = enParty(enPkmnList)
        enName.Text = UCase(Mid(enName.Text, 1, 1)) & LCase(Mid(enName.Text, 2, Len(enName.Text) - 1))
        enLvl.Text = "Lv. " & enPartyLevel(enPkmnList)

        enStat.Text = "Nrml"
        enLyf.Maximum = enPartyLevel(enPkmnList) * 7
        enLyf.Value = enLyf.Maximum
        enLyfOver.Text = enLyf.Value & "/" & enLyf.Maximum

        Call Pokedex(enName.Text, 2)
        Call descAttack(enAttack(a), 3, 0)
        lblPP0.Tag = pp
        Call descAttack(enAttack(a), 3, 0)
        lblPP1.Tag = pp
        Call descAttack(enAttack(a), 3, 0)
        lblPP2.Tag = pp

        Call descAttack(enAttack(a), 3, 0)
        lblPP3.Tag = pp
        Randomize()
        firstturn = Int(Rnd * 3)
        If firstturn = 1 Then
            MsgBox("Foe " & enName.Text & " attacked first", , tt)
            enTurn()
            urDisplay.Text = ""
        End If

        Exit Function
outOfPkmn:


        Me.Close()
        Me.Dispose()
        'enPkmnList = 0
        'optAttackIndex = 0
    End Function

    Function enTurn()
        Dim Prlz As Integer
        Dim Slp As Integer
        Dim Frz As Integer
        Dim compattack As Integer
        On Error GoTo errorhandler
        If urName.Text = "Squirtle" And iErr > 0 Then
            a = 0
        End If
        If enStat.Text = "Psn" Then
            MsgBox("Foe " & enName.Text & " is hurt by the poison", , tt)
            enLyf.Value = enLyf.Value - (enLyf.Value \ 3)
            enLyfOver.Text = enLyf.Value & "/" & enLyf.Maximum
        End If
        If enStat.Text = "Prlz" Then
            Prlz = Int((5 + 1 - 1) * Rnd() + 1)
            If Prlz <= 3 Then
                MsgBox("Foe " & enName.Text & " can't move because of paralysis", , tt)
                setBoolean(True)
                Exit Function
            Else
                MsgBox("Foe " & enName.Text & " get rid of Paralysis", , tt)
                enStat.Text = "Nrml"
            End If
        End If
        If urName.Text = "Squirtle" And iErr > 0 Then
            a = 0
        End If
        If enStat.Text = "Brn" Then
            MsgBox("Foe " & enName.Text & " is hurt by the burn", , tt)
            enLyf.Value = enLyf.Value - (enLyf.Value \ 3)
            enLyfOver.Text = enLyf.Value & "/" & enLyf.Maximum
        End If
        If enStat.Text = "Slp" Then
            Slp = Int((5 + 1 - 1) * Rnd() + 1)
            If Slp <= 3 Then
                MsgBox("Foe " & enName.Text & " is fast asleep", , tt)
                setBoolean(True)
                Exit Function
            Else
                MsgBox("Foe " & enName.Text & " Woke Up", , tt)
                enStat.Text = "Nrml"
            End If
        End If
        If enStat.Text = "Frz" Then
            Frz = Int((5 + 1 - 1) * Rnd() + 1)
            If Frz <= 4 Then
                MsgBox("Foe " & enName.Text & " is frozen solid", , tt)
                setBoolean(True)
                Exit Function
            Else
                MsgBox("Foe " & enName.Text & " Defroze", , tt)
                enStat.Text = "Nrml"
            End If
        End If

        '*************************************************************************************
        enHasPP = False
        If urName.Text = "Squirtle" And iErr > 0 Then
            a = 0
        End If
        Do While enHasPP = False
            Randomize()
            compattack = Int(Rnd() * 4)
            If compattack = 0 And lblPP0.Tag > 0 Then enHasPP = True
            If compattack = 1 And lblPP1.Tag > 0 Then enHasPP = True
            If compattack = 2 And lblPP2.Tag > 0 Then enHasPP = True
            If compattack = 3 And lblPP3.Tag > 0 Then enHasPP = True
        Loop

        If compattack = 0 Then lblPP0.Tag = Val(lblPP0.Tag) - 1
        If compattack = 1 Then lblPP1.Tag = Val(lblPP0.Tag) - 1
        If compattack = 2 Then lblPP2.Tag = Val(lblPP0.Tag) - 1
        If compattack = 3 Then lblPP3.Tag = Val(lblPP0.Tag) - 1

        enTurn = False
        Call Pokedex(enName.Text, 2)
        Call descAttack(enAttack(compattack), 2, urPkmnList)
        ' LblEnType.Text = "**" & enAttack(compattack)
        If urName.Text = "Squirtle" And iErr > 0 Then
            a = 0
        End If
        Call calculateDamage(Damage, atkType, urType1, urType2, Val(Mid(enLvl.Text, 4, Len(enLvl.Text) - 3))) ' Val(enLvl.Text))
        If urName.Text = "Squirtle" And iErr > 0 Then
            a = 0
        End If
        prevLyfValue = urLyf.Value
        EnDisplay.Text = enName.Text & " used " & enAttack(compattack) & " and inflict " & totalDamage & " damage"
        If iErr > 90 Then
            iErr = iErr + 1
        End If
        If urName.Text = "Squirtle" And iErr > 0 Then
            a = 0
        End If
        enTmr.Enabled = True
        Exit Function
        '*************************************************************************************
errorhandler:
        functionEnemyDead()
    End Function

    Private Sub FrmBattle_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' 
        Dim value As String = My.Application.Info.DirectoryPath
        Dim bHitmax As Boolean
        Dim pp1 As Integer
        Dim pp2 As Integer
        Dim pp3 As Integer
        Dim pp4 As Integer
        Dim pp1v As Integer
        Dim pp2v As Integer
        Dim pp3v As Integer
        Dim pp4v As Integer
        'sFilebug = value & "\text.txt"
        'srFilebug = New System.IO.StreamWriter(sFilebug)
        bYouWin = True
        Label6.Text = ""
        If sGiveBadge <> "" Then Label6.Text = "Badge " & sGiveBadge '
        UrDisplay.Text = ""
        EnDisplay.Text = ""
        optAttackIndex = 0
        prev = 0
        optAttack0.Checked = True
        ';itemlist = Array("Potion", "Super Potion", "Max Potion", "Full Restore", "Antidote", "Parlyz Heal", "Awakening", "Burn Heal", "Ice Heal")
        'desclist = Array("Restore pokemon life by 20", "Restore pokemon life by 50", "Fully restore pokemon life", "Fully restore pokemon life and it's illness", "Cure Poison", "Cure Paralysis", "Awaken Sleeping Pokemon", "Cure Burn", "Defroze freezing pokemon")
        '
        ' Show your pokoman
        '
        ' Pokeballs = 10
        FileTile = My.Application.Info.DirectoryPath & "\TILES\POKEBALL.jpg"
        imgPokeball.Image = Image.FromFile(FileTile)
        imgPokeball2.Image = Image.FromFile(FileTile)
        'Exit Sub
        FileTile = My.Application.Info.DirectoryPath & "\images\PokemonPics\mLeft.jpg"
        ' imgLeftChar.Image = Image.FromFile(FileTile)
        bHitmax = False
        For Each poko In nPoko
            urName.Text = poko.Name
            FileTile = My.Application.Info.DirectoryPath & "\Images\PokemonPics\" & poko.Name & ".gif"
            urActivePkmn.Image = Image.FromFile(FileTile)
            urLvl.Text = "Lv. " & poko.Level
            urStat.Text = poko.Status
            urLyf.Maximum = poko.Level * 7
            urLyf.Value = poko.Value
            urLyfOver.Text = urLyf.Value & "/" & urLyf.Maximum
            myWins = poko.Wins
            pp1v = poko.Hit1
            pp2v = poko.Hit2
            pp3v = poko.Hit3
            pp4v = poko.Hit4
            If poko.Value >= 1 Then
                If poko.Hit1M > 0 Then bHitmax = True
                Exit For
            End If
        Next
        sBugOut = "Load " & urName.Text & " " & urLyfOver.Text
        srFilebug.WriteLine(sBugOut)
        Label7.Text = "Wins = " & myWins
        If Val(urLyf.Value) <= 1 Then GoTo outOfPkmn
        Call Pokedex(urName.Text, 1)
        '
        'enemy
        enPkmnList = 0
        ' enParty(enPkmnList) = "Ivysaur"
        ' enPartyLevel(enPkmnList) = 5
        FileTile = My.Application.Info.DirectoryPath & "\Images\PokemonPics\" & enParty(enPkmnList) & ".gif"
        enActivePkmn.Image = Image.FromFile(FileTile)
        enName.Text = enParty(enPkmnList)
        enName.Text = UCase(Mid(enName.Text, 1, 1)) & LCase(Mid(enName.Text, 2, Len(enName.Text) - 1))
        enLvl.Text = "Lv. " & enPartyLevel(enPkmnList)
        enLyf.Maximum = enPartyLevel(enPkmnList) * 7
        enLyf.Value = enLyf.Maximum
        enLyfOver.Text = enPartyLevel(enPkmnList) * 7 & "/" & enLyf.Maximum
        Call Pokedex(enName.Text, 2)     'describe foe pokemon
        '
        nagEvolve = False
        CmdCatch.Text = "&" & "Catch (" & Pokeballs & ")"


        Call descAttack(optAttack0.Text, 3, 0)
        lblPP0.Text = "x" & pp1v
        pp1 = pp
        Call descAttack(enAttack(a), 3, 0)
        lblPP0.Tag = pp1v
        Call descAttack(optAttack1.Text, 3, 0)
        lblPP1.Text = "x" & pp2v
        pp2 = pp
        Call descAttack(enAttack(a), 3, 0)
        lblPP1.Tag = pp2v
        Call descAttack(optAttack2.Text, 3, 0)
        lblPP2.Text = "x" & pp3v
        pp3 = pp
        Call descAttack(enAttack(a), 3, 0)
        lblPP2.Tag = pp3v
        Call descAttack(optAttack3.Text, 3, 0)
        lblPP3.Text = "x" & pp4v
        pp4 = pp
        Call descAttack(enAttack(a), 3, 0)
        lblPP3.Tag = pp4v
        If bHitmax = False Then
            For Each poko In nPoko
                If urName.Text = poko.Name Then
                    poko.Hit1M = pp1
                    poko.Hit2M = pp2
                    poko.Hit3M = pp3
                    poko.Hit4M = pp4
                    poko.Hit1 = pp1
                    poko.Hit2 = pp2
                    poko.Hit3 = pp3
                    poko.Hit4 = pp4
                    lblPP0.Text = "x" & pp1
                    lblPP0.Tag = pp1
                    lblPP1.Text = "x" & pp2
                    lblPP1.Tag = pp2
                    lblPP2.Text = "x" & pp3
                    lblPP2.Tag = pp3
                    lblPP3.Text = "x" & pp4
                    lblPP3.Tag = pp4
                    Exit For
                End If
            Next
        End If

        Randomize()
        firstturn = Int(Rnd() * 3)
        If firstturn = 1 Then
            MsgBox("Foe " & enName.Text & " attacked first", , tt)
            enTurn()
        End If
        Exit Sub
outOfPkmn:
        enPkmnList = 0
        MsgBox("You have ran out of Pokemon. You have been defeated", , tt)
        sGiveBadge = ""
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub cmdAttack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAttack.Click
        Dim cErr As Integer
        Dim Prlz As Integer
        Dim Slp As Integer
        Dim Frz As Integer
        Dim iVal As Integer
        UrDisplay.Text = ""
        Label7.Text = "Wins = " & myWins
        Call Pokedex(urName.Text, 1)
        Call Pokedex(enName.Text, 2)
        If optAttack0.Checked Then optAttackIndex = 0
        If optAttack1.Checked Then optAttackIndex = 1
        If optAttack2.Checked Then optAttackIndex = 2
        If optAttack3.Checked Then optAttackIndex = 3
        If optAttackIndex = 0 Then iVal = Val(Mid(lblPP0.Text, 2, Len(lblPP0.Text))) - 1
        If optAttackIndex = 1 Then iVal = Val(Mid(lblPP1.Text, 2, Len(lblPP0.Text))) - 1
        If optAttackIndex = 2 Then iVal = Val(Mid(lblPP3.Text, 2, Len(lblPP0.Text))) - 1
        If optAttackIndex = 3 Then iVal = Val(Mid(lblPP3.Text, 2, Len(lblPP0.Text))) - 1
        If optAttackIndex = 0 Then lblUrType.Text = optAttack0.Text
        If optAttackIndex = 1 Then lblUrType.Text = optAttack1.Text
        If optAttackIndex = 2 Then lblUrType.Text = optAttack2.Text
        If optAttackIndex = 3 Then lblUrType.Text = optAttack3.Text
        If iVal + 1 = 0 Then
            If optAttackIndex = 0 Then MsgBox(urName.Text & "'s " & optAttack0.Text & " is 0", , tt)
            If optAttackIndex = 1 Then MsgBox(urName.Text & "'s " & optAttack1.Text & " is 0", , tt)
            If optAttackIndex = 2 Then MsgBox(urName.Text & "'s " & optAttack2.Text & " is 0", , tt)
            If optAttackIndex = 3 Then MsgBox(urName.Text & "'s " & optAttack3.Text & " is 0", , tt)
            Exit Sub
        End If
        If optAttackIndex = 0 Then lblPP0.Text = "x" & iVal
        If optAttackIndex = 1 Then lblPP1.Text = "x" & iVal
        If optAttackIndex = 2 Then lblPP2.Text = "x" & iVal
        If optAttackIndex = 3 Then lblPP3.Text = "x" & iVal
        cErr = 1
        'If optAttackIndex = 0 Then lblPP0.Text = "x" & Val(Mid(lblPP0.Text, 2, Len(lblPP0.Text))) - 1
        'If optAttackIndex = 1 Then lblPP1.Text = "x" & Val(Mid(lblPP1.Text, 2, Len(lblPP0.Text))) - 1
        'If optAttackIndex = 2 Then lblPP2.Text = "x" & Val(Mid(lblPP3.Text, 2, Len(lblPP0.Text))) - 1
        'If optAttackIndex = 3 Then lblPP2.Text = "x" & Val(Mid(lblPP3.Text, 2, Len(lblPP0.Text))) - 1
        UrDisplay.Text = ""
        EnDisplay.Text = ""

        On Error GoTo errorhandler

        If urStat.Text = "Psn" Then
            MsgBox(urName.Text & " is hurt by the poison", , tt)
            urLyf.Value = urLyf.Value - (urLyf.Value \ 3)
            urLyfOver.Text = urLyf.Value & "/" & urLyf.Maximum
            Call SetPokoValue()
            '
            '    If curLyf(urPkmnList) = 0 Then
            '        urDead
            '        Exit Sub
            '    End If
        End If
        cErr = 2
        If urStat.Text = "Prlz" Then
            Prlz = Int((5 - 1 + 1) * Rnd() + 1)
            If Prlz <= 3 Then
                MsgBox(urName.Text & " can't move because of paralysis", , tt)
                Call SetPokoValue()
                enTurn()
                Exit Sub
            Else
                MsgBox(urName.Text & " get rid of paralysis", , tt)
                urStat.Text = "Nrml"
                Call SetPokoValue()
            End If
        End If
        If urStat.Text = "Brn" Then
            MsgBox(urName.Text & " is hurt by burn", , tt)
            urLyf.Value = urLyf.Value - (urLyf.Value \ 4)
            urLyfOver.Text = urLyf.Value & "/" & urLyf.Maximum
            Call SetPokoValue()
            '
            '    If curLyf(urPkmnList) = 0 Then
            '            urDead
            '            Exit Sub
            '    End If
        End If
        If urStat.Text = "Slp" Then
            Slp = Int((5 - 1 + 1) * Rnd() + 1)
            If Slp <= 3 Then
                MsgBox(urName.Text & " is fast asleep", , tt)
                Call SetPokoValue()
                enTurn()
                Exit Sub
            Else
                MsgBox(urName.Text & " Woke Up", , tt)
                urStat.Text = "Nrml"
                Call SetPokoValue()
            End If
        End If
        cErr = 3
        If urStat.Text = "Frz" Then
            Frz = Int((5 - 1 + 1) * Rnd() + 1)
            If Frz <= 3 Then
                MsgBox(urName.Text & " is frozen solid", , tt)
                Call SetPokoValue()
                enTurn()
                Exit Sub
            Else
                MsgBox(urName.Text & "Defreeze", , tt)
                urStat.Text = "Nrml"
                Call SetPokoValue()
            End If
        End If

        '**************************************END OF STAT CHECK*********************************

        setBoolean(False)

        If optAttackIndex = 0 Then Call descAttack(optAttack0.Text, 1, urPkmnList)
        If optAttackIndex = 1 Then Call descAttack(optAttack1.Text, 1, urPkmnList)
        If optAttackIndex = 2 Then Call descAttack(optAttack2.Text, 1, urPkmnList)
        If optAttackIndex = 3 Then Call descAttack(optAttack3.Text, 1, urPkmnList)
        Call calculateDamage(Damage, atkType, enType1, enType2, Val(Mid(urLvl.Text, 4, Len(urLvl.Text) - 3)))
        If optAttackIndex = 0 Then UrDisplay.Text = urName.Text & " used " & optAttack0.Text & " and inflict " & totalDamage & " damage"
        If optAttackIndex = 1 Then UrDisplay.Text = urName.Text & " used " & optAttack1.Text & " and inflict " & totalDamage & " damage"
        If optAttackIndex = 2 Then UrDisplay.Text = urName.Text & " used " & optAttack2.Text & " and inflict " & totalDamage & " damage"
        If optAttackIndex = 3 Then UrDisplay.Text = urName.Text & " used " & optAttack3.Text & " and inflict " & totalDamage & " damage"
        'UrDisplay.Text = urName.Text & " used " & optAttack(optAttackIndex).Text & " and inflict " & totalDamage & " damage"
        urTmr.Enabled = True
        prevLyfValue = enLyf.Value

        Exit Sub

errorhandler:
        enTmr.Enabled = False
        urDead()
      
    End Sub

    Private Sub enTmr_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles enTmr.Tick
        On Error GoTo enemyDead


        If urLyf.Value <= prevLyfValue - totalDamage Then
            If urName.Text = "Squirtle" And iErr > 0 Then
                a = 0
            End If
            If urLyf.Value = 0 Then GoTo enemyDead
            setBoolean(True)
            enTmr.Enabled = False
        Else
            'If urLyf.Max >= 200 Then enTmr.Interval = 40
            'If urLyf.Max >= 250 Then enTmr.Interval = 35
            'If urLyf.Max >= 300 Then enTmr.Interval = 30
            'If urLyf.Max >= 400 Then enTmr.Interval = 25
            'If urLyf.Max >= 500 Then enTmr.Interval = 20
            'If urLyf.Max >= 500 Then enTmr.Interval = 15
            'If urLyf.Max >= 800 Then enTmr.Interval = 10

            urLyf.Value = urLyf.Value - 1
            urLyfOver.Text = urLyf.Value & "/" & urLyf.Maximum
            If urName.Text = "Squirtle" And iErr > 0 Then
                a = 0
            End If
            Call SetPokoValue()
            If urName.Text = "Squirtle" And iErr > 0 Then
                a = 0
            End If
        End If


        Exit Sub

enemyDead:
        setBoolean(True)
        If urName.Text = "Squirtle" And iErr > 0 Then
            a = 0
        End If
        enTmr.Enabled = False
        urDead()
    End Sub

    Private Sub urTmr_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles urTmr.Tick
        On Error GoTo enemyDead


        If enLyf.Value <= prevLyfValue - totalDamage Then
            If enLyf.Value = 0 Then GoTo enemyDead
            urTmr.Enabled = False
            setBoolean(True)
            enTurn()
        Else

            enLyf.Value = enLyf.Value - 1
            enLyfOver.Text = enLyf.Value & "/" & enLyf.Maximum
        End If





        Exit Sub

enemyDead:
        setBoolean(True)
        functionEnemyDead()
    End Sub

    Private Sub optAttack0_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        optAttackIndex = 0
    End Sub

    Private Sub CmdRun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdRun.Click
        Dim run As Integer
        UrDisplay.Text = ""
        EnDisplay.Text = ""
        CmdRun.Visible = False
        setBoolean(False)

        run = Int((10 - 1 + 1) * Rnd() + 1)
        If run <= runRate Then
            MsgBox("Got Away Safely", , tt)
            Me.Close()
            Me.Dispose()
        Else
            MsgBox("Can't Escape", , tt)
            setBoolean(False)
            Call enTurn()
        End If

    End Sub

    Private Sub CmdCatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdCatch.Click

        If Pokeballs <= 0 Then
            MsgBox("You're out of pokeball", , tt)
            Exit Sub
        End If
        imgPokeball.Visible = False
        imgPokeball2.Visible = True
        ''CmdCatch.Visible = False
        Pokeballs = Pokeballs - 1
        CmdCatch.Text = "&" & "Catch (" & Pokeballs & ")"
        UrDisplay.Text = ""
        EnDisplay.Text = ""
        setBoolean(False)
        'CmdCatch.Image = Nothing
        'imgPokeball.Visible = True
        tmrCatch.Enabled = True  ' Set timer

    End Sub

    Private Sub tmrCatch_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrCatch.Tick
        Dim icatch As Integer
        imgPokeball2.Top = imgPokeball2.Top - 25
        imgPokeball2.Left = imgPokeball2.Left + 5
        Label3.Text = "TOP " & imgPokeball2.Top
        Label4.Text = "lEFT " & imgPokeball2.Left
        For Each poko In nPoko
            If poko.Name = enName.Text Then Exit Sub
        Next
        If imgPokeball2.Top <= 70 Then
            Randomize()
            icatch = Int((10 - 1 + 1) * Rnd() + 1)

            If enLyf.Value = enLyf.Maximum Then icatch = icatch + 1
            If enStat.Text = "Nrml" Then icatch = icatch + 1
            ' catchrate = -99
            If icatch <= catchrate Then
                enActivePkmn.Visible = False
                tmrCatch.Enabled = False
                MsgBox("Congratulations, you caught " & enName.Text, , tt)
                poko = New ClsPoko
                poko.Name = enName.Text
                poko.Level = Val(Mid(enLvl.Text, 4, Len(enLvl.Text) - 3))
                poko.Status = "Nrml"
                poko.Value = poko.Level * 7
                poko.Max = poko.Level * 7
                poko.Wins = 0
                poko.Hit1M = 0
                poko.Hit2M = 0
                poko.Hit3M = 0
                poko.Hit4M = 0
                enActivePkmn.Visible = True
                imgPokeball2.Visible = False
                imgPokeball2.Top = 556
                imgPokeball2.Left = 314
                CmdCatch.Image = imgPokeball.Image
                nPoko.Add(poko)
                functionEnemyDead()
                ' Me.Close()
                ' Me.Dispose()
            Else
                tmrCatch.Enabled = False
                imgPokeball2.Visible = False
                enActivePkmn.Visible = True
                imgPokeball2.Top = 556
                imgPokeball2.Left = 314
                CmdCatch.Image = imgPokeball.Image
                MsgBox("Darn it! the Pokeball broke", , tt)
                Call enTurn()
            End If
        End If
        'tmrCatch.Enabled = False
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub RectangleShape9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub imgPokeball2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgPokeball2.Click

    End Sub

    Private Sub optAttack1_CheckedChanged(sender As Object, e As EventArgs) Handles optAttack1.CheckedChanged
        optAttack0.Checked = False
        optAttack2.Checked = False
        optAttack3.Checked = False
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub


    Private Sub optAttack2_CheckedChanged(sender As Object, e As EventArgs) Handles optAttack2.CheckedChanged
        optAttack1.Checked = False
        optAttack0.Checked = False
        optAttack3.Checked = False
    End Sub

    Private Sub optAttack3_CheckedChanged(sender As Object, e As EventArgs) Handles optAttack3.CheckedChanged
        optAttack1.Checked = False
        optAttack2.Checked = False
        optAttack0.Checked = False
    End Sub

    Private Sub cmdAttack_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cmdAttack.KeyUp
        If e.KeyCode = Keys.D1 Then
            Form3.ShowDialog()
        End If
    End Sub

    Private Sub TabPage1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage1.Click

    End Sub

    Private Sub optAttack0_Click(sender As Object, e As EventArgs) Handles optAttack0.Click
        optAttack1.Checked = False
        optAttack2.Checked = False
        optAttack3.Checked = False
        optAttack0.Checked = True
    End Sub

    Private Sub optAttack1_Click(sender As Object, e As EventArgs) Handles optAttack1.Click
        optAttack3.Checked = False
        optAttack2.Checked = False
        optAttack0.Checked = False
        optAttack1.Checked = True
    End Sub

    Private Sub optAttack2_Click(sender As Object, e As EventArgs) Handles optAttack2.Click
        optAttack1.Checked = False
        optAttack0.Checked = False
        optAttack3.Checked = False
        optAttack2.Checked = True
    End Sub

    Private Sub optAttack3_Click(sender As Object, e As EventArgs) Handles optAttack3.Click
        optAttack1.Checked = False
        optAttack2.Checked = False
        optAttack0.Checked = False
        optAttack3.Checked = True
    End Sub
End Class