﻿Public Class FrmCopy
    Private Sub GetFiles()
        '
        ' Read all the levels
        '
        Dim value As String = My.Application.Info.DirectoryPath & "\Maps\"
        Dim di As New IO.DirectoryInfo(value)
        Dim diar1 As IO.FileInfo() = di.GetFiles("*.1ap")
        Dim dra As IO.FileInfo
        Dim sMsg As String
        sMsg = value
        'list the names of all files in the specified directory
        For Each dra In diar1
            ListBox1.Items.Add(dra)
        Next
    End Sub
    Public Sub DrawIt2()
        Dim kk As Integer
        Dim PositionMap As String
        Dim cEvent As String
        Dim cDesc As String
        Dim mPB As Integer
        mPB = 1
        txtX.Text = XSB.Value
        TxtY.Text = YSB.Value
        For Y = 1 To 12
            For X = 1 To 24
                'If the result to Paint is 0 then it will get error.
                'This will prevent this.
                'PassToNext = 0
                If Y + YSB.Value + 0 < 1 Then Exit Sub
                If X + XSB.Value + 0 < 1 Then Exit Sub
                If X + XSB.Value + 0 > Len(Map(1)) Then Exit Sub
                If Y + YSB.Value + 0 > 99 Then Exit Sub
                ' If CheckTop.Checked Then
                PositionMap = Mid(Map(Y + YSB.Value + 1), (X + XSB.Value + 1), 1) & Mid(Map2(Y + YSB.Value + 1), (X + XSB.Value + 1), 1)
                
                If Y = 4 And X = 6 Then
                    kk = 1
                End If
                'If X = 0 And Y = 0 Then GoTo skip:
                For Each cTile In nTiles
                    'add all events and descriptions
                    cEvent = cTile.TileLet 'ctile.letter
                    cDesc = cTile.TileName 'tiles.Name
                    If cEvent = PositionMap Then
                        If UCase(cTile.TileType) = "ITEM" Then
                            kk = 1
                        End If
                        'ImgPaint = LoadPicture(App.Path & "\tiles\" & cDesc & ".jpg")
                        PB(mPB).Image = PB(cTile.MyTileCnt + m144).Image
                        mPB = mPB + 1
                    End If

                    'Text1.Text = Text1.Text & cEvent & " -- " & cDesc & Chr(13) & Chr(10)
                Next
            Next
        Next
        Y = 3

    End Sub
    Private Sub FrmCopy_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim kLR As Integer
        Dim kUD As Integer
        Dim m As Integer
        GetFiles()
        FileTile = My.Application.Info.DirectoryPath & "\tiles\grass.bmp"
        For kUD = 1 To 12

            For kLR = 1 To 24
                m = kLR + kUD * 24 - 24
                PB(m) = New System.Windows.Forms.PictureBox()
                With PB(m)
                    .Name = m
                    .Location = New System.Drawing.Point(30 * kLR - 10, 30 * kUD - 5)
                    .Size = New Size(30, 30)
                    .Image = Image.FromFile(FileTile)
                End With

                '  This is the line that sometimes catches people out!
                '  This is the line that sometimes catches people out!
                Me.Controls.Add(PB(m))
                'AddHandler PB(m).Click, AddressOf pbe_Click
                'Me.ToolTip1.SetToolTip(PB(m), m)
            Next
        Next
    End Sub

    Private Sub ListBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.Click
        TxtMap.Text = Mid(ListBox1.Text, 1, Len(ListBox1.Text) - 4)
        cMapFile = TxtMap.Text
        ReadMapFile(cMapFile)
        DrawIt2()
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub XSB_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles XSB.Scroll
        DrawIt2()
    End Sub

    Private Sub YSB_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles YSB.Scroll
        DrawIt2()
    End Sub

    Private Sub BtnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim i As Integer
        Dim cMsg As String
        '
        ' Copy Map Files Text1
        '
        If TxtMapNew.Text = "" Then Exit Sub
        For i = 1 To ListBox1.Items.Count
            cMsg = ListBox1.Items(i - 1)
            cMsg = Mid(ListBox1.Items(i - 1), 1, Len(ListBox1.Items(i - 1)) - 4)
            If UCase(cMsg) = UCase(TxtMapNew.Text) Then Exit Sub
        Next
        CheckFiles(TxtMapNew.Text)
        Call SaveMapFile(TxtMapNew.Text)
        GetFiles()
    End Sub

End Class