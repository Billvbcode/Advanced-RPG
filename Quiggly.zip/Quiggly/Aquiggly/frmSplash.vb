﻿Public Class frmSplash

    Private Sub tmrHeal_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrHeal.Tick
        Bar.Value = Bar.Value + 1

        If Bar.Value = 50 Then
            tmrHeal.Enabled = False
            Me.Close()
            Me.Dispose()
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Bar.Value = Bar.Value + 1

        If Bar.Value = 50 Then
            Timer1.Enabled = False
            Me.Close()
            Me.Dispose()
        End If
    End Sub

    Private Sub frmSplash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class