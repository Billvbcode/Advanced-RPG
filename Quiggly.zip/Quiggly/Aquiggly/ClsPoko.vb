﻿Public Class ClsPoko
    Private strName As String
    Private strStatus As String
    Private iLevel As Integer
    Private iValue As Integer
    Private iMax As Integer
    Private iWins As Integer
    Private iHit1 As Integer
    Private iHit1M As Integer
    Private iHit2 As Integer
    Private iHit2M As Integer
    Private iHit3 As Integer
    Private iHit3M As Integer
    Private iHit4 As Integer
    Private iHit4M As Integer
    Public Property Hit4M() As Integer       ' Melt time
        Get
            Return iHit4M
        End Get
        Set(ByVal Hit4M As Integer)
            iHit4M = Hit4M
        End Set
    End Property
    Public Property Hit4() As Integer       ' Melt time
        Get
            Return iHit4
        End Get
        Set(ByVal Hit4 As Integer)
            iHit4 = Hit4
        End Set
    End Property
    Public Property Hit3M() As Integer       ' Melt time
        Get
            Return iHit3M
        End Get
        Set(ByVal Hit3M As Integer)
            iHit3M = Hit3M
        End Set
    End Property
    Public Property Hit3() As Integer       ' Melt time
        Get
            Return iHit3
        End Get
        Set(ByVal Hit3 As Integer)
            iHit3 = Hit3
        End Set
    End Property
    Public Property Hit2M() As Integer       ' Melt time
        Get
            Return iHit2M
        End Get
        Set(ByVal Hit2M As Integer)
            iHit2M = Hit2M
        End Set
    End Property
    Public Property Hit2() As Integer       ' Melt time
        Get
            Return iHit2
        End Get
        Set(ByVal Hit2 As Integer)
            iHit2 = Hit2
        End Set
    End Property
    Public Property Hit1M() As Integer       ' Melt time
        Get
            Return iHit1M
        End Get
        Set(ByVal Hit1M As Integer)
            iHit1M = Hit1M
        End Set
    End Property
    Public Property Hit1() As Integer       ' Melt time
        Get
            Return iHit1
        End Get
        Set(ByVal Hit1 As Integer)
            iHit1 = Hit1
        End Set
    End Property
    Public Property Wins() As Integer       ' Melt time
        Get
            Return iWins
        End Get
        Set(ByVal Wins As Integer)
            iWins = Wins
        End Set
    End Property
    Public Property Max() As Integer       ' Melt time
        Get
            Return iMax
        End Get
        Set(ByVal Max As Integer)
            iMax = Max
        End Set
    End Property
    Public Property Value() As Integer       ' Melt time
        Get
            Return iValue
        End Get
        Set(ByVal Value As Integer)
            iValue = Value
        End Set
    End Property
    Public Property Level() As Integer       ' Melt time
        Get
            Return iLevel
        End Get
        Set(ByVal Value As Integer)
            iLevel = Value
        End Set
    End Property
    Public Property Status() As String      'Foe Description
        Get
            Return strStatus
        End Get
        Set(ByVal Value As String)
            strStatus = Value
        End Set
    End Property
    Public Property Name() As String      'Foe Description
        Get
            Return strName
        End Get
        Set(ByVal Value As String)
            strName = Value
        End Set
    End Property
End Class
