﻿Public Class FrmConnect
    Dim iRowFrom As Integer
    Dim iRowFromOld As Integer
    Dim sWFrom As String
    Dim cMyFilein As String
    Dim cFile As String
    Dim iWFromX As Integer
    Dim iWFromY As Integer
    Dim iRowTo As Integer
    Dim sWTo As String
    Dim iWToX As Integer
    Dim iWToY As Integer
    Dim X1 As Integer
    Dim Y1 As Integer
    Dim X3 As Integer
    Dim Y3 As Integer
    Dim imgACnt As Integer
    Dim bFix As Boolean
    Dim bChest As Boolean
    Dim cButton As String
    Dim iGcnt As Integer
    Dim iGcnt2 As Integer
    Private Sub Chest()
        'Public Sub AddDoor()
        Dim cFile As String
        Dim strMapName As String
        DGrid.Width = 385
        LblTitle.Text = "Chest"
        Label1.Text = "Click to select chest"
        Label2.Text = "Click to select item "
        cButton = "Chest"
        'FlexGrid.Rows = 1
        'FlexGrid.Cols = 1

        Dgrid2.Rows.Clear()
        Dgrid2.Columns.Clear()
        DGrid.Rows.Clear()
        DGrid.Columns.Clear()
        'FlexGrid2.FormatString = "Tile       " & vbTab & "Type" '& vbTab & "Description" '& vbTab & "Extra"
        iGcnt2 = 0
        Dgrid2.ColumnCount = 4
        Dgrid2.Columns(0).Name = "Tile......"
        Dgrid2.Columns(1).Name = "Type.."
        Dgrid2.Columns(2).Name = "Description.."
        Dgrid2.Columns(3).Name = "Extra.........."
        LblTo.Text = "Name"
        DGrid.Enabled = True
        LblTo.Text = "Name"
        'FlexGrid.FormatString = "From |Item         |Qty   |Name               "
        iGcnt = 0
        DGrid.ColumnCount = 4
        DGrid.Columns(0).Name = "From..."
        DGrid.Columns(1).Name = "Item.."
        DGrid.Columns(2).Name = "Qty.."
        DGrid.Columns(3).Name = "Name................."
        For i = 0 To ListBox1.Items.Count - 1
            strMapName = Mid(ListBox1.Items(i).ToString, 1, Len(ListBox1.Items(i).ToString) - 4)
            cFile = My.Application.Info.DirectoryPath & "\Maps\" & strMapName & "d.txt"
            iMapReadIn = -1
            ReadDoorFile(strMapName)
            bDark = False
            If sChestItems = "" Then sChestItems = "?"
            Call ReadMapFile(strMapName)
            If iChest > 0 Then
                'FlexGrid.AddItem(strMapName & vbTab & sChestItems & vbTab & iChest & vbTab & "Chest")
                DGrid.Rows.Insert(iGcnt, New String() {strMapName, sChestItems, iChest, "Chest"})
                iGcnt = iGcnt + 1
            End If
        Next
        For Each cTile In nTiles
            If cTile.TileType = "ITEM" Then
                ' FlexGrid2.AddItem(cTile.TileName & vbTab & cTile.TileType)
                Dgrid2.Rows.Insert(iGcnt2, New String() {cTile.TileName, cTile.TileType})
                iGcnt2 = iGcnt2 + 1
            End If
        Next
    End Sub
    Public Sub DrawIt2()
        Dim kk As Integer
        Dim PositionMap As String
        Dim cEvent As String
        Dim cDesc As String
        Dim mPB As Integer
        mPB = 1
        For Y = -2 To 3
            For X = X1 To X3
                mPB = X + Y * 24 + 52
                'If the result to Paint is 0 then it will get error.
                'This will prevent this.
                'PassToNext = 0
                If Y + CharY + 0 < 1 Then Exit Sub
                If X + CharX + 0 < 1 Then Exit Sub
                If X + CharX + 0 > Len(Map(1)) Then Exit Sub
                If Y + CharY + 0 > 99 Then Exit Sub
                PositionMap = Mid(Map(Y + CharY + 1), (X + CharX + 1), 1) & Mid(Map2(Y + CharY + 1), (X + CharX + 1), 1)
                'If X = 0 And Y = 0 Then GoTo skip:
                For Each cTile In nTiles
                    'add all events and descriptions
                    cEvent = cTile.TileLet 'ctile.letter
                    cDesc = cTile.TileName 'tiles.Name
                    If cEvent = PositionMap Then
                        If UCase(cTile.TileType) = "ITEM" Then
                            kk = 1
                        End If
                        'ImgPaint = LoadPicture(App.Path & "\tiles\" & cDesc & ".jpg")
                        PB(mPB).Image = PB(cTile.MyTileCnt + m144).Image
                        'mPB = mPB + 1
                    End If

                    'Text1.Text = Text1.Text & cEvent & " -- " & cDesc & Chr(13) & Chr(10)
                Next
            Next
        Next
        FileTile = My.Application.Info.DirectoryPath & "\tiles\a.bmp"
        mPB = X1 + 2 + 52
        PB(mPB).Image = Image.FromFile(FileTile)
    End Sub

    Private Sub FGrid()
        Dim i As Integer
        Dim j As Integer
        X1 = -3
        X3 = 3
        'FlexGrid.Row = iRowFrom
        'FlexGrid.Col = 0
        'SAVE_MapLoaded = FlexGrid.Text
        SAVE_MapLoaded = DGrid.Item(0, iRowFrom).Value()
        DGrid.Item(0, iRowFrom).Style.BackColor = Color.Yellow
        ' CheckFiles(SAVE_MapLoaded)
        ' FlexGrid.CellBackColor = Color.Yellow
        sWFrom = DGrid.Item(0, iRowFrom).Value() 'FlexGrid.Text
        iMapReadIn = 0
        ReadMapFile(sWFrom)
        'SAVE_MapLoaded = FlexGrid.Text
        DGrid.Item(1, iRowFrom).Style.BackColor = Color.Yellow
        DGrid.Item(2, iRowFrom).Style.BackColor = Color.Yellow
        'FlexGrid.Col = 1
        'FlexGrid.CellBackColor = Color.Yellow
        'FlexGrid.Col = 2
        'iWFromX = FlexGrid.Text
        iWFromX = DGrid.Item(2, iRowFrom).Value() 'FlexGrid.Text
        'CharX = FlexGrid.Text '+ Text3.Text
        CharX = DGrid.Item(2, iRowFrom).Value()
        'FlexGrid.CellBackColor = Color.Yellow
        'FlexGrid.Col = 3
        'FlexGrid.CellBackColor = Color.Yellow
        DGrid.Item(3, iRowFrom).Style.BackColor = Color.Yellow
        If iRowFromOld > -1 Then
            DGrid.Item(0, iRowFromOld).Style.BackColor = Color.White
            DGrid.Item(1, iRowFromOld).Style.BackColor = Color.White
            DGrid.Item(2, iRowFromOld).Style.BackColor = Color.White
            DGrid.Item(3, iRowFromOld).Style.BackColor = Color.White
        End If
        iRowFromOld = iRowFrom
        iWFromY = DGrid.Item(3, iRowFrom).Value() 'FlexGrid.Text
        'CharX = FlexGrid.Text '+ Text3.Text
        CharY = DGrid.Item(3, iRowFrom).Value()
        X1 = -3
        X3 = 3
        DrawIt2()
        ' FlexGrid.Col = 4
        If Dgrid2.Visible = False Then Exit Sub
        'sWTo = FlexGrid.Text
        sWTo = DGrid.Item(4, iRowFrom).Value()
        If bFix Or bChest Then
            For i = 1 To Dgrid2.Rows.Count - 1
                Dgrid2.Item(0, i).Style.BackColor = Color.White
                Dgrid2.Item(1, i).Style.BackColor = Color.White
                'FlexGrid2.Row = i
                'FlexGrid2.CellBackColor = Color.White
                'FlexGrid2.Col = 1
                'FlexGrid2.CellBackColor = Color.White
                'FlexGrid2.Row = i
                'FlexGrid2.Col = 0
                'If UCase(FlexGrid2.Text) = UCase(sWTo) Then
                If UCase(Dgrid2.Item(0, i).Value()) = UCase(sWTo) Then
                    Dgrid2.Item(0, i).Style.BackColor = Color.Yellow
                    LblMap2.Text = "Item= " & Dgrid2.Item(0, i).Value()
                    'FlexGrid2.Col = 1
                    'FlexGrid2.CellBackColor = Color.Yellow
                    Dgrid2.Item(1, i).Style.BackColor = Color.Yellow
                    For Each tiles In nTiles
                        'add all events and descriptions
                        If UCase(sWTo) = UCase(tiles.Name & tiles.AddName) Then
                            'ImgPaint = LoadPicture(App.Path & "\tiles\" & cDesc & ".jpg")
                            'PaintPicture(imgA(0).Picture, (13) * i32, (4) * i32)
                            'PaintPicture(imgA(0).Picture, (12) * i32, (4) * i32)
                            'PaintPicture(imgA(0).Picture, (14) * i32, (4) * i32)
                            'PaintPicture(imgA(0).Picture, (12) * i32, (5) * i32)
                            'PaintPicture(imgA(0).Picture, (14) * i32, (5) * i32)
                            'PaintPicture(imgA(tiles.TileCnt).Picture, (13) * i32, (5) * i32)
                            ' Exit For
                        End If

                        'Text1.Text = Text1.Text & cEvent & " -- " & cDesc & Chr(13) & Chr(10)
                    Next
                    ' Else

                    'If bFix Then Call SaveFix()
                    ' If bChest Then Call SaveChest()
                End If
            Next
            Exit Sub
        End If
        If sWTo <> "" Then
            ' FlexGrid.Col = 5
            'iWToX = FlexGrid.Text
            iWToX = DGrid.Item(5, iRowFrom).Value()
            ' FlexGrid.Col = 6
            ' iWToY = FlexGrid.Text
            iWToY = DGrid.Item(6, iRowFrom).Value()
            For i = 1 To Dgrid2.Rows.Count - 1
                Dgrid2.Item(0, i).Style.BackColor = Color.White
                Dgrid2.Item(1, i).Style.BackColor = Color.White
                Dgrid2.Item(2, i).Style.BackColor = Color.White
                Dgrid2.Item(3, i).Style.BackColor = Color.White
                'FlexGrid2.Row = i
                'FlexGrid2.CellBackColor = Color.White
                'FlexGrid2.Col = 1
                'FlexGrid2.CellBackColor = Color.White
                'FlexGrid2.Col = 2
                'FlexGrid2.CellBackColor = Color.White
                'FlexGrid2.Col = 3
                'FlexGrid2.CellBackColor = Color.White
                'FlexGrid2.Row = i
                'FlexGrid2.Col = 0

                If sWTo = Dgrid2.Item(0, i).Value() Then
                    j = 1
                    ' FlexGrid2.Col = 2
                    If iWToX = Dgrid2.Item(2, i).Value() Then
                        j = 1
                        ' FlexGrid2.Col = 3
                        If iWToY = Dgrid2.Item(3, i).Value() Then
                            iRowTo = i
                            Call Fgrid2()
                        End If
                    End If
                End If
            Next
        End If
        'Next
        ' iRowFromOld = iRowFrom
    End Sub
    Private Sub Fgrid2()
        'FlexGrid2.Row = iRowTo
        'FlexGrid2.Col = 0
        'FlexGrid2.CellBackColor = Color.Yellow
        Dgrid2.Item(0, iRowTo).Style.BackColor = Color.Yellow
        LblMap2.Text = "Map= " & Dgrid2.Item(0, iRowTo).Value() 'FlexGrid2.Text
        sWTo = Dgrid2.Item(0, iRowTo).Value() 'FlexGrid2.Text
        '.cFile = strDirLoc & FlexGrid2.Text & ".map"
        'FlexGrid2.Col = 1
        'FlexGrid2.CellBackColor = Color.Yellow
        'FlexGrid2.Col = 2
        'FlexGrid2.CellBackColor = Color.Yellow
        Dgrid2.Item(1, iRowTo).Style.BackColor = Color.Yellow
        Dgrid2.Item(2, iRowTo).Style.BackColor = Color.Yellow
        Dgrid2.Item(3, iRowTo).Style.BackColor = Color.Yellow
        iWToX = Dgrid2.Item(2, iRowTo).Value() 'FlexGrid2.Text
        CharX = Dgrid2.Item(2, iRowTo).Value() - 15 'FlexGrid2.Text - 15
        'FlexGrid2.Col = 3
        'FlexGrid2.CellBackColor = Color.Yellow
        iWToY = Dgrid2.Item(3, iRowTo).Value() 'FlexGrid2.Text
        CharY = Dgrid2.Item(3, iRowTo).Value() 'FlexGrid2.Text
        X1 = -3 + 15
        X3 = 3 + 15
        ReadMapFile(sWTo)
        DrawIt2()
    End Sub

    Private Sub GetFiles()
        '
        ' Read all the levels
        '
        Dim value As String = My.Application.Info.DirectoryPath & "\Maps\"
        Dim di As New IO.DirectoryInfo(value)
        Dim diar1 As IO.FileInfo() = di.GetFiles("*.1ap")
        Dim dra As IO.FileInfo
        Dim sMsg As String
        sMsg = value
        'list the names of all files in the specified directory
        For Each dra In diar1
            ListBox1.Items.Add(dra)
        Next
    End Sub
    Private Sub ReadTile()
        Dim cAddTile
        FileTile = My.Application.Info.DirectoryPath & "\tiles\"
        For Each cTile In nTiles
            iTileloc = cTile.MyTileCnt + m144
            cAddTile = cTile.TileName
            If UCase(cTile.TileAddName) <> "NONE" Then

                cAddTile = cTile.TileName & cTile.TileAddName
            End If
            FileTile = My.Application.Info.DirectoryPath & "\tiles\" & cAddTile & ".bmp"
            sToolTip = cTile.TileAddName 'ctilecTile.TileName
            'zzTile(iTileloc).Image = Image.FromFile(FileTile)
            'ShowTile()
            PB(iTileloc).Image = Image.FromFile(FileTile)
            ' Me.ToolTip1.SetToolTip(PB(iTileloc), cAddTile)
            PB(iTileloc).Tag = cAddTile
            bNewLevel = False
            'If cTile.MyTileCnt = 1 Then
            '    imgAll.Image = PB(iTileloc).Image
            '    imgAll.Tag = PB(iTileloc).Tag
            '    LblAll.Text = cTile.TileLet
            '    LblName.Text = cTile.TileName
            '    Me.ToolTip1.SetToolTip(imgAll, LblName.Text)
            'End If
            iLAstTile = cTile.MyTileCnt + m144
        Next
        ' ReadMapFile(cMapFile)
    End Sub
    Private Sub FrmConnect_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim m As Integer
        iRowFromOld = -1
        SAVE_MapLoaded = ""
        GetFiles()
        ReadTiles()
        m144 = 330
        bNewLevel = True
        FileTile = My.Application.Info.DirectoryPath & "\tiles\grass.bmp"
        For kUD = 1 To 12
            For kLR = 1 To 24
                m = kLR + kUD * 24 - 24
                PB(m) = New System.Windows.Forms.PictureBox()
                With PB(m)
                    .Name = m
                    .Location = New System.Drawing.Point(30 * kLR - 10, 30 * kUD - 5)
                    .Size = New Size(30, 30)
                End With

                '  This is the line that sometimes catches people out!
                '  This is the line that sometimes catches people out!
                Me.Controls.Add(PB(m))
                'AddHandler PB(m).Click, AddressOf pbe_Click
                'Me.ToolTip1.SetToolTip(PB(m), m)
            Next
        Next
        For kUD = 1 To 10
            For kLR = 1 To 25
                m = kLR + kUD * 25 - 25 + m144
                PB(m) = New System.Windows.Forms.PictureBox()
                With PB(m)
                    .Name = m
                    .Location = New System.Drawing.Point(30 * kLR - 20, 30 * kUD + 385)
                    .Size = New Size(30, 30)
                    .Tag = ""
                    .Visible = False
                End With

                '  This is the line that sometimes catches people out!
                Me.Controls.Add(PB(m))
                ' AddHandler PB(m).Click, AddressOf pbe_Click
            Next
        Next

        ReadTile()
    End Sub

    Private Sub CmdDoor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdDoor.Click
        Dim cFile As String
        Dim PositionMap As String
        Dim strMapName As String
        DGrid.Width = 355
        iRowFromOld = -1
        iRowFrom = -1
        iRowTo = -1
        TxtName.Text = ""
        TxtName.Visible = False
        'RedoFiles()
        LblTitle.Text = "Door"
        Button8.Visible = False
        Label1.Text = "Click to connect doors"
        Label2.Text = "Click to connect doors"
        CmdConnect.Text = "Connect doors"
        DGrid.Enabled = True
        Dgrid2.Enabled = True
        sWFrom = ""
        sWTo = ""
        LblMap1.Text = ""
        LblMap2.Text = ""
        cButton = "DOOR"
        iMapReadIn = 0
        bFix = False
        bChest = False
        ' CmdConnect.Visible = True
        CmdName.Visible = False
        TxtName.Visible = False
        LblTo.Text = "To"
        'FlexGrid.Clear()
        'FlexGrid2.Clear()
        Dgrid2.Visible = True
        ' FlexGrid.Rows = 1
        'FlexGrid.Cols = 1
        iGcnt = 0
        DGrid.Rows.Clear()
        DGrid.Columns.Clear()
        iGcnt2 = 0
        Dgrid2.Rows.Clear()
        Dgrid2.Columns.Clear()
        'FlexGrid.FormatString = "From |Type       |X  |Y  |To   | X | Y "
        DGrid.ColumnCount = 7
        DGrid.Columns(0).Name = "From.."
        DGrid.Columns(1).Name = "Type.."
        DGrid.Columns(2).Name = "X..."
        DGrid.Columns(3).Name = "Y..."
        DGrid.Columns(4).Name = "To."
        DGrid.Columns(5).Name = "X..."
        DGrid.Columns(6).Name = "Y..."
        For i = 0 To 6
            DGrid.Columns(i).Width = 40
        Next
        ' FlexGrid2.FormatString = "Map   |Type       |X  |Y  |To   | X | Y "
        ' FlexGrid2.Rows = 1
        Dgrid2.ColumnCount = 7
        Dgrid2.Columns(0).Name = "Map.."
        Dgrid2.Columns(1).Name = "Type.."
        Dgrid2.Columns(2).Name = "X..."
        Dgrid2.Columns(3).Name = "Y..."
        Dgrid2.Columns(4).Name = "To."
        Dgrid2.Columns(5).Name = "X..."
        Dgrid2.Columns(6).Name = "Y..."
        For i = 0 To 6
            Dgrid2.Columns(i).Width = 40
        Next
        For i = 0 To ListBox1.Items.Count - 1
            strMapName = Mid(ListBox1.Items(i).ToString, 1, Len(ListBox1.Items(i).ToString) - 4)
            cFile = My.Application.Info.DirectoryPath & "\Maps\" & strMapName & "d.txt"
            iMapReadIn = -1
            bDark = False
            Call ReadMapFile(strMapName)
            ReadDoorFile(strMapName)
            'cFile2 = App.Path & "\Maps\" & strMapName & ".2ap"
            '     Open cFile For Input As #1 '
            '            'Open cFile2 For Input As #2
            iTileloc = m144
            For Each doors In nDoors
                If doors.Mytype = "DOOR" Then
                    PositionMap = Mid(Map(doors.DooriY + 3), (doors.DooriX + 3), 1) & Mid(Map2(doors.DooriY + 3), (doors.DooriX + 3), 1)
                    For Each cTile In nTiles
                        If cTile.TileLet = PositionMap Then
                            iTileloc = cTile.MyTileCnt + m144
                        End If
                    Next
                    'FlexGrid.AddItem(strMapName & vbTab & PB(iTileloc).Tag & vbTab & doors.DooriX + 3 & vbTab & doors.DooriY + 3 _
                    '      & vbTab & doors.Name & vbTab & doors.DooriToX + 3 & vbTab & doors.DooriToY + 3)
                    DGrid.Rows.Insert(iGcnt, New String() {strMapName, PB(iTileloc).Tag, doors.DooriX + 3, _
                                           doors.DooriY + 3, doors.Name, doors.DooriToX + 3, doors.DooriToY + 3})
                    iGcnt = iGcnt + 1
                    ' FlexGrid2.AddItem(strMapName & vbTab & PB(iTileloc).Tag & vbTab & doors.DooriX + 3 & vbTab & doors.DooriY + 3 _
                    '      & vbTab & doors.Name & vbTab & doors.DooriToX + 3 & vbTab & doors.DooriToY + 3)
                    Dgrid2.Rows.Insert(iGcnt2, New String() {strMapName, PB(iTileloc).Tag, doors.DooriX + 3, doors.DooriY + 3,
                                                               doors.Name, doors.DooriToX + 3, doors.DooriToY + 3})
                    iGcnt2 = iGcnt2 + 1
                End If
            Next

        Next
    End Sub

    Private Sub CmdName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdName.Click
        'FrmEdit.ShowDialog()
        ' Dim cMyFilein2 As String
        Dim srFileReader As System.IO.StreamReader
        Dim srFileWrite As System.IO.StreamWriter
        Dim sMap As String
        Dim sOut As String
        Dim sToMap As String
        Dim i As Integer
        Dim j As Integer
        Dim iX As Integer
        Dim iY As Integer
        Dim strMap As String
        Dim strMap2 As String
        Dim strMap3 As String
        If iRowFrom > -1 Then
            DGrid.Item(4, iRowFrom).Value() = TxtName.Text
            cMyFilein = DGrid.Item(0, iRowFrom).Value()
            cFile = My.Application.Info.DirectoryPath & "\Maps\" & cMyFilein & "p.txt"
            srFileReader = System.IO.File.OpenText(cFile)
            strMap = srFileReader.ReadLine()
            strMap2 = srFileReader.ReadLine()
            strMap3 = srFileReader.ReadLine()
            srFileReader.Close()
            cFile = My.Application.Info.DirectoryPath & "\Maps\" & cMyFilein & "p.txt"
            srFileWrite = New System.IO.StreamWriter(cFile)
            srFileWrite.WriteLine(strMap)
            srFileWrite.WriteLine(strMap2)
            srFileWrite.WriteLine(strMap3)
            'cMyFilein2 = DGrid.Item(0, iRowTo).Value()
            'cMyFilein2 = My.Application.Info.DirectoryPath & "\Maps\" & FlexGrid.Text & "p.txt"
            For i = 0 To DGrid.Rows.Count - 1
                ' Label1.Text = DGrid.Item(0, i).Value()
                sMap = DGrid.Item(0, i).Value()
                If cMyFilein = sMap Then
                    '    FlexGrid.Col = 2
                    iX = DGrid.Item(2, i).Value() - 3
                    '    FlexGrid.Col = 3
                    iY = DGrid.Item(3, i).Value() - 3
                    '    FlexGrid.Col = 4
                    sToMap = DGrid.Item(4, i).Value()
                    If Mid(sToMap, Len(sToMap), 1) <> ":" Then sToMap = sToMap & ":"
                    sOut = Format(iX, "0000") & Format(iY, "0000") & "00000000" & sToMap
                    srFileWrite.WriteLine(sOut)
                    '    sToMap = FlexGrid.Text & ":"
                End If
            Next
            srFileWrite.Close()
            LblSave.Text = "People saved for " & cMyFilein
        End If
    End Sub

   

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cFile As String
        Dim PositionMap As String
        Dim strMapName As String
        TxtName.Text = ""
        TxtName.Visible = True
        DGrid.Width = 355
        Button8.Visible = False
        iRowFrom = -1
        sWFrom = ""
        sWTo = ""
        LblTitle.Text = "People"
        Label1.Text = "Click person at add name"
        Label2.Text = ""
        LblMap1.Text = ""
        LblMap2.Text = ""
        DGrid.Enabled = True
        Dgrid2.Enabled = True
        cButton = "PEOPLE"
        iMapReadIn = 0
        iGcnt = 0
        CmdConnect.Visible = False
        CmdName.Visible = True
        bFix = False
        bChest = False
        'FlexGrid.Clear()
        'FlexGrid2.Clear()
        Dgrid2.Visible = False
        LblTo.Text = "Name"
        TxtName.Visible = True
        'FlexGrid.Cols = 1
        DGrid.Rows.Clear()
        DGrid.Columns.Clear()
        'FlexGrid.FormatString = "Map |Type       |X  |Y  |Name          "
        DGrid.ColumnCount = 5
        DGrid.Columns(0).Name = "Map."
        DGrid.Columns(0).Width = 45
        DGrid.Columns(1).Name = "Type..."
        DGrid.Columns(1).Width = 40
        DGrid.Columns(2).Name = "X..."
        DGrid.Columns(2).Width = 25
        DGrid.Columns(3).Name = "Y..."
        DGrid.Columns(3).Width = 25
        DGrid.Columns(4).Name = "Name................."
        'DGrid.Columns(5).Name = "Cost"
        'FlexGrid.Rows = 1
        For i = 0 To ListBox1.Items.Count - 1
            strMapName = Mid(ListBox1.Items(i).ToString, 1, Len(ListBox1.Items(i).ToString) - 4)
            cFile = My.Application.Info.DirectoryPath & "\Maps\" & strMapName & "d.txt"
            iMapReadIn = -1
            bDark = False
            Call ReadMapFile(strMapName)
            ReadDoorFile(strMapName)
            'cFile2 = App.Path & "\Maps\" & strMapName & ".2ap"
            '     Open cFile For Input As #1 '
            '            'Open cFile2 For Input As #2
            iTileloc = m144
            For Each doors In nDoors
                If doors.Mytype = "TALK" Then
                    PositionMap = Mid(Map(doors.DooriY + 3), (doors.DooriX + 3), 1) & Mid(Map2(doors.DooriY + 3), (doors.DooriX + 3), 1)
                    For Each cTile In nTiles
                        If cTile.TileLet = PositionMap Then
                            iTileloc = cTile.MyTileCnt + m144
                        End If
                    Next
                    ' FlexGrid.AddItem(strMapName & vbTab & PB(iTileloc).Tag & vbTab & doors.DooriX + 3 & vbTab & doors.DooriY + 3 _
                    '   & vbTab & doors.Name)
                    DGrid.Rows.Insert(iGcnt, New String() {strMapName, PB(iTileloc).Tag, doors.DooriX + 3, _
                                          doors.DooriY + 3, doors.Name})
                    iGcnt = iGcnt + 1
                    ' FlexGrid2.AddItem(strMapName & vbTab & PB(iTileloc).Tag & vbTab & doors.DooriX + 3 & vbTab & doors.DooriY + 3 _
                    '      & vbTab & doors.Name)
                    'Dgrid2.Rows.Insert(iGcnt2, New String() {strMapName, PB(iTileloc).Tag, doors.DooriX + 3, doors.DooriY + 3,
                    '                        doors.Name})
                    'iGcnt2 = iGcnt2 + 1
                End If
            Next

        Next
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TxtName.Text = ""
        TxtName.Visible = False
        CmdName.Visible = False
        Button8.Visible = False
        LblMap2.Left = 573 ', 111
        LblMap2.Top = 111
        LblMap2.Text = ""
        CmdConnect.Visible = True
        iRowFromOld = -1
        CmdConnect.Text = "Update Chest"
        sWFrom = ""
        sWTo = ""
        Chest()
        Dgrid2.Visible = True
    End Sub

    'Private Sub FlexGrid2_ClickEvent(ByVal sender As Object, ByVal e As System.EventArgs)
    '    'Dim i As Integer
    '    'Dim j As Integer
    '    'Dim l As Integer
    '    'l = 3
    '    'If LblTitle.Text = "Chest" Then l = 1
    '    'If FlexGrid2.MouseRow = 0 Then Exit Sub
    '    'iRowTo = FlexGrid2.MouseRow
    '    'For i = 1 To FlexGrid2.Rows - 1
    '    '    FlexGrid2.Row = i
    '    '    For j = 0 To l
    '    '        FlexGrid2.Col = j
    '    '        FlexGrid2.CellBackColor = Color.White
    '    '    Next
    '    'Next
    '    'If LblTitle.Text = "Chest" Then
    '    '    FlexGrid2.Row = iRowTo
    '    '    FlexGrid2.Col = 0
    '    '    FlexGrid2.CellBackColor = Color.Yellow
    '    '    FileTile = My.Application.Info.DirectoryPath & "\tiles\" & FlexGrid2.Text & ".bmp"
    '    '    PB(66).Image = Image.FromFile(FileTile)
    '    '    LblMap2.Text = FlexGrid2.Text
    '    '    'FlexGrid.Row = iRowFrom
    '    '    'FlexGrid.Col = 1
    '    '    'FlexGrid.Text = UCase(FlexGrid2.Text)
    '    '    DGrid.Item(1, iRowFrom).Value() = UCase(FlexGrid2.Text)
    '    '    FlexGrid2.Col = 1
    '    '    FlexGrid2.CellBackColor = Color.Yellow
    '    'End If
    '    'If LblTitle.Text = "Door" Then Call Fgrid2()
    'End Sub



    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim i As Integer
        Dim j As Integer
        Dim l As Integer
        Dim k As Integer
        Dim sGrid As String
        'RedoFiles()
        For l = 0 To 100
            iBunnylocX(l) = 0
            iBunnylocY(l) = 0
        Next
        Button8.Visible = False
        DGrid.Width = 785
        bFix = False
        LblTitle.Text = "Quest"
        cButton = "QUEST"
        Label1.Text = "Quest"
        Label2.Text = ""
        DGrid.Enabled = True
        Dgrid2.Enabled = True
        bChest = True
        iMapReadIn = 0
        iGcnt = 0
        CmdConnect.Visible = False
        CmdName.Visible = False
        Dgrid2.Visible = False
        ' FlexGrid.Rows = 1
        'FlexGrid.Cols = 1
        'FlexGrid.FormatString = "Map  |#    |Name                                   |Person      |EndMap|EndName          "       '
        DGrid.Rows.Clear()
        DGrid.Columns.Clear()
        DGrid.ColumnCount = 6
        DGrid.Columns(0).Name = "Map.."
        DGrid.Columns(0).Width = 40
        DGrid.Columns(1).Name = "#...."
        DGrid.Columns(1).Width = 40
        DGrid.Columns(2).Name = "Description....................."
        DGrid.Columns(2).Width = 250
        DGrid.Columns(3).Name = "Person.............."
        DGrid.Columns(4).Name = "EndMap."
        DGrid.Columns(5).Name = "EndName....."
        k = 1
        For j = 1 To 2
            For i = 0 To ListBox1.Items.Count - 1
                cFile = Mid(ListBox1.Items(i).ToString, 1, Len(ListBox1.Items(i).ToString) - 4)
                ReadSpeech(cFile)
                For Each speech In nSpeech
                    If j = 1 Then
                        If speech.QuestName <> "" Then
                            l = speech.StartQuest
                            iBunnylocX(l) = i + 1
                            iBunnylocY(l) = k
                            'FlexGrid.AddItem(cFile & vbTab & speech.StartQuest & vbTab & speech.QuestName & vbTab & speech.Name)

                            DGrid.Rows.Insert(iGcnt, New String() {cFile, speech.StartQuest, speech.QuestName, speech.Name})
                            iGcnt = iGcnt + 1
                            'FlexGrid.AddItem cFile & vbTab & "S-" & speech.StartQuest & vbTab & speech.QuestName & vbTab & speech.Name
                            k = k + 1
                            'Exit Sub
                        End If
                    Else
                        If speech.EndQuest <> "" And speech.EndQuest <> "0" Then
                            l = speech.EndQuest
                            If iBunnylocX(l) > 0 Then
                                ' FlexGrid.Row = iBunnylocY(l)
                                ' FlexGrid.Col = 4
                                'FlexGrid.Text = cFile
                                sGrid = cFile
                                DGrid.Item(4, iBunnylocY(l) - 1).Value() = cFile
                                ' DGrid.Item(4, iBunnylocY(l)).Value() = cFile
                                'FlexGrid.Col = 5
                                'FlexGrid.Text = speech.Name
                                DGrid.Item(5, iBunnylocY(l) - 1).Value() = speech.Name
                            Else
                                ' FlexGrid.AddItem("??" & vbTab & "??" & vbTab & "??" & vbTab & "??" & vbTab & cFile & vbTab & speech.Name)
                                DGrid.Rows.Insert(iGcnt, New String() {"??", "??", "??", "??", cFile, speech.Name})
                                iGcnt = iGcnt + 1
                            End If

                        End If
                    End If
                Next
            Next
        Next
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim i As Integer
        Dim j As Integer
        Dim iStart As Integer
        Dim sShowItem As String
        Dim k As Integer
        Dim l2 As Integer
        TxtName.Text = ""
        TxtName.Visible = False
        Chest()
        bFix = False
        LblTitle.Text = "Given to you"
        Label1.Text = "Give"
        Label2.Text = ""
        cButton = "Give"
        bChest = True
        iMapReadIn = 0
        CmdConnect.Visible = False
        DGrid.Enabled = True
        Dgrid2.Enabled = True
        CmdName.Visible = False
        Dgrid2.Visible = False
        'FlexGrid.Rows = 1
        'FlexGrid.Cols = 1
        'FlexGrid.FormatString = "Name |Item                |Name                   "
        iGcnt = 0
        DGrid.ColumnCount = 4
        DGrid.Columns(0).Name = "Map....."
        DGrid.Columns(0).Width = 40
        DGrid.Columns(1).Name = "Item..............."
        DGrid.Columns(1).Width = 140
        DGrid.Columns(2).Name = "Qty........"
        DGrid.Columns(2).Width = 40
        DGrid.Columns(3).Name = "Name........"
        For i = 0 To ListBox1.Items.Count - 1
            cFile = Mid(ListBox1.Items(i).ToString, 1, Len(ListBox1.Items(i).ToString) - 4)
            ReadSpeech(cFile)
            ReadDoorFile(cFile)
            If Len(sStoreItems) > 16 Then
                iStart = 17
                For l = 1 To 4
                    j = InStr(iStart, sStoreItems, ";")
                    sShowItem = ""
                    k = j - iStart
                    If j > 0 And k > 0 Then sShowItem = Mid(sStoreItems, iStart, j - iStart)
                    If sShowItem <> "" Then
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\" & sShowItem & ".bmp"
                        'FlexGrid.AddItem(cFile & vbTab & sShowItem & vbTab & "01" & vbTab & "Store")
                        DGrid.Rows.Insert(iGcnt, New String() {cFile, sShowItem, "01", "Store"})
                        iGcnt = iGcnt + 1
                    End If
                    j = j + 1
                    iStart = j
                    l2 = InStr(iStart, sStoreItems, ";")
                    If l2 = 0 Then Exit For
                Next

            End If
            For Each speech In nSpeech
                If speech.Give <> "" Then
                    'FlexGrid.AddItem(cFile & vbTab & speech.Give & vbTab & speech.GiveQty & vbTab & speech.Name)
                    DGrid.Rows.Insert(iGcnt, New String() {cFile, speech.Give, speech.GiveQty, speech.Name})
                    iGcnt = iGcnt + 1
                    j = InStr(1, UCase(speech.Give), "BADGE")
                    If j > 0 Then
                        iBadgecnt = iBadgecnt + 1
                        sBadge(iBadgecnt) = Mid(speech.Give, 1, Len(speech.Give) - 5)
                    End If
                End If
            Next
            iMapReadIn = -1
            bDark = False
            Call ReadMapFile(cFile)
            For k = 1 To 100
                If Len(Map3(k)) > 5 Then
                    For j = 1 To Len(Map(i))
                        sShowItem = Mid(Map3(k), j, 1) & Mid(Map4(k), j, 1)
                        For Each cTile In nTiles
                            If cTile.TileLet = sShowItem And cTile.TileType = "ITEM" Then
                                'FlexGrid.AddItem(cFile & vbTab & cTile.TileName & vbTab & "01" & vbTab & "Hidden")
                                DGrid.Rows.Insert(iGcnt, New String() {cFile, cTile.TileName, "01", "Hidden"})
                                iGcnt = iGcnt + 1
                            End If
                        Next
                    Next
                End If
            Next
        Next
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim i As Integer
        Dim j As Integer
        DGrid.Width = 455
        Button8.Visible = False
        bFix = False
        LblTitle.Text = "Needed by people"
        Label1.Text = "Need"
        Label2.Text = ""
        cButton = "NEED"
        bChest = True
        iMapReadIn = 0
        CmdConnect.Visible = False
        DGrid.Enabled = True
        Dgrid2.Enabled = True
        CmdName.Visible = False
        Dgrid2.Visible = False
        'FlexGrid.Rows = 1
        'FlexGrid.Cols = 1
        'FlexGrid.FormatString = "From |Item         |Qty   |Name               "
        iGcnt = 0
        DGrid.Rows.Clear()
        DGrid.Columns.Clear()
        DGrid.ColumnCount = 4
        DGrid.Columns(0).Name = "From..."
        DGrid.Columns(1).Name = "Item....."
        DGrid.Columns(2).Name = "Qty..."
        DGrid.Columns(3).Name = "Name.........."
        'DGrid.Columns(4).Name = "Doors"
        'DGrid.Columns(5).Name = "Cost"
        For i = 0 To ListBox1.Items.Count - 1
            cFile = Mid(ListBox1.Items(i).ToString, 1, Len(ListBox1.Items(i).ToString) - 4)
            ReadSpeech(cFile)
            For Each speech In nSpeech
                If speech.Need <> "" Then
                    ' FlexGrid.AddItem(cFile & vbTab & speech.Need & vbTab & speech.NeedQty & vbTab & speech.Name)
                    DGrid.Rows.Insert(iGcnt, New String() {cFile, speech.Need, speech.NeedQty,speech.Name})
                    iGcnt = iGcnt + 1
                    j = InStr(1, UCase(speech.Need), "BADGE")
                    If j > 0 Then
                        iBadgecnt = iBadgecnt + 1
                        sBadge(iBadgecnt) = Mid(speech.Need, 1, Len(speech.Need) - 5)
                    End If
                End If
            Next
        Next
    End Sub

    Private Sub CmdConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdConnect.Click
        Dim i As Integer
        Dim srFileWrite As System.IO.StreamWriter
        Dim srFileReader As System.IO.StreamReader
        Dim sOut As String
        Dim j As Integer
        Dim l As Integer
        Dim iX As Integer
        Dim iY As Integer
        Dim iToX As Integer
        Dim iToY As Integer
        Dim sToMap As String
        Dim strMap As String
        Dim sTag1 As String
        Dim sTag2 As String
        Dim sTag3 As String
        Dim cMyFilein As String
        Dim cMyFilein2 As String
        Dim sSave(2000) As String
        If cButton = "Chest" And sWFrom <> "" Then
            cFile = My.Application.Info.DirectoryPath & "\Maps\" & sWFrom & "p.txt"
            srFileReader = System.IO.File.OpenText(cFile)
            sTag1 = srFileReader.ReadLine()
            sTag2 = srFileReader.ReadLine()
            sTag3 = srFileReader.ReadLine()
            RichTextBox1.Text = ""
            strMap = srFileReader.ReadLine()
            Do While (Not strMap Is Nothing)
                RichTextBox1.Text = RichTextBox1.Text & strMap & vbCrLf
                strMap = srFileReader.ReadLine()
            Loop
            srFileReader.Close()
            ' FlexGrid.Row = iRowFrom
            ' FlexGrid.Col = 1
            ' sTag3 = "Chest:" & FlexGrid.Text
            sTag3 = "Chest:" & DGrid.Item(1, iRowFrom).Value()
            srFileWrite = New System.IO.StreamWriter(cFile)
            srFileWrite.WriteLine(sTag1)
            srFileWrite.WriteLine(sTag2)
            srFileWrite.WriteLine(sTag3)
            srFileWrite.WriteLine(RichTextBox1.Text)
            srFileWrite.Close()
            Exit Sub
        End If
        If cButton = "DOOR" Then
            If iRowFrom > -1 And iRowTo > -1 Then
                cMyFilein = ""
                cMyFilein2 = ""
                For j = 1 To 2
                    If j = 1 Then
                        cMyFilein2 = My.Application.Info.DirectoryPath & "\Maps\" & sWFrom & "d.txt"
                    Else
                        cMyFilein2 = My.Application.Info.DirectoryPath & "\Maps\" & sWTo & "d.txt"
                    End If
                    srFileWrite = New System.IO.StreamWriter(cMyFilein2)
                    srFileWrite.WriteLine("xxxxyyyyNewxNewy")
                    For i = 0 To DGrid.Rows.Count - 1
                        If j = 1 And sWFrom = DGrid.Item(0, i).Value() Or j = 2 And sWTo = DGrid.Item(0, i).Value() Then
                            '        FlexGrid.Col = 2
                            iX = DGrid.Item(2, i).Value() - 3
                            '        FlexGrid.Col = 3
                            iY = DGrid.Item(3, i).Value() - 3
                            '        FlexGrid.Col = 4
                            sToMap = DGrid.Item(4, i).Value()
                            '        FlexGrid.Col = 5
                            iToX = -1
                            If DGrid.Item(5, i).Value() > 0 Then iToX = DGrid.Item(5, i).Value() - 3
                            iToY = -1
                            If DGrid.Item(6, i).Value() > 0 Then iToY = DGrid.Item(6, i).Value() - 3
                            sOut = Format(iX, "0000") & Format(iY, "0000") & Format(iToX, "0000") & Format(iToY, "0000") & sToMap
                            srFileWrite.WriteLine(sOut)
                            iToX = -1
                        End If
                    Next
                    srFileWrite.Close()
                Next
                LblSave.Text = "Door Saved map1=" & sWFrom & " map2=" & sWTo
            End If
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        FrmEdit.ShowDialog()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        If SAVE_MapLoaded <> "" Then FrmSpeech2.ShowDialog()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        FrmCopy.Show()
    End Sub

    Private Sub BtnPlay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPlay.Click
        ' FrmWelcome.Show()
        Form1.Show()
    End Sub

    Private Sub DGrid_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGrid.CellClick
        Dim i As Integer
        Dim j As Integer
        Dim sItemName As String
        If e.RowIndex < 0 Then Exit Sub
        ' Dim strMapName As String
        'FlexGrid.Col = 0
        'FlexGrid.Row = FlexGrid.MouseRow
        LblMap1.Text = "Map= " & DGrid.Item(0, e.RowIndex).Value() 'FlexGrid.Text
        SAVE_MapLoaded = DGrid.Item(0, e.RowIndex).Value() 'FlexGrid.Text
        Button8.Visible = True
        iMapReadIn = 0
        iRowFrom = e.RowIndex 'FlexGrid.MouseRow
        Select Case LblTitle.Text
            Case "Door"
                FGrid()
            Case "People"
                FGrid()
                TxtName.Text = DGrid.Item(4, e.RowIndex).Value()
            Case "Chest"
                ' FGrid()
                'FlexGrid.Row = iRowFrom
                'FlexGrid.Col = 0
                ' sWFrom = FlexGrid.Text
                sWFrom = DGrid.Item(0, iRowFrom).Value()
                'For j = 0 To 3
                '    FlexGrid.Col = j
                '    FlexGrid.CellBackColor = Color.Yellow
                'Next
                DGrid.Item(0, iRowFrom).Style.BackColor = Color.Yellow
                DGrid.Item(1, iRowFrom).Style.BackColor = Color.Yellow
                DGrid.Item(2, iRowFrom).Style.BackColor = Color.Yellow
                If iRowFromOld > -1 Then
                    DGrid.Item(0, iRowFromOld).Style.BackColor = Color.White
                    DGrid.Item(1, iRowFromOld).Style.BackColor = Color.White
                    DGrid.Item(2, iRowFromOld).Style.BackColor = Color.White
                    DGrid.Item(3, iRowFromOld).Style.BackColor = Color.White
                End If
                iRowFromOld = iRowFrom
                For i = 1 To Dgrid2.Rows.Count - 1
                    '.FlexGrid2.Row = i
                    For j = 0 To Dgrid2.ColumnCount - 1 ' FlexGrid2.Cols - 1
                        'FlexGrid2.Col = j
                        'FlexGrid2.CellBackColor = Color.White
                        Dgrid2.Item(j, i).Style.BackColor = Color.White
                    Next
                Next
                'FlexGrid.Col = 1
                sItemName = DGrid.Item(1, iRowFrom).Value()
                '  i = 1
                For i = 0 To Dgrid2.Rows.Count - 1
                    'FlexGrid2.Row = i
                    'FlexGrid2.Col = 0
                    'sWFrom=
                    'If FlexGrid.Text = UCase(FlexGrid2.Text) Then
                    ' If UCase(DGrid.Item(1, iRowFrom).Value()) = UCase(FlexGrid2.Text) Then
                    If UCase(DGrid.Item(1, iRowFrom).Value()) = UCase(Dgrid2.Item(0, i).Value()) Then
                        ' FlexGrid2.Col = 0
                        'FlexGrid2.CellBackColor = Color.Yellow
                        Dgrid2.Item(0, i).Style.BackColor = Color.Yellow
                        Dgrid2.Item(1, i).Style.BackColor = Color.Yellow
                        'FileTile = My.Application.Info.DirectoryPath & "\tiles\" & FlexGrid2.Text & ".bmp"
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\" & Dgrid2.Item(0, i).Value() & ".bmp"
                        j = InStr(UCase(Dgrid2.Item(0, i).Value()), "BADGE")
                        If j > 1 Then
                            FileTile = My.Application.Info.DirectoryPath & "\Images\badges\" & Mid(Dgrid2.Item(0, i).Value(), 6, Len(Dgrid2.Item(0, i).Value()) - 5) & ".gif"
                        End If
                        PB(66).Image = Image.FromFile(FileTile)
                        LblMap2.Text = Dgrid2.Item(0, i).Value()
                    End If

                Next
                'j = InStr(UCase(FlexGrid.Text), "BADGE")
                'If j > 0 Then
                '    FileTile = My.Application.Info.DirectoryPath & "\Images\badges\" & Mid(FlexGrid.Text, 6, Len(FlexGrid.Text) - 5) & ".gif"
                '    PB(66).Image = Image.FromFile(FileTile)
                '    LblMap2.Text = FlexGrid.Text
                'End If
                Exit Sub

        End Select
    End Sub


    Private Sub Dgrid2_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dgrid2.CellClick
        Dim i As Integer
        Dim j As Integer
        Dim l As Integer
        l = 3
        If e.RowIndex < 0 Then Exit Sub
        If LblTitle.Text = "Chest" Then l = 1
        iRowTo = e.RowIndex 'FlexGrid.MouseRow
        For i = 1 To Dgrid2.Rows.Count - 1
            ' FlexGrid2.Row = i
            For j = 0 To l
                'FlexGrid2.Col = j
                'FlexGrid2.CellBackColor = Color.White
                Dgrid2.Item(j, i).Style.BackColor = Color.White
            Next
        Next
        If LblTitle.Text = "Chest" Then
            Dgrid2.Item(0, iRowTo).Style.BackColor = Color.Yellow
            FileTile = My.Application.Info.DirectoryPath & "\tiles\" & Dgrid2.Item(0, iRowTo).Value() & ".bmp"
            PB(66).Image = Image.FromFile(FileTile)
            LblMap2.Text = Dgrid2.Item(0, iRowTo).Value()
            'FlexGrid.Row = iRowFrom
            'FlexGrid.Col = 1
            'FlexGrid.Text = UCase(FlexGrid2.Text)
            DGrid.Item(1, iRowFrom).Value() = UCase(Dgrid2.Item(0, iRowTo).Value())
            'FlexGrid2.Col = 1
            'FlexGrid2.CellBackColor = Color.Yellow
            Dgrid2.Item(j, iRowTo).Style.BackColor = Color.Yellow
        End If
        If LblTitle.Text = "Door" Then
            Call Fgrid2()
            If iRowFrom < 0 Then Exit Sub
            If iRowTo < 0 Then Exit Sub
            DGrid.Item(4, iRowFrom).Value() = Dgrid2.Item(0, iRowTo).Value()
            DGrid.Item(5, iRowFrom).Value() = Dgrid2.Item(2, iRowTo).Value()
            DGrid.Item(6, iRowFrom).Value() = Dgrid2.Item(3, iRowTo).Value()
            DGrid.Item(4, iRowFrom).Style.BackColor = Color.Aqua
            DGrid.Item(5, iRowFrom).Style.BackColor = Color.Aqua
            DGrid.Item(6, iRowFrom).Style.BackColor = Color.Aqua
            Dgrid2.Item(4, iRowFrom).Value() = Dgrid2.Item(0, iRowTo).Value()
            Dgrid2.Item(5, iRowFrom).Value() = Dgrid2.Item(2, iRowTo).Value()
            Dgrid2.Item(6, iRowFrom).Value() = Dgrid2.Item(3, iRowTo).Value()
            Dgrid2.Item(4, iRowFrom).Style.BackColor = Color.Aqua
            Dgrid2.Item(5, iRowFrom).Style.BackColor = Color.Aqua
            Dgrid2.Item(6, iRowFrom).Style.BackColor = Color.Aqua
            DGrid.Item(4, iRowTo).Value() = DGrid.Item(0, iRowFrom).Value()
            DGrid.Item(5, iRowTo).Value() = DGrid.Item(2, iRowFrom).Value()
            DGrid.Item(6, iRowTo).Value() = DGrid.Item(3, iRowFrom).Value()
            DGrid.Item(0, iRowTo).Style.BackColor = Color.Aqua
            DGrid.Item(1, iRowTo).Style.BackColor = Color.Aqua
            DGrid.Item(2, iRowTo).Style.BackColor = Color.Aqua
            DGrid.Item(3, iRowTo).Style.BackColor = Color.Aqua
            DGrid.Item(4, iRowTo).Style.BackColor = Color.Aqua
            DGrid.Item(5, iRowTo).Style.BackColor = Color.Aqua
            DGrid.Item(6, iRowTo).Style.BackColor = Color.Aqua
            Dgrid2.Item(4, iRowTo).Value() = DGrid.Item(0, iRowFrom).Value()
            Dgrid2.Item(5, iRowTo).Value() = DGrid.Item(2, iRowFrom).Value()
            Dgrid2.Item(6, iRowTo).Value() = DGrid.Item(3, iRowFrom).Value()
            Dgrid2.Item(4, iRowTo).Style.BackColor = Color.Aqua
            Dgrid2.Item(5, iRowTo).Style.BackColor = Color.Aqua
            Dgrid2.Item(6, iRowTo).Style.BackColor = Color.Aqua
            CmdConnect.Visible = True
        End If
    End Sub

    Private Sub Dgrid2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dgrid2.CellContentClick

    End Sub

    Private Sub DGrid_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGrid.CellContentClick

    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        SAVE_MapLoaded = "a1"
        FrmSpeech2.Show()
    End Sub

    Private Sub CmnHidden_Click(sender As Object, e As EventArgs) Handles CmnHidden.Click
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        Dim k1 As Integer
        Dim sMyHide As String
        Dim strMapName As String
        DGrid.Width = 455
        Button8.Visible = False
        ReadTilesItem()
        bFix = False
        LblTitle.Text = "Item Hidden"
        Label1.Text = "Hidden"
        Label2.Text = ""
        cButton = "Hidden"
        CmdConnect.Visible = False
        DGrid.Enabled = True
        Dgrid2.Enabled = True
        CmdName.Visible = False
        Dgrid2.Visible = False
        'FlexGrid.Rows = 1
        'FlexGrid.Cols = 1
        'FlexGrid.FormatString = "Name |Item                |Name                   "
        iGcnt = 0
        DGrid.ColumnCount = 2
        DGrid.Columns(0).Name = "Map....."
        DGrid.Columns(0).Width = 50
        DGrid.Columns(1).Name = "Item..............."
        For j = 0 To ListBox1.Items.Count - 1
            strMapName = Mid(ListBox1.Items(j).ToString, 1, Len(ListBox1.Items(j).ToString) - 4)
            cFile = My.Application.Info.DirectoryPath & "\Maps\" & strMapName & "d.txt"
            iMapReadIn = -1
            bDark = False
            Call ReadMapFile(strMapName)
            For i = 0 To 99
                For k = 1 To Len(Map3(i))
                    sMyHide = Mid(Map3(i), k, 1) & Mid(Map4(i), k, 1)
                    If Len(sMyHide) < 1 Then Exit For
                    k1 = InStr(1, sImaster, sMyHide)
                    If k1 > 0 Then
                        For Each cTile In nTiles
                            If cTile.TileLet = sMyHide Then
                                DGrid.Rows.Insert(iGcnt, New String() {strMapName, cTile.TileName})
                                iGcnt = iGcnt + 1
                            End If
                        Next
                    End If
                Next
                '    Map4(i) = ""
                '    Map4(i) = ""
                '    Map(i) = ""
                '    Map2(i) = ""
                '    Map3(i) = ""
                '    Map4(i) = ""
            Next
            Next
    End Sub
End Class