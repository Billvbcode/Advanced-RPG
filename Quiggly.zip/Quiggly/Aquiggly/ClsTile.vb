﻿Public Class ClsTile
    Private strTileName As String
    Private strTileAddName As String
    Private strTileLet As String
    Private strTileOldLet As String
    Private strTileType As String
    Private iMyTileCnt As Integer
    Public Property MyTileCnt() As Integer       ' Melt time
        Get
            Return iMyTileCnt
        End Get
        Set(ByVal Value As Integer)
            iMyTileCnt = Value
        End Set
    End Property
    Public Property TileType() As String      'Foe Description
        Get
            Return strTileType
        End Get
        Set(ByVal Value As String)
            strTileType = Value
        End Set
    End Property
    Public Property TileOldLet() As String      'Foe Description
        Get
            Return strTileOldLet
        End Get
        Set(ByVal Value As String)
            strTileOldLet = Value
        End Set
    End Property
    Public Property TileLet() As String      'Foe Description
        Get
            Return strTileLet
        End Get
        Set(ByVal Value As String)
            strTileLet = Value
        End Set
    End Property

    Public Property TileAddName() As String      'Foe Description
        Get
            Return strTileAddName
        End Get
        Set(ByVal Value As String)
            strTileAddName = Value
        End Set
    End Property
    Public Property TileName() As String      'Foe Description
        Get
            Return strTileName
        End Get
        Set(ByVal Value As String)
            strTileName = Value
        End Set
    End Property
End Class
