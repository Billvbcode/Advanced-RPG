﻿Module Mopoko2
    Public evolutionIndex As Integer
    Public iBunnylocX(100) As Integer
    Public iBunnylocY(100) As Integer
    Public iBunnylocD(100) As Integer
    Public Sub FindBunnies()
        Dim i As Integer
        Dim j As Integer
        Dim PositionMap As String
        '
        ' Check for bunnies
        '
        iBunny = 0
        For i = 1 To 99
            If Len(Map(i)) > 5 Then
                For j = 1 To Len(Map(i))
                    PositionMap = Mid(Map(i), j, 1) & Mid(Map2(i), j, 1)
                    If sBunny = PositionMap Then
                        iBunny = iBunny + 1
                        iBunnylocX(iBunny) = j - 3
                        iBunnylocY(iBunny) = i - 3
                        iBunnylocD(iBunny) = 1
                    End If
                Next
            End If
        Next
    End Sub
    Public Sub CheckFiles(ByVal cMapfile As String)
        Dim MyFile As String
        '
        'Doors
        '
        MyFile = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "d.txt"
        If System.IO.File.Exists(MyFile) Then
        Else
            ' My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "d.txt"
            Dim srFileWrite As New System.IO.StreamWriter(MyFile)
            srFileWrite.WriteLine("xxxxyyyyNewxNewy")
            srFileWrite.WriteLine("")
            srFileWrite.Close()
        End If
        '
        'People
        '
        MyFile = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "p.txt"
        If System.IO.File.Exists(MyFile) Then
        Else
            ' My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "d.txt"
            Dim srFileWrite2 As New System.IO.StreamWriter(MyFile)
            srFileWrite2.WriteLine("NORMAL")
            srFileWrite2.WriteLine("0000000000000000")
            srFileWrite2.WriteLine(" ")
            srFileWrite2.Close()
        End If
        '
        'Speech
        '
        MyFile = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "s.txt"
        If System.IO.File.Exists(MyFile) Then
        Else
            ' My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "d.txt"
            Dim srFileWrite3 As New System.IO.StreamWriter(MyFile)
            srFileWrite3.WriteLine(" ")
            srFileWrite3.Close()
        End If
        '
        'Fix
        '
        MyFile = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "f.txt"
        If System.IO.File.Exists(MyFile) Then
        Else
            ' My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "d.txt"
            Dim srFileWrite4 As New System.IO.StreamWriter(MyFile)
            srFileWrite4.WriteLine(" ")
            srFileWrite4.Close()
        End If
    End Sub

    Public Sub SaveMapFile(ByVal cMapfile As String)
        '
        ' Save MapFile
        '
        Dim i As Integer
        Dim MYFILE As String
        Dim Myfilein As String
        Dim value As String = My.Application.Info.DirectoryPath
        Dim j As Integer
        Myfilein = value & "\" & strChrName & ".qst"
        MYFILE = value & "\Maps\" & cMapfile & ".1ap"
        Dim srFileWrite As New System.IO.StreamWriter(MYFILE)

        For i = 0 To 100
            If Len(Map(i)) > 5 Then
                srFileWrite.WriteLine(Map(i))
                srFileWrite.WriteLine(Map2(i))
            End If
        Next
        srFileWrite.Close()
        '
        '
        MYFILE = value & "\Maps\" & cMapfile & ".2ap"
        Dim srFileWrite2 As New System.IO.StreamWriter(MYFILE)
        For i = 0 To 100
            If Len(Map(i)) > 5 Then
                srFileWrite2.WriteLine(Map3(i))
                srFileWrite2.WriteLine(Map4(i))
            End If
        Next
        srFileWrite2.Close()
       
    End Sub
    Function showFrmEvolve()
        frmEvolve2.lblCongrats.Text = "Congratulations. Your " & preEvolutionName & " evolved into " & evolutionName
        FileTile = My.Application.Info.DirectoryPath & "\Images\PokemonPics\" & preEvolutionName & ".gif"
        frmEvolve2.imgPre.Image = Image.FromFile(FileTile)
        FileTile = My.Application.Info.DirectoryPath & "\Images\PokemonPics\" & evolutionName & ".gif"
        frmEvolve2.imgNow.Image = Image.FromFile(FileTile)
        frmEvolve2.lblPre.Text = preEvolutionName
        frmEvolve2.LblNow.Text = evolutionName
        frmEvolve2.ShowDialog()
        For Each poko In nPoko
            If preEvolutionName = poko.Name Then
                poko.Name = evolutionName
                Exit For
            End If
        Next

    End Function
    Public Sub pokedexPart2(ByVal pkmn, ByVal args)
        Dim attacks() As String = {"dog", "cat", "fish"}
        Select Case pkmn
            'Seadra
            Case "Seadra"
                attacks = {"Water Gun", "Bubble Beam", "Quick Attack", "Body Slam"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Fearow
            Case "Fearow"
                attacks = {"Peck", "Drill Peck", "Brave Bird", "Aerial Ace"}
                Type1 = "Flying"
                Type2 = "Flying"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Electabuzz
            Case "Electabuzz"
                attacks = {"Thunder Punch", "Thunder Bolt", "HeadBut", "Spark"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Electivire
            Case "Electivire"
                attacks = {"Thunder Punch", "Thunder", "HeadBut", "Charge Beam"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Mawile
            Case "Mawile"
                attacks = {"Crunch", "Bug Buzz", "Iron Head", "Bite"}
                Type1 = "Steel"
                Type2 = "Steel"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Ledyba
            Case "Ledyba"
                attacks = {"Whirlwind", "HeadBut", "Tackle", "Screech"}
                Type1 = "Bug"
                Type2 = "Bug"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Ledian
            Case "Ledian"
                attacks = {"Bug Buzz", "Silver Wind", "Mach Punch", "Mega Punch"}
                Type1 = "Bug"
                Type2 = "Bug"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Heracross
            Case "Heracross"
                attacks = {"Mega Punch", "Mega Horn", "Focus Blast", "Mach Punch"}
                Type1 = "Fighting"
                Type2 = "Bug"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Magneton
            Case "Magneton"
                attacks = {"Thunder Bolt", "Sonic Boom", "Charge", "Thunder Shock"}
                Type1 = "Electric"
                Type2 = "Steel"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Magnezone
            Case "Magnezone"
                attacks = {"Charge Beam", "Sonic Boom", "Zap Cannon", "Thunder"}
                Type1 = "Electric"
                Type2 = "Steel"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Jolteon
            Case "Jolteon"
                attacks = {"Thunder Bolt", "Extreme Speed", "Pin Missile", "Thunder"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Nidorino
            Case "Nidorino"
                attacks = {"Horn Attack", "Stomp", "Poison Sting", "Double Kick"}
                Type1 = "Poison"
                Type2 = "Poison"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Nidoking
            Case "Nidoking"
                attacks = {"Horn Drill", "Focus Blast", "Hyper Beam", "Earthquake"}
                Type1 = "Ground"
                Type2 = "Ground"
                runRate = 4
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Kadabra
            Case "Kadabra"
                attacks = {"Confusion", "Teleport", "Psybeam", "Future Sight"}
                Type1 = "Psychic"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Alakazam
            Case "Alakazam"
                attacks = {"Confusion", "Psychic", "Psybeam", "Psycho Boost"}
                Type1 = "Psychic"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Snorlax
            Case "Snorlax"
                attacks = {"Body Slam", "Giga Impact", "HeadBut", "Hyper Beam"}
                Type1 = "Normal"
                Type2 = "Normal"
                runRate = 4
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Celebi
            Case "Celebi"
                attacks = {"Frenzy Plant", "Psychic", "Energy Ball", "Hyper Beam"}
                Type1 = "Psychic"
                Type2 = "Grass"
                runRate = 4
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 7
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 7
                End If
                'Natu
            Case "Natu"
                attacks = {"Peck", "Quick Attack", "Future Sight", "Growl"}
                Type1 = "Flying"
                Type2 = "Psychic"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Xatu
            Case "Xatu"
                attacks = {"Psychic", "Sky Attack", "Aerial Ace", "Wing Attack"}
                Type1 = "Flying"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Houndour
            Case "Houndour"
                attacks = {"Ember", "Bite", "Tail Whip", "Screech"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Houndoom
            Case "Houndoom"
                attacks = {"Flame Thrower", "Extreme Speed", "Fire Spin", "HeadBut"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Aipom
            Case "Aipom"
                attacks = {"Scratch", "Quick Attack", "Tail Whip", "Growl"}
                Type1 = "Normal"
                Type2 = "Normal"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Ambipom
            Case "Ambipom"
                attacks = {"Slash", "HeadBut", "Mach Punch", "Sky Uppercut"}
                Type1 = "Normal"
                Type2 = "Normal"
                runRate = 7
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Mareep
            Case "Mareep"
                attacks = {"Tackle", "Thunder Shock", "Cotton Spore", "Growl"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Flaaffy
            Case "Flaaffy"
                attacks = {"Thunder Shock", "HeadBut", "Thunder Punch", "Growl"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 7
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Ampharos
            Case "Ampharos"
                attacks = {"Thunder", "Thunder Bolt", "Focus Punch", "Brick Break"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 7
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Poocheyena
            Case "Poocheyena"
                attacks = {"Tackle", "Sand Attack", "Growl", "HeadBut"}
                Type1 = "Dark"
                Type2 = "Dark"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Mightyena
            Case "Mightyena"
                attacks = {"Crunch", "Extreme Speed", "Poison Fang", "Poison Tail"}
                Type1 = "Dark"
                Type2 = "Dark"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Bellsprout
            Case "Bellsprout"
                attacks = {"Vine Whip", "Poison Powder", "Stun Spore", "Leech Seed"}
                Type1 = "Grass"
                Type2 = "Poison"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Weepinbell
            Case "Weepinbell"
                attacks = {"Vine Whip", "Poison Powder", "Razor Leaf", "Leech Seed"}
                Type1 = "Grass"
                Type2 = "Poison"
                runRate = 7
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Victreebell
            Case "Victreebel"
                attacks = {"Stun Spore", "Leaf Storm", "Razor Leaf", "Thrash"}
                Type1 = "Grass"
                Type2 = "Poison"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Shieldon
            Case "Shieldon"
                attacks = {"Iron Tail", "Tackle", "Iron Head", "HeadBut"}
                Type1 = "Rock"
                Type2 = "Steel"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Bastiodon
            Case "Bastiodon"
                attacks = {"Iron Head", "Flash Cannon", "Iron Tail", "Hyper Beam"}
                Type1 = "Rock"
                Type2 = "Steel"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Cranidos
            Case "Cranidos"
                attacks = {"Rock Throw", "HeadBut", "Tackle", "Rollout"}
                Type1 = "Rock"
                Type2 = "Rock"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Rampardos
            Case "Rampardos"
                attacks = {"Stone Edge", "Rock Slide", "Double Edge", "Rock Tomb"}
                Type1 = "Rock"
                Type2 = "Rock"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Diglett
            Case "Diglett"
                attacks = {"Scratch", "Sand Attack", "Slash", "Dig"}
                Type1 = "Ground"
                Type2 = "Ground"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Dugtrio
            Case "Dugtrio"
                attacks = {"Magnitude", "Earthquake", "Slash", "Dig"}
                Type1 = "Ground"
                Type2 = "Ground"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Claydoll
            Case "Claydoll"
                attacks = {"Rock Slide", "Solar Beam", "Earhquake", "Psychic"}
                Type1 = "Rock"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Seviper
            Case "Seviper"
                attacks = {"Poison Fang", "Poison Tail", "Wrap", "Constrict"}
                Type1 = "Poison"
                Type2 = "Poison"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Swallot
            Case "Swallot"
                attacks = {"Poison Gas", "Sludge", "Body Slam", "Toxic"}
                Type1 = "Poison"
                Type2 = "Poison"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Lairon
            Case "Lairon"
                attacks = {"Rock Throw", "Iron Head", "Metal Claw", "HeadBut"}
                Type1 = "Rock"
                Type2 = "Steel"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Aggron
            Case "Aggron"
                attacks = {"Rock Slide", "Flash Cannon", "Earthquake", "Giga Impact"}
                Type1 = "Rock"
                Type2 = "Steel"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Nosepass
            Case "Nosepass"
                attacks = {"Rock Throw", "Sand Attack", "Double Edge", "Rock Tomb"}
                Type1 = "Rock"
                Type2 = "Rock"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Torkoal
            Case "Torkoal"
                attacks = {"Fire Spin", "Eruption", "Flame Thrower", "Magnitude"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Rhyhorn
            Case "Rhyhorn"
                attacks = {"Tackle", "HeadBut", "Tail Whip", "Magnitude"}
                Type1 = "Ground"
                Type2 = "Ground"
                runRate = 6
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Rhydon
            Case "Rhydon"
                attacks = {"Horn Drill", "Body Slam", "Rock Slide", "Magnitude"}
                Type1 = "Ground"
                Type2 = "Ground"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Rhyperior
            Case "Rhyperior"
                attacks = {"Horn Drill", "Giga Impact", "Hyper Beam", "Earthquake"}
                Type1 = "Ground"
                Type2 = "Ground"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Tangela
            Case "Tangela"
                attacks = {"Vine Whip", "Poison Powder", "Tackle", "Leech Seed"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Tangrowth
            Case "Tangrowth"
                attacks = {"Vine Whip", "Energy Ball", "HeadBut", "Giga Drain"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Breloom
            Case "Breloom"
                attacks = {"Mach Punch", "Focus Punch", "Solar Beam", "Razor Leaf"}
                Type1 = "Grass"
                Type2 = "Fighting"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Leafeon
            Case "Leafeon"
                attacks = {"Vine Whip", "Solar Beam", "Extreme Speed", "Mega Drain"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Roselia
            Case "Roselia"
                attacks = {"Magical Leaf", "Vine Whip", "Sleep Powder", "Stun Spore"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 7
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Roserade
            Case "Roserade"
                attacks = {"Magical Leaf", "Leaf Storm", "Sleep Powder", "Seed Bomb"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 7
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Tropius
            Case "Tropius"
                attacks = {"Magical Leaf", "Body Slam", "Solar Beam", "Aerial Ace"}
                Type1 = "Grass"
                Type2 = "Flying"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'carnivine
            Case "Carnivine"
                attacks = {"Bite", "Razor Leaf", "Crunch", "Mega Drain"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Snowver
            Case "Snowver"
                attacks = {"Pin Missile", "Mega Punch", "Powder Snow", "Mega Drain"}
                Type1 = "Grass"
                Type2 = "Ice"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Abomasnow
            Case "Abomasnow"
                attacks = {"Blizzard", "Ice Punch", "Solar Beam", "Wood Hammer"}
                Type1 = "Grass"
                Type2 = "Ice"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Crobat
            Case "Crobat"
                attacks = {"Toxic", "Poison Fang", "Giga Drain", "Wing Attack"}
                Type1 = "Poison"
                Type2 = "Flying"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Weezing
            Case "Weezing"
                attacks = {"Toxic", "Poison Fang", "Double Edge", "Sludge"}
                Type1 = "Poison"
                Type2 = "Poison"
                runRate = 7
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Nidoqueen
            Case "Nidoqueen"
                attacks = {"Thrash", "Body Slam", "Earthquake", "Poison Tail"}
                Type1 = "Poison"
                Type2 = "Ground"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Muk
            Case "Muk"
                attacks = {"Sludge", "Body Slam", "Poison Gas", "Toxic"}
                Type1 = "Poison"
                Type2 = "Poison"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Gastly
            Case "Gastly"
                attacks = {"Night Shade", "Leer", "Spite", "Hypnosis"}
                Type1 = "Dark"
                Type2 = "Ghost"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Haunter
            Case "Haunter"
                attacks = {"Lick", "Night Shade", "Shadow Ball", "Hypnosis"}
                Type1 = "Dark"
                Type2 = "Ghost"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Gengar
            Case "Gengar"
                attacks = {"Psychic", "Dark Pulse", "Shadow Ball", "Hypnosis"}
                Type1 = "Dark"
                Type2 = "Ghost"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Shuppet
            Case "Shuppet"
                attacks = {"Lick", "Bite", "Pursuit", "Night Shade"}
                Type1 = "Dark"
                Type2 = "Ghost"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Banette
            Case "Banette"
                attacks = {"Night Slash", "Shadow Ball", "Crunch", "Night Shade"}
                Type1 = "Dark"
                Type2 = "Ghost"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Duskull
            Case "Duskull"
                attacks = {"Nigh Shade", "Lick", "Curse", "Screech"}
                Type1 = "Dark"
                Type2 = "Ghost"
                runRate = 6
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Dusclops
            Case "Dusclops"
                attacks = {"Hypnosis", "Shadow Ball", "Night Slash", "Night Shade"}
                Type1 = "Dark"
                Type2 = "Ghost"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Dusknoir
            Case "Dusknoir"
                attacks = {"Hypnosis", "Shadow Ball", "Dark Pulse", "Nightmare"}
                Type1 = "Dark"
                Type2 = "Ghost"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Murkrow
            Case "Murkrow"
                attacks = {"Wing Attack", "Pursuit", "Peck", "Shadow Ball"}
                Type1 = "Dark"
                Type2 = "Fying"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Honchkrow
            Case "Honchkrow"
                attacks = {"Wing Attack", "Dark Pulse", "Aerial Ace", "Air Slash"}
                Type1 = "Dark"
                Type2 = "Fying"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Hypno
            Case "Hypno"
                attacks = {"HeadBut", "Confusion", "Hypnosis", "Psychic"}
                Type1 = "Psychic"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Espeon
            Case "Espeon"
                attacks = {"Psychic", "Confusion", "Extreme Speed", "Psybeam"}
                Type1 = "Psychic"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Gyarados
            Case "Gyarados"
                attacks = {"Thrash", "Dragon Rage", "Hyper Beam", "Hydro Pump"}
                Type1 = "Flying"
                Type2 = "Dragon"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Golduck
            Case "Golduck"
                attacks = {"Psychic", "Pound", "HeadBut", "Water Pulse"}
                Type1 = "Water"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Kingdra
            Case "Kingdra"
                attacks = {"Dragon Breath", "Dragon Rage", "Hydro Pump", "Extreme Speed"}
                Type1 = "Dragon"
                Type2 = "Dragon"
                runRate = 4
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
        End Select

        Call pokedexPart3(pkmn, args)
    End Sub
    Public Sub calculateDamage(ByVal passDamage, ByVal passType, ByVal passPkmnType1, ByVal passPkmnType2, ByVal passPkmnLvl)
        Dim kotong As Integer
        Select Case passType
            Case "Fire"

                If passPkmnType1 = "Grass" Or passPkmnType1 = "Steel" Or passPkmnType1 = "Ice" Or passPkmnType1 = "Bug" Or passPkmnType2 = "Grass" Or passPkmnType2 = "Steel" Or passPkmnType2 = "Bug" Or passPkmnType2 = "Ice" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Fire" Or passPkmnType1 = "Water" Or passPkmnType1 = "Rock" Or passPkmnType2 = "Fire" Or passPkmnType2 = "Water" Or passPkmnType2 = "Rock" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 3
                ElseIf passPkmnType1 = "Dragon" Or passPkmnType2 = "Dragon" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 4
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Normal"

                If passPkmnType1 = "Rock" Or passPkmnType1 = "Metal" Or passPkmnType2 = "Rock" Or passPkmnType2 = "Metal" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 3
                ElseIf passPkmnType1 = "Ghost" Or passPkmnType2 = "Ghost" Then
                    totalDamage = 0
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Water"

                If passPkmnType1 = "Rock" Or passPkmnType1 = "Ground" Or passPkmnType1 = "Fire" Or passPkmnType2 = "Rock" Or passPkmnType2 = "Ground" Or passPkmnType2 = "Fire" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Water" Or passPkmnType1 = "Grass" Or passPkmnType2 = "Water" Or passPkmnType2 = "Grass" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 3
                ElseIf passPkmnType1 = "Dragon" Or passPkmnType2 = "Dragon" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 4
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Grass"

                If passPkmnType1 = "Water" Or passPkmnType1 = "Rock" Or passPkmnType2 = "Ground" Or passPkmnType1 = "Ground" Or passPkmnType2 = "Water" Or passPkmnType2 = "Rock" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Fire" Or passPkmnType1 = "Poison" Or passPkmnType1 = "Flying" Or passPkmnType2 = "Fire" Or passPkmnType2 = "Poison" Or passPkmnType2 = "Flying" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 3
                ElseIf passPkmnType1 = "Dragon" Or passPkmnType2 = "Dragon" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 4
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Psychic"

                If passPkmnType1 = "Poison" Or passPkmnType1 = "Fighting" Or passPkmnType2 = "Poison" Or passPkmnType2 = "Fighting" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Bug" Or passPkmnType1 = "Psychic" Or passPkmnType2 = "Psychic" Or passPkmnType2 = "Bug" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 3
                ElseIf passPkmnType1 = "Dark" Or passPkmnType2 = "Dark" Then
                    totalDamage = 0
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Fighting"

                If passPkmnType1 = "Normal" Or passPkmnType1 = "Rock" Or passPkmnType2 = "Normal" Or passPkmnType2 = "Rock" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Psychic" Or passPkmnType1 = "Flying" Or passPkmnType2 = "Flying" Or passPkmnType2 = "Psychic" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 4
                ElseIf passPkmnType1 = "Ghost" Or passPkmnType2 = "Ghost" Then
                    totalDamage = 0
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Electric"

                If passPkmnType1 = "Water" Or passPkmnType1 = "Flying" Or passPkmnType2 = "Water" Or passPkmnType2 = "Flying" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Electric" Or passPkmnType2 = "Electric" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 3
                ElseIf passPkmnType1 = "Rock" Or passPkmnType2 = "Rock" Or passPkmnType2 = "Ground" Or passPkmnType2 = "Ground" Then
                    totalDamage = 0
                ElseIf passPkmnType1 = "Dragon" Or passPkmnType2 = "Dragon" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 4
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Steel"

                If passPkmnType1 = "Rock" Or passPkmnType2 = "Rock" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Steel" Or passPkmnType1 = "Fire" Or passPkmnType2 = "Steel" Or passPkmnType2 = "Fire" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 4
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Ice"

                If passPkmnType1 = "Grass" Or passPkmnType1 = "Flying" Or passPkmnType1 = "Dragon" Or passPkmnType2 = "Grass" Or passPkmnType2 = "Flying" Or passPkmnType2 = "Dragon" Or passPkmnType1 = "Rock" Or passPkmnType2 = "Ground" Or passPkmnType1 = "Rock" Or passPkmnType2 = "Rock" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Ice" Or passPkmnType1 = "Fire" Or passPkmnType2 = "Fire" Or passPkmnType2 = "Ice" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 3
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Flying"

                If passPkmnType1 = "Grass" Or passPkmnType1 = "Bug" Or passPkmnType1 = "Fighting" Or passPkmnType2 = "Grass" Or passPkmnType2 = "Fighting" Or passPkmnType2 = "Bug" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Rock" Or passPkmnType1 = "Metal" Or passPkmnType2 = "Rock" Or passPkmnType2 = "Metal" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 4
                ElseIf passPkmnType1 = "Ghost" Or passPkmnType2 = "Ghost" Then
                    totalDamage = 0
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Rock"

                If passPkmnType1 = "Flying" Or passPkmnType1 = "Fire" Or passPkmnType2 = "Flying" Or passPkmnType2 = "Fire" Then
                    totalDamage = (passDamage * passPkmnLvl)
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Ground"

                If passPkmnType1 = "Rock" Or passPkmnType1 = "Fire" Or passPkmnType1 = "Poison" Or passPkmnType2 = "Rock" Or passPkmnType2 = "Fire" Or passPkmnType2 = "Poison" Or passPkmnType1 = "Electric" Or passPkmnType2 = "Electric" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Bug" Or passPkmnType1 = "Grass" Or passPkmnType2 = "Bug" Or passPkmnType2 = "Grass" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 3
                ElseIf passPkmnType1 = "Flying" Or passPkmnType2 = "Flying" Then
                    totalDamage = 0
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Poison"

                If passPkmnType1 = "Grass" Or passPkmnType1 = "Bug" Or passPkmnType2 = "Grass" Or passPkmnType2 = "Bug" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Poison" Or passPkmnType1 = "Rock" Or passPkmnType2 = "Poison" Or passPkmnType2 = "Rock" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 3
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Dark"

                If passPkmnType1 = "Psychic" Or passPkmnType2 = "Psychic" Then
                    totalDamage = (passDamage * passPkmnLvl)
                ElseIf passPkmnType1 = "Metal" Or passPkmnType2 = "Metal" Then
                    totalDamage = (passDamage * passPkmnLvl) \ 3
                Else
                    totalDamage = passDamage * passPkmnLvl \ 2
                End If

            Case "Dragon"
                totalDamage = passDamage * passPkmnLvl \ 2
            Case "Bug"
                totalDamage = passDamage * passPkmnLvl \ 2
        End Select


        kotong = Int((10 - 1 + 1) * Rnd() + 1)
        totalDamage = totalDamage - kotong
        If totalDamage <= 0 Then totalDamage = 0

    End Sub


    Public Sub evolution(ByVal argsIndex, ByVal argsLevel)
        evolutionIndex = argsIndex
        'preEvolutionName = argsName
        'argsName = preEvolutionName
        Select Case preEvolutionName
            Case "Bulbasaur"
                If argsLevel >= 18 Then
                    evolutionName = "Ivysaur"
                    showFrmEvolve()
                End If
            Case "Ivysaur"
                If argsLevel >= 43 Then
                    evolutionName = "Venusaur"
                    showFrmEvolve()
                End If
            Case "Charmander"
                If argsLevel >= 20 Then
                    evolutionName = "Charmeleon"
                    showFrmEvolve()
                End If
            Case "Charmeleon"
                If argsLevel >= 46 Then
                    evolutionName = "Charizard"
                    showFrmEvolve()
                End If
            Case "Squirtle"
                If argsLevel >= 20 Then
                    evolutionName = "Wartortle"
                    showFrmEvolve()
                End If
            Case "Wartortle"
                If argsLevel >= 46 Then
                    evolutionName = "Blastoise"
                    showFrmEvolve()
                End If
            Case "Chicorita"
                If argsLevel >= 18 Then
                    evolutionName = "Bayleef"
                    showFrmEvolve()
                End If
            Case "Bayleef"
                If argsLevel >= 43 Then
                    evolutionName = "Meganium"
                    showFrmEvolve()
                End If
            Case "Cyndaquil"
                If argsLevel >= 20 Then
                    evolutionName = "Quilava"
                    showFrmEvolve()
                End If
            Case "Quilava"
                If argsLevel >= 46 Then
                    evolutionName = "Typlosion"
                    showFrmEvolve()
                End If
            Case "Totodile"
                If argsLevel >= 20 Then
                    evolutionName = "Croconaw"
                    showFrmEvolve()
                End If
            Case "Croconaw"
                If argsLevel >= 45 Then
                    evolutionName = "Feraligatr"
                    showFrmEvolve()
                End If
            Case "Treeko"
                If argsLevel >= 18 Then
                    evolutionName = "Grovile"
                    showFrmEvolve()
                End If
            Case "Grovile"
                If argsLevel >= 45 Then
                    evolutionName = "Sceptile"
                    showFrmEvolve()
                End If
            Case "Mudkip"
                If argsLevel >= 20 Then
                    evolutionName = "Marshtomp"
                    showFrmEvolve()
                End If
            Case "Marshstomp"
                If argsLevel >= 48 Then
                    evolutionName = "Swampert"
                    showFrmEvolve()
                End If
            Case "Turtwig"
                If argsLevel >= 18 Then
                    evolutionName = "Grotle"
                    showFrmEvolve()
                End If
            Case "Grotle"
                If argsLevel >= 44 Then
                    evolutionName = "Torterra"
                    showFrmEvolve()
                End If
            Case "Chimchar"
                If argsLevel >= 20 Then
                    evolutionName = "Monferno"
                    showFrmEvolve()
                End If
            Case "Monferno"
                If argsLevel >= 46 Then
                    evolutionName = "Infernape"
                    showFrmEvolve()
                End If
            Case "Piplup"
                If argsLevel >= 20 Then
                    evolutionName = "Prinplup"
                    showFrmEvolve()
                End If
            Case "Prinplup"
                If argsLevel >= 48 Then
                    evolutionName = "Empoleon"
                    showFrmEvolve()
                End If
            Case "Torchic"
                If argsLevel >= 20 Then
                    evolutionName = "Combusken"
                    showFrmEvolve()
                End If
            Case "Cumbusken"
                If argsLevel >= 46 Then
                    evolutionName = "Blaziken"
                    showFrmEvolve()
                End If
            Case "Lotad"
                If argsLevel >= 20 Then
                    evolutionName = "Lombre"
                    showFrmEvolve()
                End If
            Case "Lombre"
                If argsLevel >= 46 Then
                    evolutionName = "Ludicolo"
                    showFrmEvolve()
                End If
            Case "Rattata"
                If argsLevel >= 30 Then
                    evolutionName = "Raticate"
                    showFrmEvolve()
                End If
            Case "Ekans"
                If argsLevel >= 35 Then
                    evolutionName = "Arbok"
                    showFrmEvolve()
                End If
            Case "Hoothoot"
                If argsLevel >= 30 Then
                    evolutionName = "Noctowl"
                    showFrmEvolve()
                End If
            Case "Bellsprout"
                If argsLevel >= 30 Then
                    evolutionName = "Weepinbell"
                    showFrmEvolve()
                End If
            Case "Weepinbell"
                If argsLevel >= 45 Then
                    evolutionName = "Victreebel"
                    showFrmEvolve()
                End If
            Case "Pidgey"
                If argsLevel >= 25 Then
                    evolutionName = "Pidgeoto"
                    showFrmEvolve()
                End If
            Case "Pidgeotto"
                If argsLevel >= 35 Then
                    evolutionName = "Pidgeot"
                    showFrmEvolve()
                End If
            Case "Starly"
                If argsLevel >= 25 Then
                    evolutionName = "Staravia"
                    showFrmEvolve()
                End If
            Case "Staravia"
                If argsLevel >= 40 Then
                    evolutionName = "Staraptor"
                    showFrmEvolve()
                End If
            Case "Tailow"
                If argsLevel >= 28 Then
                    evolutionName = "Swellow"
                    showFrmEvolve()
                End If
            Case "Odish"
                If argsLevel >= 25 Then
                    evolutionName = "Gloom"
                    showFrmEvolve()
                End If
            Case "Gloom"
                If argsLevel >= 45 Then
                    evolutionName = "Vileplume"
                    showFrmEvolve()
                End If
            Case "Stunky"
                If argsLevel >= 25 Then
                    evolutionName = "Stuntank"
                    showFrmEvolve()
                End If
            Case "Pichu"
                If argsLevel >= 25 Then
                    evolutionName = "Pikachu"
                    showFrmEvolve()
                End If
            Case "Pikachu"
                If argsLevel >= 35 Then
                    evolutionName = "Raichu"
                    showFrmEvolve()
                End If
            Case "Graveller"
                If argsLevel >= 43 Then
                    evolutionName = "Golem"
                    showFrmEvolve()
                End If
            Case "Onix"
                If argsLevel >= 35 Then
                    evolutionName = "Steelix"
                    showFrmEvolve()
                End If
            Case "Chinchou"
                If argsLevel >= 35 Then
                    evolutionName = "Lanturn"
                    showFrmEvolve()
                End If
            Case "Wailmer"
                If argsLevel >= 35 Then
                    evolutionName = "Wailord"
                    showFrmEvolve()
                End If
            Case "Staryu"
                If argsLevel >= 33 Then
                    evolutionName = "Starmie"
                    showFrmEvolve()
                End If
            Case "Seel"
                If argsLevel >= 40 Then
                    evolutionName = "Dewgong"
                    showFrmEvolve()
                End If
            Case "Electrike"
                If argsLevel >= 35 Then
                    evolutionName = "Manectric"
                    showFrmEvolve()
                End If
            Case "Electabuzz"
                If argsLevel >= 43 Then
                    evolutionName = "Electivire"
                    showFrmEvolve()
                End If
            Case "Nidorino"
                If argsLevel >= 43 Then
                    evolutionName = "Nidoking"
                    showFrmEvolve()
                End If
            Case "Natu"
                If argsLevel >= 38 Then
                    evolutionName = "Xatu"
                    showFrmEvolve()
                End If
            Case "Aipom"
                If argsLevel >= 35 Then
                    evolutionName = "Ambipom"
                    showFrmEvolve()
                End If
            Case "Mareep"
                If argsLevel >= 25 Then
                    evolutionName = "Flaaffy"
                    showFrmEvolve()
                End If
            Case "Flaaffy"
                If argsLevel >= 43 Then
                    evolutionName = "Ampharos"
                    showFrmEvolve()
                End If
            Case "Weepinbell"
                If argsLevel >= 40 Then
                    evolutionName = "Victreebel"
                    showFrmEvolve()
                End If
            Case "Magneton"
                If argsLevel >= 45 Then
                    evolutionName = "Magnezone"
                    showFrmEvolve()
                End If
            Case "Shieldon"
                If argsLevel >= 45 Then
                    evolutionName = "Bastiodon"
                    showFrmEvolve()
                End If
            Case "Cranidos"
                If argsLevel >= 45 Then
                    evolutionName = "Rampardos"
                    showFrmEvolve()
                End If
            Case "Diglett"
                If argsLevel >= 35 Then
                    evolutionName = "Dugtrio"
                    showFrmEvolve()
                End If
            Case "Lairon"
                If argsLevel >= 45 Then
                    evolutionName = "Aggron"
                    showFrmEvolve()
                End If
            Case "Rhyhorn"
                If argsLevel >= 30 Then
                    evolutionName = "Rhydon"
                    showFrmEvolve()
                End If
            Case "Rhydon"
                If argsLevel >= 50 Then
                    evolutionName = "Rhyperior"
                    showFrmEvolve()
                End If
            Case "Tangela"
                If argsLevel >= 40 Then
                    evolutionName = "Tangrowth"
                    showFrmEvolve()
                End If
            Case "Roselia"
                If argsLevel >= 43 Then
                    evolutionName = "Roserade"
                    showFrmEvolve()
                End If
            Case "Snowver"
                If argsLevel >= 40 Then
                    evolutionName = "Abomasnow"
                    showFrmEvolve()
                End If
            Case "Golbat"
                If argsLevel >= 43 Then
                    evolutionName = "Crobat"
                    showFrmEvolve()
                End If
            Case "Gastly"
                If argsLevel >= 30 Then
                    evolutionName = "Haunter"
                    showFrmEvolve()
                End If
            Case "Haunter"
                If argsLevel >= 50 Then
                    evolutionName = "Gengar"
                    showFrmEvolve()
                End If
            Case "Shuppet"
                If argsLevel >= 40 Then
                    evolutionName = "Banette"
                    showFrmEvolve()
                End If
            Case "Seadra"
                If argsLevel >= 50 Then
                    evolutionName = "Kingdra"
                    showFrmEvolve()
                End If
            Case "Poliwhirl"
                If argsLevel >= 40 Then
                    evolutionName = "Poliwrath"
                    showFrmEvolve()
                End If
            Case "Poocheyena"
                If argsLevel >= 30 Then
                    evolutionName = "Mightyena"
                    showFrmEvolve()
                End If
            Case "Magby"
                If argsLevel >= 25 Then
                    evolutionName = "Magmar"
                    showFrmEvolve()
                End If
            Case "Magmar"
                If argsLevel >= 45 Then
                    evolutionName = "Magmortar"
                    showFrmEvolve()
                End If
            Case "Shynx"
                If argsLevel >= 25 Then
                    evolutionName = "Luxio"
                    showFrmEvolve()
                End If
            Case "Luxio"
                If argsLevel >= 45 Then
                    evolutionName = "Luxray"
                    showFrmEvolve()
                End If
            Case "Houndour"
                If argsLevel >= 35 Then
                    evolutionName = "Houndoom"
                    showFrmEvolve()
                End If
            Case "Hippopotas"
                If argsLevel >= 48 Then
                    evolutionName = "Hippowdon"
                    showFrmEvolve()
                End If
            Case "Dragonair"
                If argsLevel >= 65 Then
                    evolutionName = "Dragonite"
                    showFrmEvolve()
                End If
            Case "Gible"
                If argsLevel >= 35 Then
                    evolutionName = "Gabite"
                    showFrmEvolve()
                End If
            Case "Gabite"
                If argsLevel >= 60 Then
                    evolutionName = "Garchomp"
                    showFrmEvolve()
                End If
            Case "Murkrow"
                If argsLevel >= 45 Then
                    evolutionName = "Hunchkrow"
                    showFrmEvolve()
                End If
            Case "Duskull"
                If argsLevel >= 35 Then
                    evolutionName = "Dusclops"
                    showFrmEvolve()
                End If
            Case "Dusclops"
                If argsLevel >= 50 Then
                    evolutionName = "Dusknoir"
                    showFrmEvolve()
                End If
            Case "Ledyba"
                If argsLevel >= 35 Then
                    evolutionName = "Ledian"
                    showFrmEvolve()
                End If
            Case "Growlithe"
                If argsLevel >= 40 Then
                    evolutionName = "Arcanine"
                    showFrmEvolve()
                End If
            Case "Slugma"
                If argsLevel >= 40 Then
                    evolutionName = "Magcargo"
                    showFrmEvolve()
                End If
        End Select
    End Sub
    Public Sub pokedexPart3(ByVal pkmn, ByVal args)
        Dim attacks() As String = {"dog", "cat", "fish"}
        Select Case pkmn

            'Slowbro
            Case "Slowbro"
                attacks = {"Amnesia", "Psychic", "HeadBut", "Water Pulse"}
                Type1 = "Water"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Cloyster
            Case "Cloyster"
                attacks = {"Clamp", "Ice Beam", "Aurora Beam", "Water Pulse"}
                Type1 = "Water"
                Type2 = "Ice"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Tentacruel
            Case "Tentacruel"
                attacks = {"Constrict", "Toxic", "Poison Jab", "Water Pulse"}
                Type1 = "Water"
                Type2 = "Poison"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Kyogre
            Case "Kyogre"
                attacks = {"Hydro Pump", "Body Slam", "Ancient Power", "Hyper Beam"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 4
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 7
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 7
                End If
                'Groudon
            Case "Groudon"
                attacks = {"Earthquake", "Solar Beam", "Ancient Power", "Hyper Beam"}
                Type1 = "Ground"
                Type2 = "Ground"
                runRate = 4
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 7
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 7
                End If
                'Magmar
            Case "Magmar"
                attacks = {"Fire Spin", "Fire Punch", "HeadBut", "Smog"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 4
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 7
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 7
                End If
                'Lapras
            Case "Lapras"
                attacks = {"Ice Beam", "Blizzard", "Hydro Pump", "Body Slam"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 5
                End If
                'Numel
            Case "Numel"
                attacks = {"Tackle", "Growl", "HeadBut", "Ember"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 3
                End If
                'camerupt
            Case "Camerupt"
                attacks = {"Overheat", "Fire Spin", "Flame Thrower", "Body Slam"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 5
                End If
                'Magby
            Case "Magby"
                attacks = {"Tackle", "Leer", "Ember", "Smog"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 3
                End If
                'Magmar
            Case "Magmar"
                attacks = {"Ember", "Flame Thrower", "Fire Punch", "Smog"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 7
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Magmortar
            Case "Magmortar"
                attacks = {"Fire Spin", "Lava Plume", "Flame Wheel", "Seismic Toss"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 5
                End If
                'Shynx
            Case "Shynx"
                attacks = {"Tackle", "Tail Whip", "Thunder Shock", "Bite"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 3
                End If
                'Luxio
            Case "Luxio"
                attacks = {"Bolt Tackle", "Quick Attack", "Thunder Shock", "Bite"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 7
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Luxray
            Case "Luxray"
                attacks = {"Bolt Tackle", "Extreme Speed", "Thunder", "Thunder Fang"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 5
                End If
                'Mewtwo
            Case "Mewtwo"
                attacks = {"Psychic", "Doom Desire", "Giga Impact", "Energy Ball"}
                Type1 = "Psychic"
                Type2 = "Psychic"
                runRate = 3
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 7
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 7
                End If
                'Tyranitar
            Case "Tyranitar"
                attacks = {"Hyper Beam", "Earthquake", "Stone Edge", "Rock Tomb"}
                Type1 = "Ground"
                Type2 = "Ground"
                runRate = 4
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 6
                End If
                'Salamence
            Case "Salamence"
                attacks = {"Hyper Beam", "Dragon Claw", "Outrage", "Dragon Breath"}
                Type1 = "Dragon"
                Type2 = "Dragon"
                runRate = 4
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 6
                End If
                'Skorupi
            Case "Skorupi"
                attacks = {"Poison Sting", "Poison Tail", "Bite", "Tackle"}
                Type1 = "Poison"
                Type2 = "Bug"
                runRate = 6
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 3
                End If
                'Drapion
            Case "Drapion"
                attacks = {"Poison Jab", "Crunch", "Poison Tail", "Slash"}
                Type1 = "Poison"
                Type2 = "Dark"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Kingler
            Case "Kingler"
                attacks = {"Vice Grip", "Bubble Beam", "Hyper Beam", "Guilotine"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Machoke
            Case "Machoke"
                attacks = {"Seimic Toss", "Brick Break", "Mega Punch", "Karater Chop"}
                Type1 = "Fighting"
                Type2 = "Fighting"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Machamp
            Case "Machamp"
                attacks = {"Cross Chop", "Super Power", "Close Combat", "Mach Punch"}
                Type1 = "Fighting"
                Type2 = "Fighting"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 5
                End If
                'Hippopotas
            Case "Hippopotas"
                attacks = {"Tackle", "HeaBut", "Dig", "Magnitude"}
                Type1 = "Ground"
                Type2 = "Ground"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 3
                End If
                'Hippowdon
            Case "Hippowdon"
                attacks = {"Earthquake", "Mud Water", "Sand Storm", "Magnitude"}
                Type1 = "Ground"
                Type2 = "Ground"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Hariyama
            Case "Hariyama"
                attacks = {"Drain Punch", "Mach Punch", "Dynamic Punch", "Focus Blast"}
                Type1 = "Fighting"
                Type2 = "Fighting"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Milotic
            Case "Milotic"
                attacks = {"Hydro Pump", "Water Pulse", "Aqua Tail", "Hyper Beam"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 5
                End If
                'Dragonair
            Case "Dragonair"
                attacks = {"Water Pulse", "Thunder Bolt", "Fire Spin", "Hyper Beam"}
                Type1 = "Dragon"
                Type2 = "Dragon"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Dragonite
            Case "Dragonite"
                attacks = {"Blizzard", "Thunder", "Fire Blast", "Hyper Beam"}
                Type1 = "Dragon"
                Type2 = "Dragon"
                runRate = 5
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 3
                End If
                'Gible
            Case "Gible"
                attacks = {"Sand Attack", "Bite", "HeadBut", "Tackle"}
                Type1 = "Dragon"
                Type2 = "Ground"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 3
                End If
                'Gabite
            Case "Gabite"
                attacks = {"Magnitude", "Bite", "Slash", "Dragon Breath"}
                Type1 = "Dragon"
                Type2 = "Ground"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Garchomp
            Case "Garchomp"
                attacks = {"Earthquake", "Crunch", "Hyper Beam", "Dragon Breath"}
                Type1 = "Dragon"
                Type2 = "Ground"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 5
                End If
                'Seaking
            Case "Seaking"
                attacks = {"Horn Attack", "Flail", "Pursuit", "Water Pulse"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 4
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 6
                End If
                'Poliwhirl
            Case "Poliwhirl"
                attacks = {"Pound", "Hypnosis", "Water Gun", "Bubble Beam"}
                Type1 = "Water"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Poliwrath
            Case "Poliwrath"
                attacks = {"Focus Blast", "Hypnosis", "Hydro Pump", "Super Power"}
                Type1 = "Water"
                Type2 = "Fighting"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 5
                End If
                'Mamoswine
            Case "Mamoswine"
                attacks = {"Earthquake", "Powder Snow", "Blizzard", "Avalanche"}
                Type1 = "Ice"
                Type2 = "Ice"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 5
                End If
                'Growlithe
            Case "Growlithe"
                attacks = {"Ember", "HeadBut", "Fire Spin", "Growl"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 3
                End If
                'Arcanine
            Case "Arcanine"
                attacks = {"Fire Blast", "Extreme Speed", "Flame Thrower", "Take Down"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Slugma
            Case "Slugma"
                attacks = {"Poison Gas", "Ember", "Scratch", "Fire Spin"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 6
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 3
                End If
                'Magcargo
            Case "Magcargo"
                attacks = {"Lava Plume", "Flame Thrower", "Take Down", "Flame Wheel"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
                'Aerodactyl
            Case "Aerodactyl"
                attacks = {"Rock Slide", "Wing Attack", "Bite", "Sky Attack"}
                Type1 = "Flying"
                Type2 = "Rock"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    frmBattle.lblUrType.text = urType1 & "/" & urType2
                    frmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    frmBattle.lblEnType.text = enType1 & "/" & enType2
                    frmBattle.enActivePkmn.Tag = 4
                End If
        End Select
    End Sub

End Module
