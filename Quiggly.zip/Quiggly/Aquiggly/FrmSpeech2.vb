﻿Public Class FrmSpeech2
    Dim iFixx As Integer
    Dim iFixy As Integer
    Dim iTalk As Integer
    Dim sPeopleName As String
    Dim sSItem As String
    Dim iGItems As Integer
    Dim iGrid As Integer
    Dim iGMap As Integer
    Dim iGFix As Integer
    Public Sub GetBadges()
        Dim value As String = My.Application.Info.DirectoryPath & "\images\badges\"
        Dim di As New IO.DirectoryInfo(value)
        Dim diar1 As IO.FileInfo() = di.GetFiles("*.*")
        Dim dra As IO.FileInfo
        Dim sMsg As String
        sMsg = value
        'list the names of all files in the specified directory
        For Each dra In diar1
            ' FlexItems.AddItem("BADGE" & Mid(dra.ToString, 1, Len(dra.ToString) - 4) & Chr(9) & "Badge" & Chr(9) & "Item")
            DItems.Rows.Insert(iGItems, New String() {"BADGE" & Mid(dra.ToString, 1, Len(dra.ToString) - 4), "Badge", "Badge"})
            iGItems = iGItems + 1
        Next

    End Sub
    Private Sub RSpeech()
        Dim sTag As String
        Dim cFile As String
        Dim i As Integer
        Dim j As Integer
        RB1.Checked = True
        ReadDoorFile(Text1.Text)
        iTalk = 0
        ReadTiles()
        'FlexMap.Clear()
        'FlexMap.Rows = 1
        DMap.Rows.Clear()
        DMap.Columns.Clear()
        Dfix.Rows.Clear()
        DFix.Columns.Clear()
        iGFix = 0
        iGMap = 0
        ' FlexMap.FormatString = "Name   " & vbTab & "  X" & vbTab & "  Y"
        ' FlexFix.FormatString = "Fix   " & vbTab & "  X" & vbTab & "  Y"
        DMap.ColumnCount = 3
        DMap.Columns(0).Name = "From.."
        DMap.Columns(1).Name = "Type.."
        DMap.Columns(2).Name = "X..."
        DFix.ColumnCount = 3
        DFix.Columns(0).Name = "Fix.."
        DFix.Columns(1).Name = "X..."
        DFix.Columns(2).Name = "Y..."
        'Dgrid2.Columns(3).Name = "Y..."
        'Dgrid2.Columns(4).Name = "To."
        'Dgrid2.Columns(5).Name = "X..."
        'Dgrid2.Columns(6).Name = "Y...
        For Each doors In nDoors
            'If doors.Mytype = "TALK" Then FlexMap.AddItem(doors.Name & vbTab & doors.DooriToX & vbTab & doors.DooriToY)
            If doors.Mytype = "TALK" Then
                DMap.Rows.Insert(iGMap, New String() {doors.Name, doors.DooriToX, doors.DooriToY})
                iGMap = iGMap + 1
            End If

            '  If doors.Mytype = "FIX" Then FlexFix.AddItem(doors.Name & vbTab & doors.DooriX & vbTab & doors.DooriY)
            If doors.Mytype = "FIX" Then
                DFix.Rows.Insert(iGFix, New String() {doors.Name, doors.DooriX, doors.DooriY})
                iGFix = iGFix + 1
            End If

        Next
        Dim srFileReader As System.IO.StreamReader
        sPeopleName = ""
        iTalk = 0
        iFixx = 0
        iFixy = 0
        RichTextBox1.Text = ""
        cFile = My.Application.Info.DirectoryPath & "\Maps\" & Text1.Text & "s.txt"
        srFileReader = System.IO.File.OpenText(cFile)
        i = 0
        RichTextBox1.Text = ""
        sTag = srFileReader.ReadLine()
        Do While (Not sTag Is Nothing)
            If i = 0 Then
                If Trim(sTag) <> "" Then RichTextBox1.Text = sTag
            Else
                If Trim(sTag) <> "" Then RichTextBox1.Text = RichTextBox1.Text & vbCr & vbLf & sTag
            End If
            sTag = srFileReader.ReadLine()
            i = 1
            If Mid(sTag, 1, 1) = "<" Then
                j = Mid(sTag, 2, 4)
                If j > iTalk Then
                    iTalk = j
                End If
            End If
        Loop
        srFileReader.Close()

        iTalk = iTalk + 10
    End Sub
    Private Sub FrmSpeech2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' SAVE_MapLoaded = "new"
        Text1.Text = SAVE_MapLoaded
        iFixx = -1
        DItems.ColumnCount = 3
        DItems.Columns(0).Name = "Items .."
        DItems.Columns(1).Name = "Description..."
        DItems.Columns(2).Name = "Type..."
        iGItems = 0
        'FlexItems.FormatString = "Items        |Description |Type    "
        ' FlexItems.AddItem("Ticket" & Chr(9) & "" & Chr(9) & "Item")
        'FlexItems.AddItem("Wood" & Chr(9) & "" & Chr(9) & "Item")
        ' FlexItems.AddItem("Toast" & Chr(9) & "" & Chr(9) & "Item")
        ' FlexItems.AddItem("Coin" & Chr(9) & "" & Chr(9) & "Item")
        DItems.Rows.Insert(iGItems, New String() {"Ticket", "", "Item"})
        iGItems = iGItems + 1
        DItems.Rows.Insert(iGItems, New String() {"Wood", "", "Item"})
        iGItems = iGItems + 1
        DItems.Rows.Insert(iGItems, New String() {"Toast", "", "Item"})
        iGItems = iGItems + 1
        DItems.Rows.Insert(iGItems, New String() {"Coin", "", "Item"})
        iGItems = iGItems + 1
        For Each cTile In nTiles
            If UCase(cTile.TileType) = "ITEM" Then
                ' FlexItems.AddItem(cTile.TileName & Chr(9) & "" & Chr(9) & "Item")
                DItems.Rows.Insert(iGItems, New String() {cTile.TileName, "", "Item"})
                iGItems = iGItems + 1
            End If
        Next
        GetBadges()
        'FlexItems.AddItem("SPELLA" & Chr(9) & "Axe Tree" & Chr(9) & "Spell")
        'FlexItems.AddItem("SPELLC" & Chr(9) & "Cut Weeds" & Chr(9) & "Spell")
        'FlexItems.AddItem("SPELLD" & Chr(9) & "Destroy Rocks" & Chr(9) & "Spell")
        'FlexItems.AddItem("SPELLF" & Chr(9) & "Fill Swamp" & Chr(9) & "Spell")
        'FlexItems.AddItem("SPELLG" & Chr(9) & "Grow Grass" & Chr(9) & "Spell")
        'FlexItems.AddItem("SPELLL" & Chr(9) & "Light Cave" & Chr(9) & "Spell")
        'FlexItems.AddItem("SPELL1" & Chr(9) & "Transport 1" & Chr(9) & "Spell")
        DItems.Rows.Insert(iGItems, New String() {"SPELLA","Axe Tree" , "Spell"})
        iGItems = iGItems + 1
        DItems.Rows.Insert(iGItems, New String() {"SPELLC" & "Cut Weeds" , "Spell"})
        iGItems = iGItems + 1
        DItems.Rows.Insert(iGItems, New String() {"SPELLD" , "Destroy Rocks" , "Spell"})
        iGItems = iGItems + 1
        DItems.Rows.Insert(iGItems, New String() {"SPELLF" , "Fill Swamp" , "Spell"})
        iGItems = iGItems + 1
        DItems.Rows.Insert(iGItems, New String() {"SPELLG", "Grow Grass", "Spell"})
        iGItems = iGItems + 1
        DItems.Rows.Insert(iGItems, New String() {"SPELLL" ,"Light Cave" , "Spell"})
        iGItems = iGItems + 1
        DItems.Rows.Insert(iGItems, New String() {"SPELL1", "Transport 1", "Spell"})
        iGItems = iGItems + 1
        DGrid.ColumnCount = 2
        DGrid.Columns(0).Name = "Command....."
        DGrid.Columns(1).Name = "Description..."
        'DItems.Columns(2).Name = "Type..."
        iGrid = 0
        iGrid = 0
        DGrid.Rows.Insert(iGrid, New String() {"<0001>          ", "Number 1"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"Mother: Hello   ", "Name"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"0030=Any advice?", "go to Number 30"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"0000=Goodby     ", "End Speech"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"<0030>          ", "Number 30"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"SayOnce!        ", "Say only one time"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"TakeAny!        ", "Take any inventory item"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"BQuest!0001     ", "Before quest 1 started"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"SQuest!0001     ", "Start quest 1"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"QuestN!Talk brother", "Quest Name"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"EQuest!0001     ", "End quest 1"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"QuestNo!0001    ", "Only if Quest 1 is started"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"QuestYes!0001   ", "Only if Quest 1 is done"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"Give!Ticket     ", "Items given to you"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"GiveQty!01      ", "Give Qty"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"Need!Wood       ", "Item you need to give away"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"NeedQty!01      ", "Need Qty"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"BombQty!01      ", "Bombs given to you"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"Pokemon!        ", "Pokemon to fight"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"Cure=Cure Pokemon", "Cure your Pokemon"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"FixX!0010       ", "X Pos - Make grass"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"FixY!0022       ", "Y Pos - Make grass"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"FixMap!Tile     ", "Grass,Tile,Stargate,Stairs"})
        iGrid = iGrid + 1
        DGrid.Rows.Insert(iGrid, New String() {"#               ", "Replace with character name"})
        ''FlexGrid.FormatString = "Command         |Description                  "
        ''FlexGrid.AddItem("<0001>          " & Chr(9) & "Number 1")
        ''FlexGrid.AddItem("Mother: Hello   " & Chr(9) & "Name")
        ''FlexGrid.AddItem("0030=Any advice?" & Chr(9) & "go to Number 30")
        ''FlexGrid.AddItem("0000=Goodby     " & Chr(9) & "End Speech")
        ''FlexGrid.AddItem("<0030>          " & Chr(9) & "Number 30")
        ''FlexGrid.AddItem("SayOnce!        " & Chr(9) & "Say only one time")
        ''FlexGrid.AddItem("TakeAny!        " & Chr(9) & "Take any inventory item")
        ''FlexGrid.AddItem("BQuest!0001     " & Chr(9) & "Before quest 1 started")
        ''FlexGrid.AddItem("SQuest!0001     " & Chr(9) & "Start quest 1")
        ''FlexGrid.AddItem("QuestN!Talk brother" & Chr(9) & "Quest Name")
        ''FlexGrid.AddItem("EQuest!0001     " & Chr(9) & "End quest 1")
        ''FlexGrid.AddItem("QuestNo!0001    " & Chr(9) & "Only if Quest 1 is started")
        ''FlexGrid.AddItem("QuestYes!0001   " & Chr(9) & "Only if Quest 1 is done")
        ''FlexGrid.AddItem("Give!Ticket     " & Chr(9) & "Items given to you")
        ''FlexGrid.AddItem("GiveQty!01      " & Chr(9) & "Give Qty")
        ''FlexGrid.AddItem("Need!Wood       " & Chr(9) & "Item you need to give away")
        ''FlexGrid.AddItem("NeedQty!01      " & Chr(9) & "Need Qty")
        ''FlexGrid.AddItem("BombQty!01      " & Chr(9) & "Bombs given to you")
        ''FlexGrid.AddItem("Pokemon!        " & Chr(9) & "Pokemon to fight")
        ''FlexGrid.AddItem("Cure=Cure Pokemon" & Chr(9) & "Cure your Pokemon")
        ''FlexGrid.AddItem("FixX!0010       " & Chr(9) & "X Pos - Make grass")
        ''FlexGrid.AddItem("FixY!0022       " & Chr(9) & "Y Pos - Make grass")
        ''FlexGrid.AddItem("FixMap!Tile     " & Chr(9) & "Grass,Tile,Stargate,Stairs")
        ''FlexGrid.AddItem("#               " & Chr(9) & "Replace with character name")
        RSpeech()
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        RSpeech()
    End Sub

    Private Sub CmdSave_Click(sender As Object, e As EventArgs) Handles CmdSave.Click
        Dim cFile As String
        cFile = My.Application.Info.DirectoryPath & "\Maps\" & Text1.Text & "s.txt"
        ' My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "d.txt"
        Dim srFileWrite As New System.IO.StreamWriter(cFile)
        srFileWrite.WriteLine(RichTextBox1.Text)
        srFileWrite.Close()
    End Sub

    Private Sub RB1_CheckedChanged(sender As Object, e As EventArgs) Handles RB1.CheckedChanged
        RB1.BackColor = Color.White
        RB2.BackColor = Color.White
        RB2.BackColor = Color.White
        If RB1.Checked Then
            sTalkType = "Speech"
            iMagicPoints = 0
            RB1.BackColor = Color.LightGreen
        End If
        If RB2.Checked Then
            iMagicPoints = 16
            sTalkType = "Thought"
            RB2.BackColor = Color.LightGreen
        End If
        If RB3.Checked Then
            iMagicPoints = 26
            sTalkType = "Pence"
            RB2.BackColor = Color.LightGreen
        End If
    End Sub

    Private Sub RB2_CheckedChanged(sender As Object, e As EventArgs) Handles RB2.CheckedChanged
        RB1.BackColor = Color.White
        RB2.BackColor = Color.White
        RB2.BackColor = Color.White
        If RB1.Checked Then
            sTalkType = "Speech"
            iMagicPoints = 0
            RB1.BackColor = Color.LightGreen
        End If
        If RB2.Checked Then
            iMagicPoints = 16
            sTalkType = "Thought"
            RB2.BackColor = Color.LightGreen
        End If
        If RB3.Checked Then
            iMagicPoints = 26
            sTalkType = "Pence"
            RB2.BackColor = Color.LightGreen
        End If
    End Sub

    Private Sub RB3_CheckedChanged(sender As Object, e As EventArgs) Handles RB3.CheckedChanged
        RB1.BackColor = Color.White
        RB2.BackColor = Color.White
        RB2.BackColor = Color.White
        If RB1.Checked Then
            sTalkType = "Speech"
            iMagicPoints = 0
            RB1.BackColor = Color.LightGreen
        End If
        If RB2.Checked Then
            iMagicPoints = 16
            sTalkType = "Thought"
            RB2.BackColor = Color.LightGreen
        End If
        If RB3.Checked Then
            iMagicPoints = 26
            sTalkType = "Pence"
            RB2.BackColor = Color.LightGreen
        End If
    End Sub
End Class