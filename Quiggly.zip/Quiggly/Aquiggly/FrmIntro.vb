﻿Public Class FrmIntro
    Dim Map(50) As String
    Dim PositionMap As String
    Public Sub DrawIt2()
        Dim m As Integer
        Dim value As String = My.Application.Info.DirectoryPath
        Dim y As Integer
        Dim x As Integer
        FileTile = My.Application.Info.DirectoryPath & "\tiles\grass.bmp"
        x = 1
        y = 1
        Label2.Text = y + CharY & " " & Mid(Map(y + CharY + 1), (x + CharX + 1), 1)
        For y = 1 To 10
            For x = 1 To 10
                'If the result to Paint is 0 then it will get error.
                'This will prevent this.
                '                'PassToNext = 0
                If y + CharY + 0 < 1 Then GoTo skip
                If x + CharX + 0 < 1 Then GoTo skip
                If x + CharX + 0 > Len(Map(1)) Then GoTo skip
                If y + CharY + 0 > 51 Then GoTo skip
                PositionMap = Mid(Map(y + CharY + 1), (x + CharX + 1), 1)
                ' PositionMap = Mid(Map(X + CharX + 1), (Y + CharY + 1), 1)
                '                'If X = 0 And Y = 0 Then GoTo skip:
                m = 12 + x + ((y) * 12)
                Select Case PositionMap
                    Case Is = "/"
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\RoofB.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '                        PaintPicture imgBlueTop.Picture, (X + 3) * 32, (Y + 3) * 32
                    Case Is = "\"
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\RoofR.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '                        PaintPicture imgRedTop.Picture, (X + 3) * 32, (Y + 3) * 32
                    Case Is = "*"
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\House.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '                        PaintPicture imgWindow1.Picture, (X + 3) * 32, (Y + 3) * 32
                    Case Is = "#" '3
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\Door.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '                        'PaintPicture imgNothing.Picture, (X + 3) * 32, (Y + 3) * 32
                        '                        PaintPicture imgDoor1.Picture, (X + 3) * 32, (Y + 3) * 32

                    Case Is = "G" 'Grass
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\grass.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '                        PaintPicture imgGrass.Picture, (X + 3) * 32, (Y + 3) * 32
                    Case Is = "B" 'Bush
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\Tree.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '                        PaintPicture imgBush.Picture, (X + 3) * 32, (Y + 3) * 32

                    Case Is = "Q" 'Water
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\IsleTopL.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '                        PaintPicture imgTOL.Picture, (X + 3) * 32, (Y + 3) * 32
                    Case Is = "A" 'Water
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\IsleTopR.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                    Case Is = "Q" 'Water
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\IsleTopR.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '      '  PaintPicture imgBOL.Picture, (X + 3) * 32, (Y + 3) * 32
                    Case Is = "W" 'Water
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\IsleTopR.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '                        PaintPicture imgTOR.Picture, (X + 3) * 32, (Y + 3) * 32
                    Case Is = "S" 'Water
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\IsleBotR.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '      '  PaintPicture imgBOR.Picture, (X + 3) * 32, (Y + 3) * 32

                        '                    Case Is = "E" 'Border Left water
                        '                        PaintPicture ImgIL.Picture, (X + 3) * 32, (Y + 3) * 32
                        '      Case Is = "R" 'Border Right water
                        '                        PaintPicture ImgIR.Picture, (X + 3) * 32, (Y + 3) * 32
                    Case Is = "D" 'Border Top water
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\GWBotC.bmp"
                        PB(m).Image = Image.FromFile(FileTile)

                        '                        PaintPicture ImgIT.Picture, (X + 3) * 32, (Y + 3) * 32
                        '      'Case Is = "F" 'Border Bottom water
                        '      '  PaintPicture ImgIB.Picture, (X + 3) * 32, (Y + 3) * 32

                    Case Is = "-" 'Water
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\None.bmp"
                        PB(m).Image = Image.FromFile(FileTile)
                        '                        PaintPicture ImgBlack.Picture, (X + 3) * 32, (Y + 3) * 32

                End Select
skip:
            Next
        Next
        FileTile = My.Application.Info.DirectoryPath & "\tiles\mright.jpg"
        PB(55).Image = Image.FromFile(FileTile)

        '        'Character Movements. 
        '        Select Case CharFacing
        '            Case Is = 3
        '                PaintPicture imgRightChar.Picture, 5 * 32, 5 * 32
        '      End Select
    End Sub
    Private Sub FrmIntro_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bLoadMap = False
        bLoadStore = False
        iScnt44 = 0
        Map(0) = "------------------------------------------------"
        Map(1) = "------------------------------------------------"
        Map(2) = "------------------------------------------------"
        Map(3) = "------------------------------------------------"
        Map(4) = "------------------------------------------------"
        Map(5) = "------------------------------------------------"
        Map(6) = "------QDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDW------"
        Map(7) = "------EGBBBGGBBBGGGBBBGGGBBBGGGBBBGGGBBBGR------"
        Map(8) = "------EGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGR------"
        Map(9) = "------EGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGR------"
        Map(10) = "------EGBBBGGBBBGGG////BB\\\BBRGGGGGGGGGGR------"
        Map(11) = "------EGGGGGGGGGGGG*#**BG*#*GBRGGGGGGGGGGR------"
        Map(12) = "------EGBBBGGBBBGGGBBBGGGBBBGGGBBBGGGBBBGR------"
        Map(13) = "------EGBBBGGBBBGGGBBBGGGBBBGGGBBBGGGBBBGR------"
        Map(14) = "------EGBBBGGBBBGGGBBBGGGBBBGGGBBBGGGBBBGR------"
        CharX = 4
        CharY = 5
        CharFacing = 3
        Dim kLR As Integer
        Dim kUD As Integer
        Dim m As Integer
        Dim value As String = My.Application.Info.DirectoryPath
        FileTile = My.Application.Info.DirectoryPath & "\tiles\grass.bmp"
        '
        ' Map
        '
        For kUD = 1 To 12
            For kLR = 1 To 12
                m = kLR + kUD * 12 - 12
                PB(m) = New System.Windows.Forms.PictureBox()
                With PB(m)
                    .Name = m
                    .Location = New System.Drawing.Point(30 * kLR - 10, 30 * kUD - 5)
                    .Size = New Size(30, 30)
                    .Image = Image.FromFile(FileTile)
                End With

                '  This is the line that sometimes catches people out!
                Me.Controls.Add(PB(m))
                'AddHandler PB(m).Click, AddressOf pbe_Click
            Next
        Next
        Timer1.Enabled = True
    End Sub



    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        CharX = CharX + 1
        If CharX = 28 Then CharX = 10
        'CharY = CharY + 1
        'If CharY = 21 Then CharY = 10
        'Call IntroMov
        DrawIt2()
    End Sub

    Private Sub LblPlay_Click(sender As Object, e As EventArgs) Handles LblPlay.Click
        Timer1.Enabled = False
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub LblPlay_MouseEnter(sender As Object, e As EventArgs) Handles LblPlay.MouseEnter
        LblPlay.ForeColor = Color.Blue
        LblPlay.BackColor = Color.Azure
    End Sub

    Private Sub LblPlay_MouseLeave(sender As Object, e As EventArgs) Handles LblPlay.MouseLeave
        LblPlay.ForeColor = Color.Orange
        LblPlay.BackColor = Color.Black
    End Sub

    Private Sub LblLoad_Click(sender As Object, e As EventArgs) Handles LblLoad.Click
        Timer1.Enabled = False
        strChrName = "George"
        LoadGame()
        bLoadMap = True
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub LblLoad_MouseEnter(sender As Object, e As EventArgs) Handles LblLoad.MouseEnter
        LblLoad.ForeColor = Color.Blue
        LblLoad.BackColor = Color.Azure
    End Sub

    Private Sub LblLoad_MouseMove(sender As Object, e As MouseEventArgs) Handles LblLoad.MouseMove

    End Sub

    Private Sub LblLoad_MouseLeave(sender As Object, e As EventArgs) Handles LblLoad.MouseLeave
        LblLoad.ForeColor = Color.Orange
        LblLoad.BackColor = Color.Black
    End Sub

    Private Sub LblMake_Click(sender As Object, e As EventArgs) Handles LblMake.Click
        Timer1.Enabled = False
        FrmConnect.Show()
        Me.Hide()
    End Sub

    Private Sub LblMake_MouseEnter(sender As Object, e As EventArgs) Handles LblMake.MouseEnter
        LblMake.ForeColor = Color.Blue
        LblMake.BackColor = Color.Azure
    End Sub

    Private Sub LblMake_MouseLeave(sender As Object, e As EventArgs) Handles LblMake.MouseLeave
        LblMake.ForeColor = Color.Orange
        LblMake.BackColor = Color.Black
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim i As Integer
        bPlayGame = True
        ReadTiles()
        For i = 1 To 10
            myInv(i) = ""
            '  If PB(i + 132).Visible Then myInv(i) = PB(i + 132).Tag
        Next
        myInv(1) = "Candle"
        myInv(2) = "BGem"
        Coin = 5
        sStoreItems = "0102000010200000Candle;Axe;;;"
        ' sStoreItems = "1015202501020304Axe;Wand;claw;Hat;"
        FrmStore.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim i As Integer
        bPlayGame = False
        ReadTilesItem()
        For i = 1 To 10
            myInv(i) = ""
            '  If PB(i + 132).Visible Then myInv(i) = PB(i + 132).Tag
        Next
        myInv(1) = ""
        'myInv(2) = "BGem"
        Coin = 5
        sStoreItems = "" '"0102000010200000Candle;Axe;;;"
        ' sStoreItems = "1015202501020304Axe;Wand;claw;Hat;"
        FrmStore.ShowDialog()
    End Sub
End Class