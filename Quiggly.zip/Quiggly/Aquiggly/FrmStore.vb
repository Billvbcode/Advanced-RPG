﻿Public Class FrmStore

    Private Sub FrmStore_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim j As Integer
        Dim k As Integer
        Dim l As Integer
        Dim l2 As Integer
        Dim iStart As Integer
        Dim sShowItem As String
        Dim m As Integer
        iScnt44 = iScnt44 + 1
        Label3.Text = iScnt44
        ' ReadTiles()
        LblError.Visible = False
        FileTile = My.Application.Info.DirectoryPath & "\tiles\none.bmp"
        If bLoadStore = False Then
            For kUD = 1 To 5
                m = kUD
                ImgItem(m) = New System.Windows.Forms.PictureBox()
                With ImgItem(m)
                    .Name = m
                    .Location = New System.Drawing.Point(20 + 40 * kUD, 30)
                    .Size = New Size(30, 30)
                    .Tag = "NONE"
                    If bPlayGame Then
                        .Visible = False
                        .Tag = ""
                    End If
                End With

                '  This is the line that sometimes catches people out!
                '  This is the line that sometimes catches people out!
                Me.Controls.Add(ImgItem(m))
                If bPlayGame = False Then
                    ImgItem(m).Image = Image.FromFile(FileTile)
                    Me.ToolTip1.SetToolTip(ImgItem(m), "NONE")
                End If
                AddHandler ImgItem(m).Click, AddressOf pbe_Click
            Next
            ImgItem(5).Visible = False
            For kUD = 6 To 11
                m = kUD
                ImgItem(m) = New System.Windows.Forms.PictureBox()
                With ImgItem(m)
                    .Name = m
                    .Location = New System.Drawing.Point(20 + 40 * kUD - 40 * 5, 170)
                    .Size = New Size(30, 30)
                    .Tag = ""
                    .Visible = False
                End With
                '  This is the line that sometimes catches people out!
                Me.Controls.Add(ImgItem(m))
                'If bPlayGame = False Then ImgItem(m).Image = Image.FromFile(FileTile)
                AddHandler ImgItem(m).Click, AddressOf pbe_Click
            Next
            For kUD = 1 To 4
                m = kUD
                TxtPrice(m) = New System.Windows.Forms.TextBox
                With TxtPrice(m)
                    .Name = m
                    .Location = New System.Drawing.Point(20 + 40 * kUD, 70)
                    .Size = New Size(30, 30)
                    .Enabled = False
                    .Text = "0"
                    .Visible = False
                    If bPlayGame = False Then
                        .Visible = True
                        .Enabled = True
                    End If

                End With
                '  This is the line that sometimes catches people out!
                Me.Controls.Add(TxtPrice(m))
                AddHandler TxtPrice(m).Click, AddressOf TxtP_Click
            Next
            Label1.Top = TxtPrice(1).Top
            For kUD = 6 To 9
                m = kUD
                TxtPrice(m) = New System.Windows.Forms.TextBox
                With TxtPrice(m)
                    .Name = m
                    .Location = New System.Drawing.Point(20 + 40 * kUD - 40 * 5, 100)
                    .Size = New Size(30, 30)
                    .Visible = True
                    .Text = "0"
                    .Enabled = False
                    .Visible = False
                    If bPlayGame = False Then
                        .Visible = True
                        .Enabled = True
                    End If
                End With
                '  This is the line that sometimes catches people out!
                Me.Controls.Add(TxtPrice(m))
                AddHandler TxtPrice(m).Click, AddressOf TxtP_Click
            Next
        End If
        bLoadStore = True
        If bPlayGame = False Then
            Pcoin.Visible = False
            For klr = 1 To 6
                For kUD = 12 To 26
                    m = kUD + klr * 15 - 15
                    ImgItem(m) = New System.Windows.Forms.PictureBox()
                    With ImgItem(m)
                        .Name = m
                        .Location = New System.Drawing.Point(120 + 32 * kUD - 40 * 12, 150 + klr * 32 - 32)
                        .Size = New Size(30, 30)
                        .Tag = ""
                        '  .Visible = False
                    End With
                    '  This is the line that sometimes catches people out!
                    Me.Controls.Add(ImgItem(m))
                    ImgItem(m).Image = Image.FromFile(FileTile)
                    AddHandler ImgItem(m).Click, AddressOf pbe_Click
                Next
            Next
            LblCoin.Visible = False
            k = 12
            For Each cTile In nTiles
                If k = 12 Then
                    FileTile = My.Application.Info.DirectoryPath & "\tiles\" & cTile.TileName & ".bmp"
                    ImgItem(k).Image = Image.FromFile(FileTile)
                    ImgItem(k).Visible = True
                    ImgItem(k).Tag = cTile.TileName
                    Me.ToolTip1.SetToolTip(ImgItem(k), cTile.TileName)
                    imgAll.Visible = True
                    imgAll.Image = ImgItem(k).Image
                    imgAll.Tag = ImgItem(k).Tag
                    LblName.Text = ImgItem(k).Tag
                    Me.ToolTip1.SetToolTip(imgAll, LblName.Text)
                    k = k + 1
                End If
                If cTile.TileType = "ITEM" Then
                    FileTile = My.Application.Info.DirectoryPath & "\tiles\" & cTile.TileName & ".bmp"
                    ImgItem(k).Image = Image.FromFile(FileTile)
                    ImgItem(k).Visible = True
                    ImgItem(k).Tag = cTile.TileName
                    Me.ToolTip1.SetToolTip(ImgItem(k), cTile.TileName)
                    k = k + 1
                End If
            Next
            Label2.Top = TxtPrice(6).Top
            ' Exit Sub
        End If
        j = 9
        For j = 6 To 11
            ImgItem(j).Visible = False
            ImgItem(j).Tag = ""
            If myInv(j - 5) <> "" Then
                FileTile = My.Application.Info.DirectoryPath & "\tiles\" & myInv(j - 5) & ".bmp"
                ImgItem(j).Image = Image.FromFile(FileTile)
                ImgItem(j).Visible = True
                ImgItem(j).Tag = myInv(j - 5)
                Me.ToolTip1.SetToolTip(ImgItem(j), myInv(j - 5))
            End If
        Next
        Label2.Top = TxtPrice(6).Top
        FileTile = My.Application.Info.DirectoryPath & "\tiles\coin.jpg"
        Pcoin.Image = Image.FromFile(FileTile)
        Me.ToolTip1.SetToolTip(Pcoin, "Coin")
        LblCoin.Text = Coin
        If Len(sStoreItems) > 16 Then
            TxtPrice(1).Text = Val(Mid(sStoreItems, 1, 2))
            TxtPrice(2).Text = Val(Mid(sStoreItems, 3, 2))
            TxtPrice(3).Text = Val(Mid(sStoreItems, 5, 2))
            TxtPrice(4).Text = Val(Mid(sStoreItems, 7, 2))
            TxtPrice(6).Text = Val(Mid(sStoreItems, 9, 2))
            TxtPrice(7).Text = Val(Mid(sStoreItems, 11, 2))
            TxtPrice(8).Text = Val(Mid(sStoreItems, 13, 2))
            TxtPrice(9).Text = Val(Mid(sStoreItems, 15, 2))
            iStart = 17
            For l = 1 To 4
                j = InStr(iStart, sStoreItems, ";")
                sShowItem = ""
                k = j - iStart
                If j > 0 And k > 0 Then sShowItem = Mid(sStoreItems, iStart, j - iStart)
                If sShowItem <> "" Then
                    FileTile = My.Application.Info.DirectoryPath & "\tiles\" & sShowItem & ".bmp"
                    ImgItem(l).Image = Image.FromFile(FileTile)
                    ImgItem(l).Visible = True
                    ImgItem(l).Tag = sShowItem
                    Me.ToolTip1.SetToolTip(ImgItem(l), sShowItem)
                    TxtPrice(l).Visible = True
                    TxtPrice(l + 5).Visible = True
                    LblCoin.Text = Coin
                End If
                j = j + 1
                iStart = j
                l2 = InStr(iStart, sStoreItems, ";")
                If l2 = 0 Then Exit Sub
            Next

        End If
        
    End Sub
    Private Sub TxtP_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim cmsg As TextBox
        cmsg = sender
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        i = Val(cmsg.Name)
        If bPlayGame Then
        Else
            sStoreItems = Format(Val(TxtPrice(1).Text), "00") & Format(Val(TxtPrice(2).Text), "00") _
                   & Format(Val(TxtPrice(3).Text), "00") & Format(Val(TxtPrice(4).Text), "00") _
                   & Format(Val(TxtPrice(6).Text), "00") & Format(Val(TxtPrice(7).Text), "00") _
                   & Format(Val(TxtPrice(8).Text), "00") & Format(Val(TxtPrice(9).Text), "00") _
                   & ImgItem(1).Tag & ";" & ImgItem(2).Tag & ";" & ImgItem(3).Tag & ";" & ImgItem(4).Tag & ";"
            sStoreItems = Replace(sStoreItems, "NONE", "")
        End If

    End Sub
    Private Sub pbe_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim cmsg As PictureBox
        cmsg = sender
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        i = Val(cmsg.Name) ' & " " & sender.tag'
        Label3.Text = cmsg.Name & " " & sender.tag '
        LblError.Visible = False
        If bPlayGame Then
            If i > 0 And i < 5 Then
                For j = 6 To 11
                    If ImgItem(j).Visible And UCase(ImgItem(i).Tag) = UCase(ImgItem(j).Tag) Then
                        LblError.Visible = True
                        LblError.Text = "You Already Have One!"
                        Exit Sub
                    End If
                Next
                If Coin < Val(TxtPrice(i).Text) Then
                    LblError.Visible = True
                    LblError.Text = "Not Enough Money!"
                    Exit Sub
                End If
                If Val(TxtPrice(i + 5).Text) < 1 Then
                    LblError.Visible = True
                    LblError.Text = "None Left!"
                    Exit Sub
                End If
                k = Val(TxtPrice(i + 5).Text) - 1
                For j = 6 To 11
                    If ImgItem(j).Visible = False Then
                        Coin = Coin - Val(TxtPrice(i).Text)
                        TxtPrice(i + 5).Text = k
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\" & ImgItem(i).Tag & ".bmp"
                        ImgItem(j).Image = Image.FromFile(FileTile)
                        ImgItem(j).Visible = True
                        ImgItem(j).Tag = ImgItem(i).Tag
                        Me.ToolTip1.SetToolTip(ImgItem(j), ImgItem(j).Tag)
                        LblCoin.Text = Coin
                        myInv(j - 5) = ImgItem(i).Tag
                        If UCase(ImgItem(i).Tag) = "CANDLE" Then SAVE_Candle = 18
                        Exit Sub
                    End If
                Next

            End If
        Else
            If i > 11 Then
                imgAll.Image = ImgItem(i).Image
                imgAll.Tag = ImgItem(i).Tag
                LblName.Text = ImgItem(i).Tag
                Me.ToolTip1.SetToolTip(imgAll, LblName.Text)
            Else
                ImgItem(i).Image = imgAll.Image
                ImgItem(i).Tag = LblName.Text
                Me.ToolTip1.SetToolTip(ImgItem(i), LblName.Text)
                sStoreItems = Format(Val(TxtPrice(1).Text), "00") & Format(Val(TxtPrice(2).Text), "00") _
                   & Format(Val(TxtPrice(3).Text), "00") & Format(Val(TxtPrice(4).Text), "00") _
                   & Format(Val(TxtPrice(6).Text), "00") & Format(Val(TxtPrice(7).Text), "00") _
                   & Format(Val(TxtPrice(8).Text), "00") & Format(Val(TxtPrice(9).Text), "00") _
                   & ImgItem(1).Tag & ";" & ImgItem(2).Tag & ";" & ImgItem(3).Tag & ";" & ImgItem(4).Tag & ";"
                sStoreItems = Replace(sStoreItems, "NONE", "")

            End If
        End If

    End Sub
End Class