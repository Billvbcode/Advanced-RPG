﻿Public Class FrmWelcome
    Dim speech(20) As String
    Dim ctr As Integer
    Private Sub FrmWelcome_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FileTile = My.Application.Info.DirectoryPath & "\tiles\mdown.jpg"
        imgUpChar.Image = Image.FromFile(FileTile)
        strChrName = "Sheik"
        ctr = 0
        'If ctr = 0 Then
        '    Do While strChrName = "" Or Len(strChrName) > 10
        '        strChrName = InputBox("Please tell me your name.", "Enter your name", "Sheik")
        '        'If Len(PlayerName) > 10 Then MsgBox("Player name must be 10 characters only", , "Pokemon (cawi Version)")
        '    Loop
        'End If
        Timer1.Enabled = True
        ctr = ctr + 1
        Timer1.Tag = 1
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        On Error GoTo e
        'GoTo e
        speech(1) = "Good day to you ahhhmm... Say, what is your name again?"
        speech(2) = "Yeah right I remember now! Well " & strChrName & " Im Your guide. Nice meeting you ."
        'speech(2) = "You know I also used to be a pokemon trainer when I was at your age. Naaaa I miss that day."
        'speech(3) = "Anyway Im sure you're already excited to start your journey. You can now choose your starting pokemon"

        'Story(0) = "There was a legend of that the chosen one will save the kingdom from a great dark force."
        speech(2) = speech(2) & "The time has arrived for you to save the kingdom from a great dark force."
        speech(2) = speech(2) & " But you must learn spells, "
        speech(2) = speech(2) & "find items and solve quest."
        speech(3) = "It will not be easy so Good Luck..."
        lblDisplay.Text = ""
        If ctr = 2 Then lblDisplay.Text = speech(1) & vbCrLf
        If ctr = 3 Then lblDisplay.Text = speech(1) & vbCrLf & speech(2) & vbCrLf
        lblDisplay.Text = lblDisplay.Text & Mid(speech(ctr), 1, Val(Timer1.Tag))
        Timer1.Tag = Val(Timer1.Tag) + 1

        If Timer1.Tag > Len(speech(ctr)) + 10 Then

            If ctr = 0 Then
                Do While strChrName = "" Or Len(strChrName) > 10
                    strChrName = InputBox("Please tell me your name.", "Enter your name", "Sheik")
                    'If Len(PlayerName) > 10 Then MsgBox "Player name must be 10 characters only", , "Pokemon (cawi Version)"
                Loop
            End If

            If ctr = 3 Then
                Me.Hide()
                Timer1.Enabled = False
                Form1.Show()
                'frmSelectPkmn.ShowDialog()
                Exit Sub
            End If

            ctr = ctr + 1
            Timer1.Tag = 1
        End If

        Exit Sub
e:


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim dt As Boolean
        dt = Timer1.Enabled
        Timer1.Enabled = True

    End Sub
End Class