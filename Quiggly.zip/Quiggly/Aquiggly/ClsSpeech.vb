﻿Public Class ClsSpeech
    Private strStatus As String
    Private strBadge As String
    Private strPokeLevel As String
    Private strPokeCure As String
    Private strPokemon As String
    Private strSayOnce As String
    Private strTakeAny As String
    Private strQuestNo As String
    Private strQuestYes As String
    Private strQuestName As String
    Private strFixMap As String
    Private strFixX As String
    Private strFixY As String
    Private strEndQuest As String
    Private strStartQuest As String
    Private strBeforeQuest As String
    Private strNeed As String
    Private strGive As String
    Private strTalk As String
    Private strName As String
    Private strMyType As String
    Private mElements As Integer
    Private lCount As Long
    Private iBombQty As Integer
    Private iGiveQty As Integer
    Private iNeedQty As Integer
    Private mStrArray(20) As String
    Private iRNumber As String
    Public Property RNumber() As String      ' Melt time
        Get
            Return iRNumber
        End Get
        Set(ByVal Value As String)
            iRNumber = Value
        End Set
    End Property
    ' The indexed Score property procedures.
    Public Property Question(ByVal test_number As Integer) As String
        Get
            Return mStrArray(test_number)
        End Get
        Set(ByVal Value As String)
            mStrArray(test_number) = Value
            mElements = test_number + 1
        End Set
    End Property
    Public Property NeedQty() As Integer       ' Melt time
        Get
            Return iNeedQty
        End Get
        Set(ByVal Value As Integer)
            iNeedQty = Value
        End Set
    End Property
    Public Property GiveQty() As Integer       ' Melt time
        Get
            Return iGiveQty
        End Get
        Set(ByVal Value As Integer)
            iGiveQty = Value
        End Set
    End Property
    Public Property BombQty() As Integer       ' Melt time
        Get
            Return iBombQty
        End Get
        Set(ByVal Value As Integer)
            iBombQty = Value
        End Set
    End Property
    Public Property Count() As Long
        Get
            Return mElements
        End Get
        Set(ByVal Value As Long)
            lCount = Value
        End Set
    End Property
    ' Erase the array
    Public Sub Clear()
        mElements = 0
    End Sub

    Public Property MyType() As String      'Foe Description
        Get
            Return strMyType
        End Get
        Set(ByVal Value As String)
            strMyType = Value
        End Set
    End Property
    Public Property Name() As String      'Foe Description
        Get
            Return strName
        End Get
        Set(ByVal Value As String)
            strName = Value
        End Set
    End Property
    Public Property Talk() As String      'Foe Description
        Get
            Return strTalk
        End Get
        Set(ByVal Value As String)
            strTalk = Value
        End Set
    End Property
    Public Property Give() As String      'Foe Description
        Get
            Return strGive
        End Get
        Set(ByVal Value As String)
            strGive = Value
        End Set
    End Property
    Public Property Need() As String      'Foe Description
        Get
            Return strNeed
        End Get
        Set(ByVal Value As String)
            strNeed = Value
        End Set
    End Property
    Public Property BeforeQuest() As String      'Foe Description
        Get
            Return strBeforeQuest
        End Get
        Set(ByVal Value As String)
            strBeforeQuest = Value
        End Set
    End Property
    Public Property StartQuest() As String      'Foe Description
        Get
            Return strStartQuest
        End Get
        Set(ByVal Value As String)
            strStartQuest = Value
        End Set
    End Property
    Public Property EndQuest() As String      'Foe Description
        Get
            Return strEndQuest
        End Get
        Set(ByVal Value As String)
            strEndQuest = Value
        End Set
    End Property
    Public Property FixY() As String      'Foe Description
        Get
            Return strFixY
        End Get
        Set(ByVal Value As String)
            strFixY = Value
        End Set
    End Property
    Public Property FixX() As String      'Foe Description
        Get
            Return strFixX
        End Get
        Set(ByVal Value As String)
            strFixX = Value
        End Set
    End Property
    Public Property FixMap() As String      'Foe Description
        Get
            Return strFixMap
        End Get
        Set(ByVal Value As String)
            strFixMap = Value
        End Set
    End Property
    Public Property QuestName() As String      'Foe Description
        Get
            Return strQuestName
        End Get
        Set(ByVal Value As String)
            strQuestName = Value
        End Set
    End Property
    Public Property QuestYes() As String      'Foe Description
        Get
            Return strQuestYes
        End Get
        Set(ByVal Value As String)
            strQuestYes = Value
        End Set
    End Property
    Public Property QuestNo() As String      'Foe Description
        Get
            Return strQuestNo
        End Get
        Set(ByVal Value As String)
            strQuestNo = Value
        End Set
    End Property
    Public Property TakeAny() As String      'Foe Description
        Get
            Return strTakeAny
        End Get
        Set(ByVal Value As String)
            strTakeAny = Value
        End Set
    End Property
    Public Property SayOnce() As String      'Foe Description
        Get
            Return strSayOnce
        End Get
        Set(ByVal Value As String)
            strSayOnce = Value
        End Set
    End Property
    Public Property Pokemon() As String      'Foe Description
        Get
            Return strPokemon
        End Get
        Set(ByVal Value As String)
            strPokemon = Value
        End Set
    End Property
    Public Property PokeCure() As String      'Foe Description
        Get
            Return strPokeCure
        End Get
        Set(ByVal Value As String)
            strPokeCure = Value
        End Set
    End Property
    Public Property PokeLevel() As String      'Foe Description
        Get
            Return strPokeLevel
        End Get
        Set(ByVal Value As String)
            strPokeLevel = Value
        End Set
    End Property
    Public Property Badge() As String      'Foe Description
        Get
            Return strBadge
        End Get
        Set(ByVal Value As String)
            strBadge = Value
        End Set
    End Property
    Public Property Status() As String      'Foe Description
        Get
            Return strStatus
        End Get
        Set(ByVal Value As String)
            strStatus = Value
        End Set
    End Property
End Class
