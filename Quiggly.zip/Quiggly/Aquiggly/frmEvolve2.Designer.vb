﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEvolve2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnCLose = New System.Windows.Forms.Button()
        Me.lblPre = New System.Windows.Forms.Label()
        Me.LblNow = New System.Windows.Forms.Label()
        Me.lblCongrats = New System.Windows.Forms.Label()
        Me.imgNow = New System.Windows.Forms.PictureBox()
        Me.imgPre = New System.Windows.Forms.PictureBox()
        CType(Me.imgNow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgPre, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnCLose
        '
        Me.BtnCLose.Location = New System.Drawing.Point(171, 221)
        Me.BtnCLose.Name = "BtnCLose"
        Me.BtnCLose.Size = New System.Drawing.Size(83, 50)
        Me.BtnCLose.TabIndex = 17
        Me.BtnCLose.Text = "Close"
        Me.BtnCLose.UseVisualStyleBackColor = True
        '
        'lblPre
        '
        Me.lblPre.AutoSize = True
        Me.lblPre.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPre.Location = New System.Drawing.Point(19, 158)
        Me.lblPre.Name = "lblPre"
        Me.lblPre.Size = New System.Drawing.Size(55, 16)
        Me.lblPre.TabIndex = 19
        Me.lblPre.Text = "Label1"
        '
        'LblNow
        '
        Me.LblNow.AutoSize = True
        Me.LblNow.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNow.Location = New System.Drawing.Point(258, 158)
        Me.LblNow.Name = "LblNow"
        Me.LblNow.Size = New System.Drawing.Size(55, 16)
        Me.LblNow.TabIndex = 20
        Me.LblNow.Text = "Label1"
        '
        'lblCongrats
        '
        Me.lblCongrats.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCongrats.Location = New System.Drawing.Point(71, 9)
        Me.lblCongrats.Name = "lblCongrats"
        Me.lblCongrats.Size = New System.Drawing.Size(225, 31)
        Me.lblCongrats.TabIndex = 21
        Me.lblCongrats.Text = "Label1"
        '
        'imgNow
        '
        Me.imgNow.Location = New System.Drawing.Point(253, 53)
        Me.imgNow.Name = "imgNow"
        Me.imgNow.Size = New System.Drawing.Size(113, 80)
        Me.imgNow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgNow.TabIndex = 16
        Me.imgNow.TabStop = False
        '
        'imgPre
        '
        Me.imgPre.Location = New System.Drawing.Point(22, 53)
        Me.imgPre.Name = "imgPre"
        Me.imgPre.Size = New System.Drawing.Size(113, 80)
        Me.imgPre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgPre.TabIndex = 15
        Me.imgPre.TabStop = False
        '
        'frmEvolve2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(423, 303)
        Me.Controls.Add(Me.lblCongrats)
        Me.Controls.Add(Me.LblNow)
        Me.Controls.Add(Me.lblPre)
        Me.Controls.Add(Me.BtnCLose)
        Me.Controls.Add(Me.imgNow)
        Me.Controls.Add(Me.imgPre)
        Me.Name = "frmEvolve2"
        Me.Text = "frmEvolve2"
        CType(Me.imgNow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgPre, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents imgPre As System.Windows.Forms.PictureBox
    Friend WithEvents imgNow As System.Windows.Forms.PictureBox
    Friend WithEvents BtnCLose As System.Windows.Forms.Button
    Friend WithEvents lblPre As System.Windows.Forms.Label
    Friend WithEvents LblNow As System.Windows.Forms.Label
    Friend WithEvents lblCongrats As System.Windows.Forms.Label
End Class
