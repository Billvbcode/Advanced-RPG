﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmConnect
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.CmdDoor = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.LblFrom = New System.Windows.Forms.Label()
        Me.LblTo = New System.Windows.Forms.Label()
        Me.TxtName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LblMap1 = New System.Windows.Forms.Label()
        Me.LblMap2 = New System.Windows.Forms.Label()
        Me.CmdName = New System.Windows.Forms.Button()
        Me.CmdConnect = New System.Windows.Forms.Button()
        Me.LblTitle = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.LblSave = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.BtnPlay = New System.Windows.Forms.Button()
        Me.DGrid = New System.Windows.Forms.DataGridView()
        Me.Dgrid2 = New System.Windows.Forms.DataGridView()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.CmnHidden = New System.Windows.Forms.Button()
        CType(Me.DGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Dgrid2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(310, 501)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(117, 108)
        Me.ListBox1.TabIndex = 26
        '
        'CmdDoor
        '
        Me.CmdDoor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdDoor.Location = New System.Drawing.Point(12, 201)
        Me.CmdDoor.Name = "CmdDoor"
        Me.CmdDoor.Size = New System.Drawing.Size(62, 33)
        Me.CmdDoor.TabIndex = 29
        Me.CmdDoor.Text = "Doors"
        Me.CmdDoor.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(91, 201)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 33)
        Me.Button1.TabIndex = 30
        Me.Button1.Text = "People"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(189, 201)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(62, 33)
        Me.Button2.TabIndex = 31
        Me.Button2.Text = "Chest"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'LblFrom
        '
        Me.LblFrom.AutoSize = True
        Me.LblFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblFrom.Location = New System.Drawing.Point(19, 241)
        Me.LblFrom.Name = "LblFrom"
        Me.LblFrom.Size = New System.Drawing.Size(55, 16)
        Me.LblFrom.TabIndex = 32
        Me.LblFrom.Text = "Label1"
        '
        'LblTo
        '
        Me.LblTo.AutoSize = True
        Me.LblTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTo.Location = New System.Drawing.Point(426, 241)
        Me.LblTo.Name = "LblTo"
        Me.LblTo.Size = New System.Drawing.Size(55, 16)
        Me.LblTo.TabIndex = 33
        Me.LblTo.Text = "Label1"
        '
        'TxtName
        '
        Me.TxtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtName.Location = New System.Drawing.Point(505, 237)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(148, 22)
        Me.TxtName.TabIndex = 34
        Me.TxtName.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(112, 259)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Click"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(560, 259)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 36
        Me.Label2.Text = "Click"
        '
        'LblMap1
        '
        Me.LblMap1.AutoSize = True
        Me.LblMap1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMap1.Location = New System.Drawing.Point(19, 176)
        Me.LblMap1.Name = "LblMap1"
        Me.LblMap1.Size = New System.Drawing.Size(0, 16)
        Me.LblMap1.TabIndex = 37
        '
        'LblMap2
        '
        Me.LblMap2.AutoSize = True
        Me.LblMap2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMap2.Location = New System.Drawing.Point(573, 111)
        Me.LblMap2.Name = "LblMap2"
        Me.LblMap2.Size = New System.Drawing.Size(0, 16)
        Me.LblMap2.TabIndex = 38
        '
        'CmdName
        '
        Me.CmdName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdName.Location = New System.Drawing.Point(173, 498)
        Me.CmdName.Name = "CmdName"
        Me.CmdName.Size = New System.Drawing.Size(87, 33)
        Me.CmdName.TabIndex = 39
        Me.CmdName.Text = "AddName"
        Me.CmdName.UseVisualStyleBackColor = True
        Me.CmdName.Visible = False
        '
        'CmdConnect
        '
        Me.CmdConnect.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdConnect.Location = New System.Drawing.Point(0, 498)
        Me.CmdConnect.Name = "CmdConnect"
        Me.CmdConnect.Size = New System.Drawing.Size(142, 33)
        Me.CmdConnect.TabIndex = 40
        Me.CmdConnect.Text = "Connect"
        Me.CmdConnect.UseVisualStyleBackColor = True
        Me.CmdConnect.Visible = False
        '
        'LblTitle
        '
        Me.LblTitle.AutoSize = True
        Me.LblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTitle.Location = New System.Drawing.Point(342, 9)
        Me.LblTitle.Name = "LblTitle"
        Me.LblTitle.Size = New System.Drawing.Size(55, 16)
        Me.LblTitle.TabIndex = 41
        Me.LblTitle.Text = "Label1"
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(279, 201)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(87, 33)
        Me.Button3.TabIndex = 42
        Me.Button3.Text = "Quest"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(384, 201)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(87, 33)
        Me.Button4.TabIndex = 43
        Me.Button4.Text = "Give"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(580, 198)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(87, 33)
        Me.Button5.TabIndex = 44
        Me.Button5.Text = "Need"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(433, 498)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(87, 33)
        Me.Button6.TabIndex = 45
        Me.Button6.Text = "MakeMap"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(540, 498)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(87, 33)
        Me.Button7.TabIndex = 46
        Me.Button7.Text = "CopyMAp"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'LblSave
        '
        Me.LblSave.AutoSize = True
        Me.LblSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSave.Location = New System.Drawing.Point(19, 593)
        Me.LblSave.Name = "LblSave"
        Me.LblSave.Size = New System.Drawing.Size(0, 16)
        Me.LblSave.TabIndex = 47
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(674, 536)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(109, 55)
        Me.RichTextBox1.TabIndex = 56
        Me.RichTextBox1.Text = ""
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(644, 498)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(87, 33)
        Me.Button8.TabIndex = 57
        Me.Button8.Text = "SPeech"
        Me.Button8.UseVisualStyleBackColor = True
        Me.Button8.Visible = False
        '
        'BtnPlay
        '
        Me.BtnPlay.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPlay.Location = New System.Drawing.Point(696, 201)
        Me.BtnPlay.Name = "BtnPlay"
        Me.BtnPlay.Size = New System.Drawing.Size(87, 33)
        Me.BtnPlay.TabIndex = 58
        Me.BtnPlay.Text = "Play"
        Me.BtnPlay.UseVisualStyleBackColor = True
        '
        'DGrid
        '
        Me.DGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGrid.Location = New System.Drawing.Point(12, 275)
        Me.DGrid.Name = "DGrid"
        Me.DGrid.Size = New System.Drawing.Size(367, 202)
        Me.DGrid.TabIndex = 59
        '
        'Dgrid2
        '
        Me.Dgrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgrid2.Location = New System.Drawing.Point(416, 275)
        Me.Dgrid2.Name = "Dgrid2"
        Me.Dgrid2.Size = New System.Drawing.Size(367, 202)
        Me.Dgrid2.TabIndex = 60
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(641, 58)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(89, 28)
        Me.Button9.TabIndex = 61
        Me.Button9.Text = "Button9"
        Me.Button9.UseVisualStyleBackColor = True
        Me.Button9.UseWaitCursor = True
        Me.Button9.Visible = False
        '
        'CmnHidden
        '
        Me.CmnHidden.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmnHidden.Location = New System.Drawing.Point(487, 198)
        Me.CmnHidden.Name = "CmnHidden"
        Me.CmnHidden.Size = New System.Drawing.Size(87, 33)
        Me.CmnHidden.TabIndex = 62
        Me.CmnHidden.Text = "Hidden"
        Me.CmnHidden.UseVisualStyleBackColor = True
        '
        'FrmConnect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(795, 618)
        Me.Controls.Add(Me.CmnHidden)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Dgrid2)
        Me.Controls.Add(Me.DGrid)
        Me.Controls.Add(Me.BtnPlay)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.LblSave)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.LblTitle)
        Me.Controls.Add(Me.CmdConnect)
        Me.Controls.Add(Me.CmdName)
        Me.Controls.Add(Me.LblMap2)
        Me.Controls.Add(Me.LblMap1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtName)
        Me.Controls.Add(Me.LblTo)
        Me.Controls.Add(Me.LblFrom)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.CmdDoor)
        Me.Controls.Add(Me.ListBox1)
        Me.Name = "FrmConnect"
        Me.Text = "FrmConnect"
        CType(Me.DGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Dgrid2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents CmdDoor As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents LblFrom As System.Windows.Forms.Label
    Friend WithEvents LblTo As System.Windows.Forms.Label
    Friend WithEvents TxtName As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents LblMap1 As System.Windows.Forms.Label
    Friend WithEvents LblMap2 As System.Windows.Forms.Label
    Friend WithEvents CmdName As System.Windows.Forms.Button
    Friend WithEvents CmdConnect As System.Windows.Forms.Button
    Friend WithEvents LblTitle As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents LblSave As System.Windows.Forms.Label
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents BtnPlay As System.Windows.Forms.Button
    Friend WithEvents DGrid As System.Windows.Forms.DataGridView
    Friend WithEvents Dgrid2 As DataGridView
    Friend WithEvents Button9 As Button
    Friend WithEvents CmnHidden As Button
End Class
