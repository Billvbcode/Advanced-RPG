﻿Public Class ClsSaveMap
    Private strChestItem As String
    Private strStoreItem As String
    Private strName As String
    Private strMytype As String
    Private iMapCnt As Integer
    Private mElements As Integer
    Private mStrArray(99) As String
    Private mStrArray2(99) As String
    Private mStrArray3(99) As String
    Private mStrArray4(99) As String
    Private lCount As Long
    Public Property Count() As Long
        Get
            Return mElements
        End Get
        Set(ByVal Value As Long)
            lCount = Value
        End Set
    End Property
    Public Property SaveMap4(ByVal test_number As Integer) As String
        Get
            Return mStrArray4(test_number)
        End Get
        Set(ByVal Value As String)
            mStrArray4(test_number) = Value
        End Set
    End Property
    Public Property SaveMap3(ByVal test_number As Integer) As String
        Get
            Return mStrArray3(test_number)
        End Get
        Set(ByVal Value As String)
            mStrArray3(test_number) = Value
        End Set
    End Property
    Public Property SaveMap2(ByVal test_number As Integer) As String
        Get
            Return mStrArray2(test_number)
        End Get
        Set(ByVal Value As String)
            mStrArray2(test_number) = Value
        End Set
    End Property
    Public Property SaveMap(ByVal test_number As Integer) As String
        Get
            Return mStrArray(test_number)
        End Get
        Set(ByVal Value As String)
            mStrArray(test_number) = Value
            mElements = test_number + 1
        End Set
    End Property
    Public Sub Clear()
        mElements = 0
    End Sub
    Public Property MapCnt() As Integer      'Foe Description
        Get
            Return iMapCnt
        End Get
        Set(ByVal Value As Integer)
            iMapCnt = Value
        End Set
    End Property
    Public Property Mytype() As String      'Foe Description
        Get
            Return strMytype
        End Get
        Set(ByVal Value As String)
            strMytype = Value
        End Set
    End Property
    Public Property Name() As String      'Foe Description
        Get
            Return strName
        End Get
        Set(ByVal Value As String)
            strName = Value
        End Set
    End Property
    Public Property StoreItem() As String      'Foe Description
        Get
            Return strStoreItem
        End Get
        Set(ByVal Value As String)
            strStoreItem = Value
        End Set
    End Property
    Public Property ChestItem() As String      'Foe Description
        Get
            Return strChestItem
        End Get
        Set(ByVal Value As String)
            strChestItem = Value
        End Set
    End Property
End Class
