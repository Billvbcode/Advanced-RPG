﻿Public Class FrmEdit
    Public Sub SaveDoor(ByVal cMapfile As String)
        Dim cMsg As String
        Dim strMap As String
        Dim strMap2 As String
        Dim strMap3 As String
        Dim MYFILE As String
        Dim J As Integer
        Dim value As String = My.Application.Info.DirectoryPath
        '
        'Door File
        MYFILE = value & "\Maps\" & cMapfile & "d.txt"
        Dim srFileWrite As New System.IO.StreamWriter(MYFILE)
        srFileWrite.WriteLine("xxxxyyyyNewxNewy")
        For Each doors In nDoors
            If doors.Mytype = "DOOR" Then
                cMsg = Format(doors.DooriX, "0000") & Format(doors.DoorIy, "0000")
                cMsg = cMsg & Format(doors.DooriToX, "0000") & Format(doors.DooriToy, "0000") & doors.Name
                srFileWrite.WriteLine(cMsg)
            End If
        Next
        srFileWrite.Close()
        '
        ' Save people file
        '
        MYFILE = value & "\Maps\" & cMapfile & "p.txt"
        Dim srFileReader As System.IO.StreamReader
        srFileReader = System.IO.File.OpenText(MYFILE)
        strMap = srFileReader.ReadLine() ' Normal/Cave/Wild/Store
        strMap2 = srFileReader.ReadLine() ' Store Items
        strMap3 = srFileReader.ReadLine() ' Chest Item
        srFileReader.Close()
        Dim srFileWrite2 As New System.IO.StreamWriter(MYFILE)
        srFileWrite2.WriteLine(strMap)
        srFileWrite2.WriteLine(strMap2)
        srFileWrite2.WriteLine(strMap3)
        For Each doors In nDoors
            If doors.Mytype = "TALK" Then
                J = InStr(doors.Name, ":")
                If J = 0 Then doors.Name = doors.Name & ":"
                cMsg = Format(doors.DooriX, "0000") & Format(doors.DooriY, "0000")
                cMsg = cMsg & Format(doors.DooriToX, "0000") & Format(doors.DooriToY, "0000") & doors.Name
                srFileWrite2.WriteLine(cMsg)
            End If

        Next
        srFileWrite2.Close()
        '
        '
        '
        MYFILE = value & "\Maps\" & cMapfile & "f.txt"
        Dim srFileWrite3 As New System.IO.StreamWriter(MYFILE)
        srFileWrite3.WriteLine("xxxxyyyyTileName")
        For Each doors In nDoors
            If doors.Mytype = "FIX" Then
                cMsg = Format(doors.DooriX, "0000") & Format(doors.DoorIy, "0000")
                cMsg = cMsg & doors.Name
                srFileWrite3.WriteLine(cMsg)
            End If

        Next
        srFileWrite3.Close()
    End Sub

    Private Sub SwitchLayer()
        Dim i As Integer
        If CheckTop.Checked Then
            For i = m144 + 1 To iLAstTile
                PB(i).Visible = True
            Next
        Else
            For i = m144 + 1 To iLAstTile
                PB(i).Visible = False
            Next
            For Each cTile In nTiles
                If cTile.TileType = "ITEM" Then
                    i = cTile.MyTileCnt + m144
                    PB(i).Visible = True
                End If
            Next
        End If
    End Sub

    Private Sub ReadTile()
        Dim cAddTile
        FileTile = My.Application.Info.DirectoryPath & "\tiles\"
        For Each cTile In nTiles
            iTileloc = cTile.MyTileCnt + m144
            cAddTile = cTile.TileName
            If UCase(cTile.TileAddName) <> "NONE" Then

                cAddTile = cTile.TileName & cTile.TileAddName
            End If
            FileTile = My.Application.Info.DirectoryPath & "\tiles\" & cAddTile & ".bmp"
            sToolTip = cTile.TileAddName 'ctilecTile.TileName
            'zzTile(iTileloc).Image = Image.FromFile(FileTile)
            'ShowTile()
            PB(iTileloc).Image = Image.FromFile(FileTile)
            Me.ToolTip1.SetToolTip(PB(iTileloc), cAddTile)
            PB(iTileloc).Tag = cAddTile
            bNewLevel = False
            If cTile.MyTileCnt = 1 Then
                imgAll.Image = PB(iTileloc).Image
                imgAll.Tag = PB(iTileloc).Tag
                LblAll.Text = cTile.TileLet
                LblName.Text = cTile.TileName
                Me.ToolTip1.SetToolTip(imgAll, LblName.Text)
            End If
            iLAstTile = cTile.MyTileCnt + m144
        Next
        ' ReadMapFile(cMapFile)
    End Sub
    Private Sub GetFiles()
        '
        ' Read all the levels
        '
        Dim value As String = My.Application.Info.DirectoryPath & "\Maps\"
        Dim di As New IO.DirectoryInfo(value)
        Dim diar1 As IO.FileInfo() = di.GetFiles("*.1ap")
        Dim dra As IO.FileInfo
        Dim sMsg As String
        sMsg = value
        'list the names of all files in the specified directory
        For Each dra In diar1
            ListBox1.Items.Add(dra)
        Next
    End Sub
    Public Sub DrawIt2()
        Dim kk As Integer
        Dim PositionMap As String
        Dim cEvent As String
        Dim cDesc As String
        Dim mPB As Integer
        mPB = 1
        txtX.Text = XSB.Value
        TxtY.Text = YSB.Value
        For Y = 1 To 12
            For X = 1 To 24
                'If the result to Paint is 0 then it will get error.
                'This will prevent this.
                'PassToNext = 0
                If Y + YSB.Value + 0 < 1 Then Exit Sub
                If X + XSB.Value + 0 < 1 Then Exit Sub
                If X + XSB.Value + 0 > Len(Map(1)) Then Exit Sub
                If Y + YSB.Value + 0 > 99 Then Exit Sub
                If CheckTop.Checked Then
                    PositionMap = Mid(Map(Y + YSB.Value + 1), (X + XSB.Value + 1), 1) & Mid(Map2(Y + YSB.Value + 1), (X + XSB.Value + 1), 1)
                Else
                    PositionMap = Mid(Map3(Y + YSB.Value + 1), (X + XSB.Value + 1), 1) & Mid(Map4(Y + YSB.Value + 1), (X + XSB.Value + 1), 1)
                End If
                If Y = 4 And X = 6 Then
                    kk = 1
                End If
                'If X = 0 And Y = 0 Then GoTo skip:
                For Each cTile In nTiles
                    'add all events and descriptions
                    cEvent = cTile.TileLet 'ctile.letter
                    cDesc = cTile.TileName 'tiles.Name
                    If cEvent = PositionMap Then
                        If UCase(cTile.TileType) = "ITEM" Then
                            kk = 1
                        End If
                        'ImgPaint = LoadPicture(App.Path & "\tiles\" & cDesc & ".jpg")
                        PB(mPB).Image = PB(cTile.MyTileCnt + m144).Image
                        mPB = mPB + 1
                    End If

                    'Text1.Text = Text1.Text & cEvent & " -- " & cDesc & Chr(13) & Chr(10)
                Next
            Next
        Next
        Y = 3

    End Sub
    Private Sub FrmEdit_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim kLR As Integer
        Dim kUD As Integer
        Dim m As Integer
        bPlayGame = False
        SAVE_MapLoaded = ""
        GetFiles()
        ReadTiles()
        CheckTop.Checked = True
        m144 = 330
        OptNormal.Checked = True
        OptNormal.BackColor = Color.LightGreen

        bNewLevel = True
        FileTile = My.Application.Info.DirectoryPath & "\tiles\grass.bmp"
        For kUD = 1 To 12
            For kLR = 1 To 24
                m = kLR + kUD * 24 - 24
                PB(m) = New System.Windows.Forms.PictureBox()
                With PB(m)
                    .Name = m
                    .Location = New System.Drawing.Point(30 * kLR - 10, 30 * kUD - 5)
                    .Size = New Size(30, 30)
                End With

                '  This is the line that sometimes catches people out!
                '  This is the line that sometimes catches people out!
                Me.Controls.Add(PB(m))
                AddHandler PB(m).Click, AddressOf pbe_Click
                Me.ToolTip1.SetToolTip(PB(m), m)
            Next
        Next
        For kUD = 1 To 10
            For kLR = 1 To 25
                m = kLR + kUD * 25 - 25 + m144
                PB(m) = New System.Windows.Forms.PictureBox()
                With PB(m)
                    .Name = m
                    .Location = New System.Drawing.Point(30 * kLR - 20, 30 * kUD + 385)
                    .Size = New Size(30, 30)
                    .Tag = ""
                    ' .Visible = False
                End With

                '  This is the line that sometimes catches people out!
                Me.Controls.Add(PB(m))
                AddHandler PB(m).Click, AddressOf pbe_Click
            Next
        Next

        ReadTile()

    End Sub
    Private Sub pbe_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim cmsg As PictureBox
        cmsg = sender
        Dim i As Integer
        Dim j As Integer
        Dim icx As Integer
        Dim icy As Integer
        Dim  cAddTile As String
        i = Val(cmsg.Name)
        If i > m144 Then
            lblSpot.Text = "I=" & i - m144
            imgAll.Image = PB(i).Image
            imgAll.Tag = PB(i).Tag
            For Each cTile In nTiles
                cAddTile = cTile.TileName
                If UCase(cTile.TileAddName) <> "NONE" Then
                    cAddTile = cTile.TileName & cTile.TileAddName
                End If
                If imgAll.Tag = cAddTile Then
                    LblName.Text = cTile.TileName
                    LblAll.Text = cTile.TileLet
                    Me.ToolTip1.SetToolTip(imgAll, LblName.Text)
                    LblType.Text = cTile.TileType
                End If
            Next
        Else
            TxtLoc.Text = i
            icy = Int((i - 1) / 24) ' + 1
            TxtY.Text = i & " " & icy
            MapY.Text = icy
            icx = i - icy * 24 + XSB.Value + 1
            txtX.Text = icx
            If icx < 1 Then
                j = 1
            End If
            icy = icy + 1 + YSB.Value + 1
            MapY.Text = icy
            MapX.Text = icx
            If CheckTop.Checked Then
                Mid(Map(icy), icx, 1) = Mid(LblAll.Text, 1, 1)
                Mid(Map2(icy), icx, 1) = Mid(LblAll.Text, 2, 1)
                Mid(Map3(icy), icx, 1) = Mid(LblAll.Text, 1, 1)
                Mid(Map4(icy), icx, 1) = Mid(LblAll.Text, 2, 1)
            Else
                If LblType.Text = "ITEM" Then
                    Mid(Map3(icy), icx, 1) = Mid(LblAll.Text, 1, 1)
                    Mid(Map4(icy), icx, 1) = Mid(LblAll.Text, 2, 1)
                End If
            End If
            DrawIt2()
        End If
    End Sub

    Private Sub ListBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.Click
        OptNormal.Checked = True
        OptNormal.BackColor = Color.LightGreen
        XSB.Value = 0
        YSB.Value = 0
        iWildLevel = 0
        TxtMap.Text = Mid(ListBox1.Text, 1, Len(ListBox1.Text) - 4)
        cMapFile = TxtMap.Text
        SAVE_MapLoaded = cMapFile
        ReadDoorFile(cMapFile)
        OPTshop.Checked = bStore
        OptDark.Checked = bDark
        If iWildLevel > 0 Then OptWild.Checked = True
        bDark = False
        ReadMapFile(cMapFile)
        DrawIt2()
        
        WildLevel.Text = iWildLevel
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub XSB_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles XSB.Scroll
        DrawIt2()
    End Sub

    Private Sub YSB_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles YSB.Scroll
        DrawIt2()
    End Sub

    Private Sub CheckHidden_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckHidden.CheckedChanged
        If CheckHidden.Checked Then
            CheckTop.Checked = False
            CheckTop.BackColor = Color.White
            CheckHidden.BackColor = Color.LightGreen
            LblLayer.Text = "Hidden Layer"
        Else
            CheckTop.Checked = True
            CheckTop.BackColor = Color.LightGreen
            CheckHidden.BackColor = Color.White
            LblLayer.Text = "Top Layer"
        End If
        SwitchLayer()
    End Sub

    Private Sub CheckTop_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckTop.CheckedChanged
        If CheckTop.Checked Then
            CheckHidden.Checked = False
            CheckTop.BackColor = Color.LightGreen
            CheckHidden.BackColor = Color.White
            LblLayer.Text = "Top Layer"
        Else
            CheckHidden.Checked = True
            CheckTop.BackColor = Color.White
            CheckHidden.BackColor = Color.LightGreen
            LblLayer.Text = "Hidden Layer"
        End If
        SwitchLayer()
    End Sub

    Private Sub BtnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim srFileReader As System.IO.StreamReader
        Dim cFile As String
        Dim sTag As String
        Dim strMap As String
        Call CheckFiles(TxtMap.Text)
        Call SaveMapFile(TxtMap.Text)
        Call SaveDoor(TxtMap.Text)
        SAVE_MapLoaded = TxtMap.Text
        'bMakeshop = True
        If OPTshop.Checked Then
            FrmStore.ShowDialog()
            '    Unload(Me)
        End If
        cFile = My.Application.Info.DirectoryPath & "\Maps\" & TxtMap.Text & "p.txt"
        srFileReader = System.IO.File.OpenText(cFile)
        sTag = srFileReader.ReadLine()
        sTag = srFileReader.ReadLine()
        RichTextBox1.Text = ""
        strMap = srFileReader.ReadLine()
        Do While (Not strMap Is Nothing)
            RichTextBox1.Text = RichTextBox1.Text & strMap & vbCrLf
            strMap = srFileReader.ReadLine()
        Loop
        srFileReader.Close()
        '    '        '
        Dim srFileWrite As New System.IO.StreamWriter(cFile)
        If OptDark.Checked Then srFileWrite.WriteLine("CAVE")
        If OptNormal.Checked Then srFileWrite.WriteLine("NORMAL")
        If OptWild.Checked Then srFileWrite.WriteLine("WILD" & Format(Val(WildLevel.Text), "0000"))
        If OPTshop.Checked Then
            srFileWrite.WriteLine("STORE")
            srFileWrite.WriteLine(sStoreItems)
        Else
            srFileWrite.WriteLine("")
        End If
        srFileWrite.WriteLine(RichTextBox1.Text)
        srFileWrite.Close()

    End Sub

    Private Sub OPTshop_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OPTshop.CheckedChanged
        OptWild.BackColor = Color.White
        OPTshop.BackColor = Color.White
        OptDark.BackColor = Color.White
        OptNormal.BackColor = Color.White
        If OptWild.Checked Then OptWild.BackColor = Color.LightGreen
        If OPTshop.Checked Then OPTshop.BackColor = Color.LightGreen
        If OptDark.Checked Then OptDark.BackColor = Color.LightGreen
        If OptNormal.Checked Then OptNormal.BackColor = Color.LightGreen
    End Sub

    Private Sub OptNormal_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OptNormal.CheckedChanged
        OptWild.BackColor = Color.White
        OPTshop.BackColor = Color.White
        OptDark.BackColor = Color.White
        OptNormal.BackColor = Color.White
        If OptWild.Checked Then OptWild.BackColor = Color.LightGreen
        If OPTshop.Checked Then OPTshop.BackColor = Color.LightGreen
        If OptDark.Checked Then OptDark.BackColor = Color.LightGreen
        If OptNormal.Checked Then OptNormal.BackColor = Color.LightGreen
    End Sub

    Private Sub OptWild_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OptWild.CheckedChanged
        OptWild.BackColor = Color.White
        OPTshop.BackColor = Color.White
        OptDark.BackColor = Color.White
        OptNormal.BackColor = Color.White
        If OptWild.Checked Then OptWild.BackColor = Color.LightGreen
        If OPTshop.Checked Then OPTshop.BackColor = Color.LightGreen
        If OptDark.Checked Then OptDark.BackColor = Color.LightGreen
        If OptNormal.Checked Then OptNormal.BackColor = Color.LightGreen
    End Sub

    Private Sub OptDark_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OptDark.CheckedChanged
        OptWild.BackColor = Color.White
        OPTshop.BackColor = Color.White
        OptDark.BackColor = Color.White
        OptNormal.BackColor = Color.White
        If OptWild.Checked Then OptWild.BackColor = Color.LightGreen
        If OPTshop.Checked Then OPTshop.BackColor = Color.LightGreen
        If OptDark.Checked Then OptDark.BackColor = Color.LightGreen
        If OptNormal.Checked Then OptNormal.BackColor = Color.LightGreen
    End Sub

    
    Private Sub BtnSpeech_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSpeech.Click
        If SAVE_MapLoaded <> "" Then FrmSpeech.ShowDialog()
    End Sub
End Class