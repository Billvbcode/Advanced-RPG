﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSpeech2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CmdSave = New System.Windows.Forms.Button()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Text1 = New System.Windows.Forms.TextBox()
        Me.DGrid = New System.Windows.Forms.DataGridView()
        Me.DFix = New System.Windows.Forms.DataGridView()
        Me.DItems = New System.Windows.Forms.DataGridView()
        Me.DMap = New System.Windows.Forms.DataGridView()
        Me.RB3 = New System.Windows.Forms.RadioButton()
        Me.RB2 = New System.Windows.Forms.RadioButton()
        Me.RB1 = New System.Windows.Forms.RadioButton()
        CType(Me.DGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DFix, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DMap, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CmdSave
        '
        Me.CmdSave.Location = New System.Drawing.Point(359, 21)
        Me.CmdSave.Name = "CmdSave"
        Me.CmdSave.Size = New System.Drawing.Size(69, 24)
        Me.CmdSave.TabIndex = 12
        Me.CmdSave.Text = "Save"
        Me.CmdSave.UseVisualStyleBackColor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(12, 65)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(459, 542)
        Me.RichTextBox1.TabIndex = 11
        Me.RichTextBox1.Text = ""
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(248, 18)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(74, 28)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Read"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Text1
        '
        Me.Text1.Location = New System.Drawing.Point(12, 18)
        Me.Text1.Name = "Text1"
        Me.Text1.Size = New System.Drawing.Size(148, 20)
        Me.Text1.TabIndex = 9
        '
        'DGrid
        '
        Me.DGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGrid.Location = New System.Drawing.Point(495, 41)
        Me.DGrid.Name = "DGrid"
        Me.DGrid.Size = New System.Drawing.Size(268, 168)
        Me.DGrid.TabIndex = 60
        '
        'DFix
        '
        Me.DFix.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DFix.Location = New System.Drawing.Point(495, 227)
        Me.DFix.Name = "DFix"
        Me.DFix.Size = New System.Drawing.Size(268, 125)
        Me.DFix.TabIndex = 61
        '
        'DItems
        '
        Me.DItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DItems.Location = New System.Drawing.Point(495, 368)
        Me.DItems.Name = "DItems"
        Me.DItems.Size = New System.Drawing.Size(268, 130)
        Me.DItems.TabIndex = 62
        '
        'DMap
        '
        Me.DMap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DMap.Location = New System.Drawing.Point(495, 519)
        Me.DMap.Name = "DMap"
        Me.DMap.Size = New System.Drawing.Size(268, 119)
        Me.DMap.TabIndex = 63
        '
        'RB3
        '
        Me.RB3.AutoSize = True
        Me.RB3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB3.Location = New System.Drawing.Point(317, 615)
        Me.RB3.Name = "RB3"
        Me.RB3.Size = New System.Drawing.Size(70, 20)
        Me.RB3.TabIndex = 66
        Me.RB3.TabStop = True
        Me.RB3.Text = "Pence"
        Me.RB3.UseVisualStyleBackColor = True
        '
        'RB2
        '
        Me.RB2.AutoSize = True
        Me.RB2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB2.Location = New System.Drawing.Point(154, 618)
        Me.RB2.Name = "RB2"
        Me.RB2.Size = New System.Drawing.Size(82, 20)
        Me.RB2.TabIndex = 65
        Me.RB2.TabStop = True
        Me.RB2.Text = "Thought"
        Me.RB2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RB2.UseVisualStyleBackColor = True
        '
        'RB1
        '
        Me.RB1.AutoSize = True
        Me.RB1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB1.Location = New System.Drawing.Point(38, 618)
        Me.RB1.Name = "RB1"
        Me.RB1.Size = New System.Drawing.Size(79, 20)
        Me.RB1.TabIndex = 64
        Me.RB1.TabStop = True
        Me.RB1.Text = "Speech"
        Me.RB1.UseVisualStyleBackColor = True
        '
        'FrmSpeech2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(815, 668)
        Me.Controls.Add(Me.RB3)
        Me.Controls.Add(Me.RB2)
        Me.Controls.Add(Me.RB1)
        Me.Controls.Add(Me.DMap)
        Me.Controls.Add(Me.DItems)
        Me.Controls.Add(Me.DFix)
        Me.Controls.Add(Me.DGrid)
        Me.Controls.Add(Me.CmdSave)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Text1)
        Me.Name = "FrmSpeech2"
        Me.Text = "FrmSpeech2"
        CType(Me.DGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DFix, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DMap, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CmdSave As Button
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Text1 As TextBox
    Friend WithEvents DGrid As DataGridView
    Friend WithEvents DFix As DataGridView
    Friend WithEvents DItems As DataGridView
    Friend WithEvents DMap As DataGridView
    Friend WithEvents RB3 As RadioButton
    Friend WithEvents RB2 As RadioButton
    Friend WithEvents RB1 As RadioButton
End Class
