﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmFight))
        Me.FlexPoko = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.FlexSelect = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.TxtMyPoko = New System.Windows.Forms.TextBox()
        Me.TxtMyLevel = New System.Windows.Forms.TextBox()
        Me.TxtLevel = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnRedo = New System.Windows.Forms.Button()
        Me.BntClear = New System.Windows.Forms.Button()
        Me.enActivePkmn = New System.Windows.Forms.PictureBox()
        Me.LblName = New System.Windows.Forms.Label()
        Me.BtnDone = New System.Windows.Forms.Button()
        CType(Me.FlexPoko, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FlexSelect, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.enActivePkmn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FlexPoko
        '
        Me.FlexPoko.Location = New System.Drawing.Point(12, 39)
        Me.FlexPoko.Name = "FlexPoko"
        Me.FlexPoko.OcxState = CType(resources.GetObject("FlexPoko.OcxState"), System.Windows.Forms.AxHost.State)
        Me.FlexPoko.Size = New System.Drawing.Size(252, 370)
        Me.FlexPoko.TabIndex = 0
        '
        'FlexSelect
        '
        Me.FlexSelect.Location = New System.Drawing.Point(492, 12)
        Me.FlexSelect.Name = "FlexSelect"
        Me.FlexSelect.OcxState = CType(resources.GetObject("FlexSelect.OcxState"), System.Windows.Forms.AxHost.State)
        Me.FlexSelect.Size = New System.Drawing.Size(263, 349)
        Me.FlexSelect.TabIndex = 1
        '
        'TxtMyPoko
        '
        Me.TxtMyPoko.Location = New System.Drawing.Point(379, 389)
        Me.TxtMyPoko.Name = "TxtMyPoko"
        Me.TxtMyPoko.Size = New System.Drawing.Size(335, 20)
        Me.TxtMyPoko.TabIndex = 2
        '
        'TxtMyLevel
        '
        Me.TxtMyLevel.Location = New System.Drawing.Point(379, 437)
        Me.TxtMyLevel.Name = "TxtMyLevel"
        Me.TxtMyLevel.Size = New System.Drawing.Size(335, 20)
        Me.TxtMyLevel.TabIndex = 3
        '
        'TxtLevel
        '
        Me.TxtLevel.Location = New System.Drawing.Point(367, 50)
        Me.TxtLevel.Name = "TxtLevel"
        Me.TxtLevel.Size = New System.Drawing.Size(41, 20)
        Me.TxtLevel.TabIndex = 4
        Me.TxtLevel.Text = "10"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(279, 54)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 16)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "BaseLevel"
        '
        'BtnRedo
        '
        Me.BtnRedo.Location = New System.Drawing.Point(342, 12)
        Me.BtnRedo.Name = "BtnRedo"
        Me.BtnRedo.Size = New System.Drawing.Size(66, 30)
        Me.BtnRedo.TabIndex = 6
        Me.BtnRedo.Text = "Redo"
        Me.BtnRedo.UseVisualStyleBackColor = True
        '
        'BntClear
        '
        Me.BntClear.Location = New System.Drawing.Point(282, 257)
        Me.BntClear.Name = "BntClear"
        Me.BntClear.Size = New System.Drawing.Size(66, 30)
        Me.BntClear.TabIndex = 7
        Me.BntClear.Text = "Clear"
        Me.BntClear.UseVisualStyleBackColor = True
        '
        'enActivePkmn
        '
        Me.enActivePkmn.Location = New System.Drawing.Point(367, 108)
        Me.enActivePkmn.Name = "enActivePkmn"
        Me.enActivePkmn.Size = New System.Drawing.Size(113, 80)
        Me.enActivePkmn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.enActivePkmn.TabIndex = 20
        Me.enActivePkmn.TabStop = False
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblName.Location = New System.Drawing.Point(279, 136)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(0, 16)
        Me.LblName.TabIndex = 21
        '
        'BtnDone
        '
        Me.BtnDone.Location = New System.Drawing.Point(388, 257)
        Me.BtnDone.Name = "BtnDone"
        Me.BtnDone.Size = New System.Drawing.Size(66, 30)
        Me.BtnDone.TabIndex = 22
        Me.BtnDone.Text = "Done"
        Me.BtnDone.UseVisualStyleBackColor = True
        '
        'FrmFight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(793, 482)
        Me.Controls.Add(Me.BtnDone)
        Me.Controls.Add(Me.LblName)
        Me.Controls.Add(Me.enActivePkmn)
        Me.Controls.Add(Me.BntClear)
        Me.Controls.Add(Me.BtnRedo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtLevel)
        Me.Controls.Add(Me.TxtMyLevel)
        Me.Controls.Add(Me.TxtMyPoko)
        Me.Controls.Add(Me.FlexSelect)
        Me.Controls.Add(Me.FlexPoko)
        Me.Name = "FrmFight"
        Me.Text = "FrmFight"
        CType(Me.FlexPoko, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FlexSelect, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.enActivePkmn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents FlexPoko As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents FlexSelect As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents TxtMyPoko As System.Windows.Forms.TextBox
    Friend WithEvents TxtMyLevel As System.Windows.Forms.TextBox
    Friend WithEvents TxtLevel As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BtnRedo As System.Windows.Forms.Button
    Friend WithEvents BntClear As System.Windows.Forms.Button
    Friend WithEvents enActivePkmn As System.Windows.Forms.PictureBox
    Friend WithEvents LblName As System.Windows.Forms.Label
    Friend WithEvents BtnDone As System.Windows.Forms.Button
End Class
