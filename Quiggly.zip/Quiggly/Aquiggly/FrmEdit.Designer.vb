﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmEdit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtMap = New System.Windows.Forms.TextBox()
        Me.imgAll = New System.Windows.Forms.PictureBox()
        Me.LblAll = New System.Windows.Forms.Label()
        Me.LblName = New System.Windows.Forms.Label()
        Me.XSB = New System.Windows.Forms.HScrollBar()
        Me.YSB = New System.Windows.Forms.VScrollBar()
        Me.TxtY = New System.Windows.Forms.TextBox()
        Me.txtX = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.MapY = New System.Windows.Forms.TextBox()
        Me.MapX = New System.Windows.Forms.TextBox()
        Me.TxtLoc = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LblType = New System.Windows.Forms.Label()
        Me.CheckTop = New System.Windows.Forms.CheckBox()
        Me.CheckHidden = New System.Windows.Forms.CheckBox()
        Me.LblLayer = New System.Windows.Forms.Label()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.OPTshop = New System.Windows.Forms.RadioButton()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.OptDark = New System.Windows.Forms.RadioButton()
        Me.OptNormal = New System.Windows.Forms.RadioButton()
        Me.OptWild = New System.Windows.Forms.RadioButton()
        Me.WildLevel = New System.Windows.Forms.TextBox()
        Me.BtnSpeech = New System.Windows.Forms.Button()
        Me.lblSpot = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.imgAll, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(774, 451)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(117, 147)
        Me.ListBox1.TabIndex = 26
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(810, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 13)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Map"
        '
        'TxtMap
        '
        Me.TxtMap.Location = New System.Drawing.Point(841, 18)
        Me.TxtMap.Name = "TxtMap"
        Me.TxtMap.Size = New System.Drawing.Size(71, 20)
        Me.TxtMap.TabIndex = 32
        '
        'imgAll
        '
        Me.imgAll.Location = New System.Drawing.Point(841, 314)
        Me.imgAll.Name = "imgAll"
        Me.imgAll.Size = New System.Drawing.Size(32, 32)
        Me.imgAll.TabIndex = 34
        Me.imgAll.TabStop = False
        '
        'LblAll
        '
        Me.LblAll.AutoSize = True
        Me.LblAll.Location = New System.Drawing.Point(838, 349)
        Me.LblAll.Name = "LblAll"
        Me.LblAll.Size = New System.Drawing.Size(39, 13)
        Me.LblAll.TabIndex = 35
        Me.LblAll.Text = "Label2"
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.Location = New System.Drawing.Point(879, 323)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(39, 13)
        Me.LblName.TabIndex = 36
        Me.LblName.Text = "Label2"
        '
        'XSB
        '
        Me.XSB.Location = New System.Drawing.Point(-1, 391)
        Me.XSB.Maximum = 90
        Me.XSB.Name = "XSB"
        Me.XSB.Size = New System.Drawing.Size(749, 25)
        Me.XSB.TabIndex = 37
        '
        'YSB
        '
        Me.YSB.Location = New System.Drawing.Point(744, 18)
        Me.YSB.Maximum = 90
        Me.YSB.Name = "YSB"
        Me.YSB.Size = New System.Drawing.Size(32, 361)
        Me.YSB.TabIndex = 38
        '
        'TxtY
        '
        Me.TxtY.Location = New System.Drawing.Point(841, 43)
        Me.TxtY.Name = "TxtY"
        Me.TxtY.Size = New System.Drawing.Size(58, 20)
        Me.TxtY.TabIndex = 40
        '
        'txtX
        '
        Me.txtX.Location = New System.Drawing.Point(841, 72)
        Me.txtX.Name = "txtX"
        Me.txtX.Size = New System.Drawing.Size(58, 20)
        Me.txtX.TabIndex = 39
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(811, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(14, 13)
        Me.Label2.TabIndex = 41
        Me.Label2.Text = "X"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(811, 50)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(14, 13)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Y"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(803, 120)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 46
        Me.Label4.Text = "MapY"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(803, 152)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "MapX"
        '
        'MapY
        '
        Me.MapY.Location = New System.Drawing.Point(841, 117)
        Me.MapY.Name = "MapY"
        Me.MapY.Size = New System.Drawing.Size(58, 20)
        Me.MapY.TabIndex = 44
        '
        'MapX
        '
        Me.MapX.Location = New System.Drawing.Point(841, 152)
        Me.MapX.Name = "MapX"
        Me.MapX.Size = New System.Drawing.Size(58, 20)
        Me.MapX.TabIndex = 43
        '
        'TxtLoc
        '
        Me.TxtLoc.Location = New System.Drawing.Point(841, 191)
        Me.TxtLoc.Name = "TxtLoc"
        Me.TxtLoc.Size = New System.Drawing.Size(58, 20)
        Me.TxtLoc.TabIndex = 47
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(800, 191)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(25, 13)
        Me.Label6.TabIndex = 48
        Me.Label6.Text = "Loc"
        '
        'LblType
        '
        Me.LblType.AutoSize = True
        Me.LblType.Location = New System.Drawing.Point(756, 323)
        Me.LblType.Name = "LblType"
        Me.LblType.Size = New System.Drawing.Size(39, 13)
        Me.LblType.TabIndex = 49
        Me.LblType.Text = "Label2"
        '
        'CheckTop
        '
        Me.CheckTop.AutoSize = True
        Me.CheckTop.Location = New System.Drawing.Point(775, 417)
        Me.CheckTop.Name = "CheckTop"
        Me.CheckTop.Size = New System.Drawing.Size(71, 17)
        Me.CheckTop.TabIndex = 50
        Me.CheckTop.Text = "TopLayer"
        Me.CheckTop.UseVisualStyleBackColor = True
        '
        'CheckHidden
        '
        Me.CheckHidden.AutoSize = True
        Me.CheckHidden.Location = New System.Drawing.Point(852, 417)
        Me.CheckHidden.Name = "CheckHidden"
        Me.CheckHidden.Size = New System.Drawing.Size(60, 17)
        Me.CheckHidden.TabIndex = 51
        Me.CheckHidden.Text = "Hidden"
        Me.CheckHidden.UseVisualStyleBackColor = True
        '
        'LblLayer
        '
        Me.LblLayer.AutoSize = True
        Me.LblLayer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLayer.Location = New System.Drawing.Point(231, 0)
        Me.LblLayer.Name = "LblLayer"
        Me.LblLayer.Size = New System.Drawing.Size(79, 16)
        Me.LblLayer.TabIndex = 52
        Me.LblLayer.Text = "Top Layer"
        '
        'BtnSave
        '
        Me.BtnSave.Location = New System.Drawing.Point(759, 382)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(67, 29)
        Me.BtnSave.TabIndex = 53
        Me.BtnSave.Text = "Save"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'OPTshop
        '
        Me.OPTshop.AutoSize = True
        Me.OPTshop.Location = New System.Drawing.Point(841, 222)
        Me.OPTshop.Name = "OPTshop"
        Me.OPTshop.Size = New System.Drawing.Size(50, 17)
        Me.OPTshop.TabIndex = 54
        Me.OPTshop.TabStop = True
        Me.OPTshop.Text = "Shop"
        Me.OPTshop.UseVisualStyleBackColor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(686, 616)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(109, 55)
        Me.RichTextBox1.TabIndex = 55
        Me.RichTextBox1.Text = ""
        Me.RichTextBox1.Visible = False
        '
        'OptDark
        '
        Me.OptDark.AutoSize = True
        Me.OptDark.Location = New System.Drawing.Point(759, 245)
        Me.OptDark.Name = "OptDark"
        Me.OptDark.Size = New System.Drawing.Size(79, 17)
        Me.OptDark.TabIndex = 56
        Me.OptDark.TabStop = True
        Me.OptDark.Text = "Dark C ave"
        Me.OptDark.UseVisualStyleBackColor = True
        '
        'OptNormal
        '
        Me.OptNormal.AutoSize = True
        Me.OptNormal.Location = New System.Drawing.Point(759, 222)
        Me.OptNormal.Name = "OptNormal"
        Me.OptNormal.Size = New System.Drawing.Size(56, 17)
        Me.OptNormal.TabIndex = 57
        Me.OptNormal.TabStop = True
        Me.OptNormal.Text = "Nornal"
        Me.OptNormal.UseVisualStyleBackColor = True
        '
        'OptWild
        '
        Me.OptWild.AutoSize = True
        Me.OptWild.Location = New System.Drawing.Point(759, 268)
        Me.OptWild.Name = "OptWild"
        Me.OptWild.Size = New System.Drawing.Size(94, 17)
        Me.OptWild.TabIndex = 58
        Me.OptWild.TabStop = True
        Me.OptWild.Text = "Wild Pokemon"
        Me.OptWild.UseVisualStyleBackColor = True
        '
        'WildLevel
        '
        Me.WildLevel.Location = New System.Drawing.Point(852, 255)
        Me.WildLevel.Name = "WildLevel"
        Me.WildLevel.Size = New System.Drawing.Size(58, 20)
        Me.WildLevel.TabIndex = 59
        '
        'BtnSpeech
        '
        Me.BtnSpeech.Location = New System.Drawing.Point(858, 382)
        Me.BtnSpeech.Name = "BtnSpeech"
        Me.BtnSpeech.Size = New System.Drawing.Size(60, 29)
        Me.BtnSpeech.TabIndex = 60
        Me.BtnSpeech.Text = "Speech"
        Me.BtnSpeech.UseVisualStyleBackColor = True
        '
        'lblSpot
        '
        Me.lblSpot.AutoSize = True
        Me.lblSpot.Location = New System.Drawing.Point(756, 349)
        Me.lblSpot.Name = "lblSpot"
        Me.lblSpot.Size = New System.Drawing.Size(39, 13)
        Me.lblSpot.TabIndex = 61
        Me.lblSpot.Text = "Label2"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(831, 616)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(60, 29)
        Me.Button1.TabIndex = 62
        Me.Button1.Text = "Speech"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'FrmEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(929, 683)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblSpot)
        Me.Controls.Add(Me.BtnSpeech)
        Me.Controls.Add(Me.WildLevel)
        Me.Controls.Add(Me.OptWild)
        Me.Controls.Add(Me.OptNormal)
        Me.Controls.Add(Me.OptDark)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.OPTshop)
        Me.Controls.Add(Me.BtnSave)
        Me.Controls.Add(Me.LblLayer)
        Me.Controls.Add(Me.CheckHidden)
        Me.Controls.Add(Me.CheckTop)
        Me.Controls.Add(Me.LblType)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.TxtLoc)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.MapY)
        Me.Controls.Add(Me.MapX)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TxtY)
        Me.Controls.Add(Me.txtX)
        Me.Controls.Add(Me.YSB)
        Me.Controls.Add(Me.XSB)
        Me.Controls.Add(Me.LblName)
        Me.Controls.Add(Me.LblAll)
        Me.Controls.Add(Me.imgAll)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtMap)
        Me.Controls.Add(Me.ListBox1)
        Me.Name = "FrmEdit"
        Me.Text = "FrmEdit"
        CType(Me.imgAll, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtMap As System.Windows.Forms.TextBox
    Friend WithEvents imgAll As System.Windows.Forms.PictureBox
    Friend WithEvents LblAll As System.Windows.Forms.Label
    Friend WithEvents LblName As System.Windows.Forms.Label
    Friend WithEvents XSB As System.Windows.Forms.HScrollBar
    Friend WithEvents YSB As System.Windows.Forms.VScrollBar
    Friend WithEvents TxtY As System.Windows.Forms.TextBox
    Friend WithEvents txtX As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents MapY As System.Windows.Forms.TextBox
    Friend WithEvents MapX As System.Windows.Forms.TextBox
    Friend WithEvents TxtLoc As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LblType As System.Windows.Forms.Label
    Friend WithEvents CheckTop As System.Windows.Forms.CheckBox
    Friend WithEvents CheckHidden As System.Windows.Forms.CheckBox
    Friend WithEvents LblLayer As System.Windows.Forms.Label
    Friend WithEvents BtnSave As System.Windows.Forms.Button
    Friend WithEvents OPTshop As System.Windows.Forms.RadioButton
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents OptDark As System.Windows.Forms.RadioButton
    Friend WithEvents OptNormal As System.Windows.Forms.RadioButton
    Friend WithEvents OptWild As System.Windows.Forms.RadioButton
    Friend WithEvents WildLevel As System.Windows.Forms.TextBox
    Friend WithEvents BtnSpeech As System.Windows.Forms.Button
    Friend WithEvents lblSpot As Label
    Friend WithEvents Button1 As Button
End Class
