﻿Public Class frmEvolve2

    Private Sub BtnCLose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCLose.Click
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub frmEvolve2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class