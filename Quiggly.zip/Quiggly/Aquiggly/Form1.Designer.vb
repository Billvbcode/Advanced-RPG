﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.imgLeftChar = New System.Windows.Forms.PictureBox()
        Me.imgRightChar = New System.Windows.Forms.PictureBox()
        Me.imgUpChar = New System.Windows.Forms.PictureBox()
        Me.imgDownChar = New System.Windows.Forms.PictureBox()
        Me.imgCarryChar = New System.Windows.Forms.PictureBox()
        Me.txtX = New System.Windows.Forms.TextBox()
        Me.TxtY = New System.Windows.Forms.TextBox()
        Me.TxtName = New System.Windows.Forms.TextBox()
        Me.TxtType = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Pitanje = New System.Windows.Forms.Label()
        Me.TxtMap = New System.Windows.Forms.TextBox()
        Me.LblTicket = New System.Windows.Forms.Label()
        Me.LblWood = New System.Windows.Forms.Label()
        Me.LblMagic = New System.Windows.Forms.Label()
        Me.LblToast = New System.Windows.Forms.Label()
        Me.LblCoin = New System.Windows.Forms.Label()
        Me.LblBomb = New System.Windows.Forms.Label()
        Me.LblJar = New System.Windows.Forms.Label()
        Me.TxtLet = New System.Windows.Forms.TextBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Imgboat1 = New System.Windows.Forms.PictureBox()
        Me.Imgboat2 = New System.Windows.Forms.PictureBox()
        Me.Imgboat3 = New System.Windows.Forms.PictureBox()
        Me.Imgboat = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LblLevel = New System.Windows.Forms.Label()
        Me.LblBunny = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.LblMe = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LblLight = New System.Windows.Forms.Label()
        Me.Lbl1 = New System.Windows.Forms.Label()
        Me.LblFill = New System.Windows.Forms.Label()
        Me.LblGrow = New System.Windows.Forms.Label()
        Me.LblCut = New System.Windows.Forms.Label()
        Me.LblDestroy = New System.Windows.Forms.Label()
        Me.LblAxe = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MapsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SpeechToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TimBunny = New System.Windows.Forms.Timer(Me.components)
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.DGrid = New System.Windows.Forms.DataGridView()
        Me.TimMove = New System.Windows.Forms.Timer(Me.components)
        Me.Label14 = New System.Windows.Forms.Label()
        CType(Me.imgLeftChar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgRightChar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgUpChar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgDownChar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgCarryChar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.Imgboat1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Imgboat2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Imgboat3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Imgboat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.DGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(622, 336)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(126, 34)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(622, 396)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(118, 30)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'imgLeftChar
        '
        Me.imgLeftChar.Location = New System.Drawing.Point(622, 560)
        Me.imgLeftChar.Name = "imgLeftChar"
        Me.imgLeftChar.Size = New System.Drawing.Size(32, 32)
        Me.imgLeftChar.TabIndex = 3
        Me.imgLeftChar.TabStop = False
        Me.imgLeftChar.Visible = False
        '
        'imgRightChar
        '
        Me.imgRightChar.Location = New System.Drawing.Point(660, 560)
        Me.imgRightChar.Name = "imgRightChar"
        Me.imgRightChar.Size = New System.Drawing.Size(32, 32)
        Me.imgRightChar.TabIndex = 4
        Me.imgRightChar.TabStop = False
        Me.imgRightChar.Visible = False
        '
        'imgUpChar
        '
        Me.imgUpChar.Location = New System.Drawing.Point(708, 560)
        Me.imgUpChar.Name = "imgUpChar"
        Me.imgUpChar.Size = New System.Drawing.Size(32, 32)
        Me.imgUpChar.TabIndex = 5
        Me.imgUpChar.TabStop = False
        Me.imgUpChar.Visible = False
        '
        'imgDownChar
        '
        Me.imgDownChar.Location = New System.Drawing.Point(622, 612)
        Me.imgDownChar.Name = "imgDownChar"
        Me.imgDownChar.Size = New System.Drawing.Size(32, 32)
        Me.imgDownChar.TabIndex = 6
        Me.imgDownChar.TabStop = False
        Me.imgDownChar.Visible = False
        '
        'imgCarryChar
        '
        Me.imgCarryChar.Location = New System.Drawing.Point(660, 612)
        Me.imgCarryChar.Name = "imgCarryChar"
        Me.imgCarryChar.Size = New System.Drawing.Size(32, 32)
        Me.imgCarryChar.TabIndex = 7
        Me.imgCarryChar.TabStop = False
        Me.imgCarryChar.Visible = False
        '
        'txtX
        '
        Me.txtX.Enabled = False
        Me.txtX.Location = New System.Drawing.Point(634, 432)
        Me.txtX.Name = "txtX"
        Me.txtX.Size = New System.Drawing.Size(58, 20)
        Me.txtX.TabIndex = 8
        '
        'TxtY
        '
        Me.TxtY.Enabled = False
        Me.TxtY.Location = New System.Drawing.Point(634, 458)
        Me.TxtY.Name = "TxtY"
        Me.TxtY.Size = New System.Drawing.Size(58, 20)
        Me.TxtY.TabIndex = 9
        '
        'TxtName
        '
        Me.TxtName.Enabled = False
        Me.TxtName.Location = New System.Drawing.Point(634, 484)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(58, 20)
        Me.TxtName.TabIndex = 10
        '
        'TxtType
        '
        Me.TxtType.Enabled = False
        Me.TxtType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtType.Location = New System.Drawing.Point(634, 510)
        Me.TxtType.Name = "TxtType"
        Me.TxtType.Size = New System.Drawing.Size(58, 26)
        Me.TxtType.TabIndex = 11
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Pitanje)
        Me.Panel1.Location = New System.Drawing.Point(21, 43)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(579, 271)
        Me.Panel1.TabIndex = 12
        Me.Panel1.Visible = False
        '
        'Pitanje
        '
        Me.Pitanje.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pitanje.Location = New System.Drawing.Point(23, 9)
        Me.Pitanje.Name = "Pitanje"
        Me.Pitanje.Size = New System.Drawing.Size(476, 38)
        Me.Pitanje.TabIndex = 0
        Me.Pitanje.Text = "Label1"
        '
        'TxtMap
        '
        Me.TxtMap.Enabled = False
        Me.TxtMap.Location = New System.Drawing.Point(658, 11)
        Me.TxtMap.Name = "TxtMap"
        Me.TxtMap.Size = New System.Drawing.Size(71, 20)
        Me.TxtMap.TabIndex = 15
        '
        'LblTicket
        '
        Me.LblTicket.AutoSize = True
        Me.LblTicket.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTicket.Location = New System.Drawing.Point(28, 360)
        Me.LblTicket.Name = "LblTicket"
        Me.LblTicket.Size = New System.Drawing.Size(16, 16)
        Me.LblTicket.TabIndex = 16
        Me.LblTicket.Text = "0"
        '
        'LblWood
        '
        Me.LblWood.AutoSize = True
        Me.LblWood.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblWood.Location = New System.Drawing.Point(58, 360)
        Me.LblWood.Name = "LblWood"
        Me.LblWood.Size = New System.Drawing.Size(16, 16)
        Me.LblWood.TabIndex = 17
        Me.LblWood.Text = "0"
        '
        'LblMagic
        '
        Me.LblMagic.AutoSize = True
        Me.LblMagic.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMagic.Location = New System.Drawing.Point(88, 360)
        Me.LblMagic.Name = "LblMagic"
        Me.LblMagic.Size = New System.Drawing.Size(16, 16)
        Me.LblMagic.TabIndex = 18
        Me.LblMagic.Text = "0"
        '
        'LblToast
        '
        Me.LblToast.AutoSize = True
        Me.LblToast.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblToast.Location = New System.Drawing.Point(116, 360)
        Me.LblToast.Name = "LblToast"
        Me.LblToast.Size = New System.Drawing.Size(16, 16)
        Me.LblToast.TabIndex = 19
        Me.LblToast.Text = "0"
        '
        'LblCoin
        '
        Me.LblCoin.AutoSize = True
        Me.LblCoin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCoin.Location = New System.Drawing.Point(147, 360)
        Me.LblCoin.Name = "LblCoin"
        Me.LblCoin.Size = New System.Drawing.Size(16, 16)
        Me.LblCoin.TabIndex = 21
        Me.LblCoin.Text = "0"
        '
        'LblBomb
        '
        Me.LblBomb.AutoSize = True
        Me.LblBomb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblBomb.Location = New System.Drawing.Point(181, 360)
        Me.LblBomb.Name = "LblBomb"
        Me.LblBomb.Size = New System.Drawing.Size(16, 16)
        Me.LblBomb.TabIndex = 22
        Me.LblBomb.Text = "0"
        '
        'LblJar
        '
        Me.LblJar.AutoSize = True
        Me.LblJar.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.LblJar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJar.Location = New System.Drawing.Point(127, 0)
        Me.LblJar.Name = "LblJar"
        Me.LblJar.Size = New System.Drawing.Size(55, 16)
        Me.LblJar.TabIndex = 23
        Me.LblJar.Text = "Label1"
        Me.LblJar.Visible = False
        '
        'TxtLet
        '
        Me.TxtLet.Enabled = False
        Me.TxtLet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLet.Location = New System.Drawing.Point(634, 536)
        Me.TxtLet.Name = "TxtLet"
        Me.TxtLet.Size = New System.Drawing.Size(58, 26)
        Me.TxtLet.TabIndex = 24
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(622, 102)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(117, 43)
        Me.ListBox1.TabIndex = 25
        Me.ListBox1.Visible = False
        '
        'Imgboat1
        '
        Me.Imgboat1.Location = New System.Drawing.Point(622, 650)
        Me.Imgboat1.Name = "Imgboat1"
        Me.Imgboat1.Size = New System.Drawing.Size(32, 32)
        Me.Imgboat1.TabIndex = 27
        Me.Imgboat1.TabStop = False
        Me.Imgboat1.Visible = False
        '
        'Imgboat2
        '
        Me.Imgboat2.Location = New System.Drawing.Point(660, 650)
        Me.Imgboat2.Name = "Imgboat2"
        Me.Imgboat2.Size = New System.Drawing.Size(32, 32)
        Me.Imgboat2.TabIndex = 28
        Me.Imgboat2.TabStop = False
        Me.Imgboat2.Visible = False
        '
        'Imgboat3
        '
        Me.Imgboat3.Location = New System.Drawing.Point(622, 688)
        Me.Imgboat3.Name = "Imgboat3"
        Me.Imgboat3.Size = New System.Drawing.Size(32, 32)
        Me.Imgboat3.TabIndex = 29
        Me.Imgboat3.TabStop = False
        Me.Imgboat3.Visible = False
        '
        'Imgboat
        '
        Me.Imgboat.Location = New System.Drawing.Point(660, 688)
        Me.Imgboat.Name = "Imgboat"
        Me.Imgboat.Size = New System.Drawing.Size(32, 32)
        Me.Imgboat.TabIndex = 30
        Me.Imgboat.TabStop = False
        Me.Imgboat.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(619, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 13)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "Map"
        '
        'LblLevel
        '
        Me.LblLevel.AutoSize = True
        Me.LblLevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLevel.Location = New System.Drawing.Point(606, 54)
        Me.LblLevel.Name = "LblLevel"
        Me.LblLevel.Size = New System.Drawing.Size(14, 13)
        Me.LblLevel.TabIndex = 32
        Me.LblLevel.Text = "0"
        '
        'LblBunny
        '
        Me.LblBunny.AutoSize = True
        Me.LblBunny.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblBunny.Location = New System.Drawing.Point(606, 33)
        Me.LblBunny.Name = "LblBunny"
        Me.LblBunny.Size = New System.Drawing.Size(14, 13)
        Me.LblBunny.TabIndex = 33
        Me.LblBunny.Text = "0"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel2.Controls.Add(Me.LblMe)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.LblLight)
        Me.Panel2.Controls.Add(Me.Lbl1)
        Me.Panel2.Controls.Add(Me.LblFill)
        Me.Panel2.Controls.Add(Me.LblGrow)
        Me.Panel2.Controls.Add(Me.LblCut)
        Me.Panel2.Controls.Add(Me.LblDestroy)
        Me.Panel2.Controls.Add(Me.LblAxe)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(12, 420)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(579, 309)
        Me.Panel2.TabIndex = 34
        '
        'LblMe
        '
        Me.LblMe.AutoSize = True
        Me.LblMe.Location = New System.Drawing.Point(197, 19)
        Me.LblMe.Name = "LblMe"
        Me.LblMe.Size = New System.Drawing.Size(45, 13)
        Me.LblMe.TabIndex = 40
        Me.LblMe.Text = "Label14"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(294, 180)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(125, 16)
        Me.Label11.TabIndex = 39
        Me.Label11.Text = "----Commands----"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(288, 286)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 16)
        Me.Label4.TabIndex = 38
        Me.Label4.Text = "L - Light Darkness"
        Me.Label4.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(424, 260)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(105, 16)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "V - View Store"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(288, 260)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(112, 16)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "S - Save Game"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(424, 234)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(112, 16)
        Me.Label7.TabIndex = 35
        Me.Label7.Text = "R - Load Game"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(288, 234)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 16)
        Me.Label8.TabIndex = 34
        Me.Label8.Text = "M - Show Map"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(424, 208)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(56, 16)
        Me.Label9.TabIndex = 33
        Me.Label9.Text = "E - Exit"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(288, 208)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(106, 16)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "B - Bomb Wall"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(291, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 16)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "----Spells----"
        '
        'LblLight
        '
        Me.LblLight.AutoSize = True
        Me.LblLight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLight.Location = New System.Drawing.Point(288, 120)
        Me.LblLight.Name = "LblLight"
        Me.LblLight.Size = New System.Drawing.Size(132, 16)
        Me.LblLight.TabIndex = 30
        Me.LblLight.Text = "L - Light Darkness"
        '
        'Lbl1
        '
        Me.Lbl1.AutoSize = True
        Me.Lbl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl1.Location = New System.Drawing.Point(424, 94)
        Me.Lbl1.Name = "Lbl1"
        Me.Lbl1.Size = New System.Drawing.Size(120, 16)
        Me.Lbl1.TabIndex = 29
        Me.Lbl1.Text = "1,2,3 - Transport"
        '
        'LblFill
        '
        Me.LblFill.AutoSize = True
        Me.LblFill.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblFill.Location = New System.Drawing.Point(288, 94)
        Me.LblFill.Name = "LblFill"
        Me.LblFill.Size = New System.Drawing.Size(105, 16)
        Me.LblFill.TabIndex = 28
        Me.LblFill.Text = "F - Fill Swamp"
        '
        'LblGrow
        '
        Me.LblGrow.AutoSize = True
        Me.LblGrow.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblGrow.Location = New System.Drawing.Point(424, 68)
        Me.LblGrow.Name = "LblGrow"
        Me.LblGrow.Size = New System.Drawing.Size(112, 16)
        Me.LblGrow.TabIndex = 27
        Me.LblGrow.Text = "G - Grow Grass"
        '
        'LblCut
        '
        Me.LblCut.AutoSize = True
        Me.LblCut.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCut.Location = New System.Drawing.Point(288, 68)
        Me.LblCut.Name = "LblCut"
        Me.LblCut.Size = New System.Drawing.Size(98, 16)
        Me.LblCut.TabIndex = 26
        Me.LblCut.Text = "C - Cut Weed"
        '
        'LblDestroy
        '
        Me.LblDestroy.AutoSize = True
        Me.LblDestroy.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDestroy.Location = New System.Drawing.Point(424, 42)
        Me.LblDestroy.Name = "LblDestroy"
        Me.LblDestroy.Size = New System.Drawing.Size(126, 16)
        Me.LblDestroy.TabIndex = 25
        Me.LblDestroy.Text = "D - Destroy Rock"
        '
        'LblAxe
        '
        Me.LblAxe.AutoSize = True
        Me.LblAxe.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAxe.Location = New System.Drawing.Point(288, 42)
        Me.LblAxe.Name = "LblAxe"
        Me.LblAxe.Size = New System.Drawing.Size(94, 16)
        Me.LblAxe.TabIndex = 24
        Me.LblAxe.Text = "A - Axe Tree"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(16, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(102, 16)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "----Badges----"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MapsToolStripMenuItem, Me.SpeechToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(752, 24)
        Me.MenuStrip1.TabIndex = 35
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MapsToolStripMenuItem
        '
        Me.MapsToolStripMenuItem.Name = "MapsToolStripMenuItem"
        Me.MapsToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.MapsToolStripMenuItem.Text = "Maps"
        '
        'SpeechToolStripMenuItem
        '
        Me.SpeechToolStripMenuItem.Name = "SpeechToolStripMenuItem"
        Me.SpeechToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.SpeechToolStripMenuItem.Text = "Speech"
        '
        'TimBunny
        '
        Me.TimBunny.Interval = 280
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(285, 396)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(45, 13)
        Me.Label12.TabIndex = 36
        Me.Label12.Text = "Label12"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(409, 396)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(45, 13)
        Me.Label13.TabIndex = 37
        Me.Label13.Text = "Label13"
        '
        'DGrid
        '
        Me.DGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.DGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGrid.Enabled = False
        Me.DGrid.Location = New System.Drawing.Point(412, 151)
        Me.DGrid.Name = "DGrid"
        Me.DGrid.Size = New System.Drawing.Size(327, 179)
        Me.DGrid.TabIndex = 38
        '
        'TimMove
        '
        Me.TimMove.Interval = 200
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(305, 3)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(45, 13)
        Me.Label14.TabIndex = 39
        Me.Label14.Text = "Label14"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(752, 732)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.DGrid)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.LblBunny)
        Me.Controls.Add(Me.LblLevel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Imgboat)
        Me.Controls.Add(Me.Imgboat3)
        Me.Controls.Add(Me.Imgboat2)
        Me.Controls.Add(Me.Imgboat1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.TxtLet)
        Me.Controls.Add(Me.LblJar)
        Me.Controls.Add(Me.LblBomb)
        Me.Controls.Add(Me.LblCoin)
        Me.Controls.Add(Me.LblToast)
        Me.Controls.Add(Me.LblMagic)
        Me.Controls.Add(Me.LblWood)
        Me.Controls.Add(Me.LblTicket)
        Me.Controls.Add(Me.TxtMap)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TxtType)
        Me.Controls.Add(Me.TxtName)
        Me.Controls.Add(Me.TxtY)
        Me.Controls.Add(Me.txtX)
        Me.Controls.Add(Me.imgCarryChar)
        Me.Controls.Add(Me.imgDownChar)
        Me.Controls.Add(Me.imgUpChar)
        Me.Controls.Add(Me.imgRightChar)
        Me.Controls.Add(Me.imgLeftChar)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.KeyPreview = true
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Game"
        CType(Me.imgLeftChar,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.imgRightChar,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.imgUpChar,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.imgDownChar,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.imgCarryChar,System.ComponentModel.ISupportInitialize).EndInit
        Me.Panel1.ResumeLayout(false)
        CType(Me.Imgboat1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.Imgboat2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.Imgboat3,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.Imgboat,System.ComponentModel.ISupportInitialize).EndInit
        Me.Panel2.ResumeLayout(false)
        Me.Panel2.PerformLayout
        Me.MenuStrip1.ResumeLayout(false)
        Me.MenuStrip1.PerformLayout
        CType(Me.DGrid,System.ComponentModel.ISupportInitialize).EndInit
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents imgLeftChar As System.Windows.Forms.PictureBox
    Friend WithEvents imgRightChar As System.Windows.Forms.PictureBox
    Friend WithEvents imgUpChar As System.Windows.Forms.PictureBox
    Friend WithEvents imgDownChar As System.Windows.Forms.PictureBox
    Friend WithEvents imgCarryChar As System.Windows.Forms.PictureBox
    Friend WithEvents txtX As System.Windows.Forms.TextBox
    Friend WithEvents TxtY As System.Windows.Forms.TextBox
    Friend WithEvents TxtName As System.Windows.Forms.TextBox
    Friend WithEvents TxtType As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Pitanje As System.Windows.Forms.Label
    Friend WithEvents TxtMap As System.Windows.Forms.TextBox
    Friend WithEvents LblTicket As System.Windows.Forms.Label
    Friend WithEvents LblWood As System.Windows.Forms.Label
    Friend WithEvents LblMagic As System.Windows.Forms.Label
    Friend WithEvents LblToast As System.Windows.Forms.Label
    Friend WithEvents LblCoin As System.Windows.Forms.Label
    Friend WithEvents LblBomb As System.Windows.Forms.Label
    Friend WithEvents LblJar As System.Windows.Forms.Label
    Friend WithEvents TxtLet As System.Windows.Forms.TextBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Imgboat1 As System.Windows.Forms.PictureBox
    Friend WithEvents Imgboat2 As System.Windows.Forms.PictureBox
    Friend WithEvents Imgboat3 As System.Windows.Forms.PictureBox
    Friend WithEvents Imgboat As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LblLevel As System.Windows.Forms.Label
    Friend WithEvents LblBunny As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents LblFill As System.Windows.Forms.Label
    Friend WithEvents LblGrow As System.Windows.Forms.Label
    Friend WithEvents LblCut As System.Windows.Forms.Label
    Friend WithEvents LblDestroy As System.Windows.Forms.Label
    Friend WithEvents LblAxe As System.Windows.Forms.Label
    Friend WithEvents Lbl1 As System.Windows.Forms.Label
    Friend WithEvents LblLight As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MapsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SpeechToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TimBunny As System.Windows.Forms.Timer
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents DGrid As System.Windows.Forms.DataGridView
    Friend WithEvents TimMove As Timer
    Friend WithEvents LblMe As Label
    Friend WithEvents Label14 As Label
End Class
