﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSplash
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Bar = New System.Windows.Forms.ProgressBar()
        Me.display = New System.Windows.Forms.Label()
        Me.tmrHeal = New System.Windows.Forms.Timer(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Bar
        '
        Me.Bar.Location = New System.Drawing.Point(65, 130)
        Me.Bar.Maximum = 50
        Me.Bar.Name = "Bar"
        Me.Bar.Size = New System.Drawing.Size(418, 64)
        Me.Bar.TabIndex = 0
        '
        'display
        '
        Me.display.AutoSize = True
        Me.display.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.display.ForeColor = System.Drawing.Color.RoyalBlue
        Me.display.Location = New System.Drawing.Point(85, 46)
        Me.display.Name = "display"
        Me.display.Size = New System.Drawing.Size(356, 37)
        Me.display.TabIndex = 1
        Me.display.Text = "Wild Pokemon Appear"
        '
        'tmrHeal
        '
        Me.tmrHeal.Interval = 20
        '
        'Timer1
        '
        Me.Timer1.Interval = 20
        '
        'frmSplash
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(568, 313)
        Me.Controls.Add(Me.display)
        Me.Controls.Add(Me.Bar)
        Me.Name = "frmSplash"
        Me.Text = "frmSplash"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Bar As System.Windows.Forms.ProgressBar
    Friend WithEvents display As System.Windows.Forms.Label
    Friend WithEvents tmrHeal As System.Windows.Forms.Timer
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
