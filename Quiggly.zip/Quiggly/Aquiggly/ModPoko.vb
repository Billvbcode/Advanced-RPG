﻿Module ModPoko
    Public optAttack(5) As RadioButton
    Public attacks
    Public enParty(10) As String
    Public enPartyLevel(10) As String
    Public enAttack(10) As String
    Public nagEvolve As Boolean
    Public enHasPP As Boolean
    Public pp As Integer
    Public Damage As Integer
    Public prevLyfValue As Integer
    Public atkType As String
    Public enType1 As String
    Public enType2 As String
    Public urType1 As String
    Public urType2 As String
    Public Type1 As String
    Public Type2 As String
    Public totalDamage As Integer
    Public iErr As Integer
    Public catchrate As Integer
    Public runRate As Integer
    Public evolutionName As String
    Public preEvolutionName As String
    Public bYouWin As Boolean
    Public sFilebug As String
    Public srFilebug As System.IO.StreamWriter
    Public sBugOut As String
    Public IName As String
    Public Sub SetPokoValue()
        For Each poko In nPoko
            If FrmBattle.urName.Text = poko.Name Then
                poko.Status = FrmBattle.urStat.Text
                poko.Value = FrmBattle.urLyf.Value
                Exit For
            End If
        Next

    End Sub
    Public Sub CurePoko()
        For Each poko In nPoko
            poko.Value = poko.Max
            poko.Status = "Nrml"
            poko.Hit1 = poko.Hit1M
            poko.Hit2 = poko.Hit2M
            poko.Hit3 = poko.Hit3M
            poko.Hit4 = poko.Hit4M
        Next
        frmSplash.display.Text = "Healing Pokemon"
        frmSplash.Timer1.Enabled = False
        frmSplash.tmrHeal.Enabled = True
        frmSplash.ShowDialog()
    End Sub
    Public Sub AddBadge()
        Dim i As Integer
        Dim bAddBadge As Boolean
        bAddBadge = False
        If iBadgecnt = 0 Then
            iBadgecnt = 1
            sBadge(1) = sGiveBadge
        Else
            bAddBadge = True
            For k = 1 To iBadgecnt
                If sBadge(1) = sGiveBadge Then bAddBadge = False
            Next
            If bAddBadge Then
                iBadgecnt = iBadgecnt + 1
                sBadge(iBadgecnt) = sGiveBadge
            End If
        End If
        '
        'Form1.Panel1.Visible = True

        ''For i = 0 To 7
        ''    FrmMake3.Choice(i).Visible = False
        ''Next
        'Form1.Pitanje.Text = speech.Name & " Here is the " & sGiveBadge & " Badge"
        'Form1.Choice(1).Text = "<Speech> Bye"
        'Form1.Choice(1).AutoSize = True
        'Form1.Choice(1).Visible = True
        'Form1.Choice(1).Tag = "0000"
    End Sub
    Public Sub descAttack(ByVal attack, ByVal pkmnTeam, ByVal args)
        Select Case attack

            Case "Bolt Tackle"
                Damage = 8
                atkType = "Electric"
                pp = 5
            Case "Take Down"
                Damage = 6
                atkType = "Normal"
                pp = 7
            Case "Flame Wheel"
                Damage = 6
                atkType = "Fire"
                pp = 8
            Case "Whirlwind"
                Damage = 6
                atkType = "Fying"
                pp = 8
            Case "Nightmare"
                Damage = 6
                atkType = "Dark"
                pp = 8
            Case "Dynamic Punch"
                Damage = 7
                atkType = "Fighting"
                pp = 6
            Case "Drain Punch"
                Damage = 7
                atkType = "Fighting"
                pp = 6
            Case "Sand Storm"
                Damage = 7
                atkType = "Ground"
                pp = 6
            Case "Close Combat"
                Damage = 7
                atkType = "Fighting"
                pp = 6
            Case "Cross Chop"
                Damage = 8
                atkType = "Fighting"
                pp = 5
            Case "Dragon Claw"
                Damage = 6
                atkType = "Dragon"
                pp = 8
            Case "Doom Desire"
                Damage = 8
                atkType = "Steel"
                pp = 5
            Case "Psywave"
                Damage = 6
                atkType = "Psychic"
                pp = 8
            Case "Lava Plume"
                Damage = 10
                atkType = "Fire"
                pp = 2
            Case "Attract"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Charm"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Cotton Spore"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Fire Punch"
                Damage = 6
                atkType = "Fire"
                pp = 8
            Case "Clamp"
                Damage = 6
                atkType = "Water"
                pp = 8
            Case "Amnesia"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Flail"
                Damage = 5
                atkType = "Normal"
                pp = 10
            Case "Vice Grip"
                Damage = 7
                atkType = "Normal"
                pp = 6
            Case "Dragon Rage"
                Damage = 7
                atkType = "Dragon"
                pp = 6
            Case "Night Slash"
                Damage = 8
                atkType = "Dark"
                pp = 5
            Case "Lick"
                Damage = 5
                atkType = "Dark"
                pp = 10
            Case "Dark Pulse"
                Damage = 7
                atkType = "Dark"
                pp = 6
            Case "Shadow Ball"
                Damage = 7
                atkType = "Dark"
                pp = 6
            Case "Spite"
                Damage = 4
                atkType = "Dark"
                pp = 10
            Case "Seed bomb"
                Damage = 8
                atkType = "Grass"
                pp = 5
            Case "Mega Horn"
                Damage = 12
                atkType = "Bug"
                pp = 1
            Case "Stomp"
                Damage = 6
                atkType = "Normal"
                pp = 8
            Case "Double Kick"
                Damage = 6
                atkType = "Fighting"
                pp = 8
            Case "Sludge"
                Damage = 6
                atkType = "Poison"
                pp = 7
            Case "Dig"
                Damage = 6
                atkType = "Ground"
                pp = 7
            Case "Magnitude"
                Damage = 7
                atkType = "Ground"
                pp = 6
            Case "Flash Cannon"
                Damage = 8
                atkType = "Steel"
                pp = 5
            Case "Energy Ball"
                Damage = 10
                atkType = "Grass"
                pp = 2
            Case "Giga Impact"
                Damage = 10
                atkType = "Normal"
                pp = 2
            Case "Hyper Beam"
                Damage = 9
                atkType = "Normal"
                pp = 2
            Case "Teleport"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Horn Drill"
                Damage = 10
                atkType = "Normal"
                pp = 2
            Case "Horn Attack"
                Damage = 6
                atkType = "Normal"
                pp = 8
            Case "Zap Cannon"
                Damage = 6
                atkType = "Electric"
                pp = 7
            Case "Sonic Boom"
                Damage = 7
                atkType = "Normal"
                pp = 6
            Case "Screech"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Shock Wave"
                Damage = 7
                atkType = "Electric"
                pp = 5
            Case "Thunder Punch"
                Damage = 6
                atkType = "Electric"
                pp = 8
            Case "Thunder Fang"
                Damage = 6
                atkType = "Electric"
                pp = 7
            Case "Rapid Spin"
                Damage = 4
                atkType = "Normal"
                pp = 7
            Case "Aurora Beam"
                Damage = 7
                atkType = "Ice"
                pp = 5
            Case "Ice Beam"
                Damage = 7
                atkType = "Ice"
                pp = 5
            Case "Psycho Boost"
                Damage = 7
                atkType = "Psychic"
                pp = 6
            Case "Aqua Tail"
                Damage = 6
                atkType = "Water"
                pp = 8
            Case "Charge Beam"
                Damage = 7
                atkType = "Electric"
                pp = 5
            Case "Charge"
                Damage = 6
                atkType = "Electric"
                pp = 6
            Case "Spark"
                Damage = 6
                atkType = "Electric"
                pp = 7
            Case "Helping Hands"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Night Shade"
                Damage = 6
                atkType = "Dark"
                pp = 7
            Case "Bug Buzz"
                Damage = 9
                atkType = "Bug"
                pp = 2
            Case "Eruption"
                Damage = 9
                atkType = "Fire"
                pp = 2
            Case "Flare Blitz"
                Damage = 9
                atkType = "Fire"
                pp = 2
            Case "Wood Hammer"
                Damage = 8
                atkType = "Grass"
                pp = 4
            Case "Leaf Storm"
                Damage = 9
                atkType = "Grass"
                pp = 2
            Case "Iron Tail"
                Damage = 6
                atkType = "Steel"
                pp = 7
            Case "Iron Head"
                Damage = 6
                atkType = "Steel"
                pp = 7
            Case "Ancient Power"
                Damage = 5
                atkType = "Rock"
                pp = 8
            Case "Super Power"
                Damage = 9
                atkType = "Fighting"
                pp = 2
            Case "Rollout"
                Damage = 5
                atkType = "Rock"
                pp = 8
            Case "Stone Edge"
                Damage = 8
                atkType = "Rock"
                pp = 5
            Case "Double Edge"
                Damage = 6
                atkType = "Normal"
                pp = 7
            Case "Rock Throw"
                Damage = 6
                atkType = "Rock"
                pp = 8
            Case "Rock Slide"
                Damage = 8
                atkType = "Rock"
                pp = 5
            Case "Thunder"
                Damage = 9
                atkType = "Electric"
                pp = 2
            Case "Thunder Bolt"
                Damage = 6
                atkType = "Electric"
                pp = 8
            Case "Thunder Shock"
                Damage = 5
                atkType = "Electric"
                pp = 10
            Case "Thrash"
                Damage = 7
                atkType = "Normal"
                pp = 5
            Case "Brave Bird"
                Damage = 8
                atkType = "Flying"
                pp = 5
            Case "Air Slash"
                Damage = 6
                atkType = "Flying"
                pp = 7
            Case "Cut"
                Damage = 4
                atkType = "Normal"
                pp = 10
            Case "Absorb"
                Damage = 5
                atkType = "Grass"
                pp = 10
            Case "Tackle"
                Damage = 4
                atkType = "Normal"
                pp = 10
            Case "Water Pulse"
                Damage = 7
                atkType = "Water"
                pp = 5
            Case "Hydro Cannon"
                Damage = 10
                atkType = "Water"
                pp = 2
            Case "Frenzy Plant"
                Damage = 10
                atkType = "Grass"
                pp = 2
            Case "Bubble Beam"
                Damage = 7
                atkType = "Water"
                pp = 6
            Case "Scratch"
                Damage = 4
                atkType = "Normal"
                pp = 10
            Case "Growl"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Tail Whip"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Leer"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Water Gun"
                Damage = 6
                atkType = "Water"
                pp = 7
            Case "Bubble"
                Damage = 5
                atkType = "Water"
                pp = 8
            Case "Ember"
                Damage = 5
                atkType = "Fire"
                pp = 8
            Case "Flame Thrower"
                Damage = 8
                atkType = "Fire"
                pp = 5
            Case "Peck"
                Damage = 5
                atkType = "Flying"
                pp = 10
            Case "Drill Peck"
                Damage = 7
                atkType = "Flying"
                pp = 6
            Case "Fly"
                Damage = 7
                atkType = "Flying"
                pp = 5
            Case "Gust"
                Damage = 5
                atkType = "Flying"
                pp = 8
            Case "Bite"
                Damage = 6
                atkType = "Dark"
                pp = 7

            Case "HeadBut"
                Damage = 6
                atkType = "Normal"
                pp = 7
            Case "Vine Whip"
                Damage = 6
                atkType = "Grass"
                pp = 8
            Case "Solar Beam"
                Damage = 10
                atkType = "Grass"
                pp = 2
            Case "Razor Leaf"
                Damage = 7
                atkType = "Grass"
                pp = 5
            Case "Sand Attack"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "Bullet Seed"
                Damage = 5
                atkType = "Grass"
                pp = 10
            Case "Leech Seed"
                Damage = 5
                atkType = "Grass"
                pp = 10
            Case "Pound"
                Damage = 5
                atkType = "Normal"
                pp = 10
            Case "Poison Sting"
                Damage = 5
                atkType = "Poison"
                pp = 10
            Case "Poison Tail"
                Damage = 7
                atkType = "Poison"
                pp = 6
            Case "Wrap"
                Damage = 3
                atkType = "Normal"
                pp = 15
            Case "Constrict"
                Damage = 4
                atkType = "Normal"
                pp = 10
            Case "Faint"
                Damage = 4
                atkType = "Dark"
                pp = 10
            Case "Quick Attack"
                Damage = 6
                atkType = "Normal"
                pp = 7
            Case "Confusion"
                Damage = 7
                atkType = "Psychic"
                pp = 6
            Case "Hyper Fang"
                Damage = 7
                atkType = "Normal"
                pp = 6
            Case "Mud Slap"
                Damage = 6
                atkType = "Ground"
                pp = 8
            Case "Mud Shot"
                Damage = 7
                atkType = "Ground"
                pp = 6
            Case "Dragon Breath"
                Damage = 7
                atkType = "Dragon"
                pp = 5
            Case "Hydro Pump"
                Damage = 8
                atkType = "Water"
                pp = 5
            Case "Body Slam"
                Damage = 8
                atkType = "Normal"
                pp = 5
            Case "Rapid Spin"
                Damage = 5
                atkType = "Normal"
                pp = 10
            Case "Metal Claw"
                Damage = 6
                atkType = "Steel"
                pp = 8
            Case "Fire Blast"
                Damage = 10
                atkType = "Fire"
                pp = 2
            Case "Blizzard"
                Damage = 10
                atkType = "Ice"
                pp = 2
            Case "Magical Leaf"
                Damage = 7
                atkType = "Grass"
                pp = 4
            Case "Crunch"
                Damage = 7
                atkType = "Dark"
                pp = 5
            Case "Focus Punch"
                Damage = 7
                atkType = "Fighting"
                pp = 5
            Case "Leaf Blade"
                Damage = 7
                atkType = "Grass"
                pp = 5
            Case "Giga Drain"
                Damage = 7
                atkType = "Grass"
                pp = 5
            Case "OverHeat"
                Damage = 8
                atkType = "Fire"
                pp = 5
            Case "Sky Uppercut"
                Damage = 8
                atkType = "Fighting"
                pp = 5
            Case "Earthquake"
                Damage = 9
                atkType = "Ground"
                pp = 3
            Case "Mud Water"
                Damage = 8
                atkType = "Water"
                pp = 5
            Case "Slash"
                Damage = 6
                atkType = "Normal"
                pp = 7
            Case "Brick Break"
                Damage = 6
                atkType = "Fighting"
                pp = 7
            Case "Focus Blast"
                Damage = 10
                atkType = "Fighting"
                pp = 2
            Case "Avalanche"
                Damage = 7
                atkType = "Ice"
                pp = 6
            Case "Pursuit"
                Damage = 4
                atkType = "Normal"
                pp = 10
            Case "Psybeam"
                Damage = 6
                atkType = "Psychic"
                pp = 7
            Case "Wing Attack"
                Damage = 7
                atkType = "Flying"
                pp = 5
            Case "Sky Attack"
                Damage = 8
                atkType = "Flying"
                pp = 5
            Case "Aerial Ace"
                Damage = 6
                atkType = "Flying"
                pp = 7
            Case "Pin Missile"
                Damage = 6
                atkType = "Bug"
                pp = 8
            Case "Fury Cutter"
                Damage = 7
                atkType = "Bug"
                pp = 7
            Case "Guilotine"
                Damage = 10
                atkType = "Normal"
                pp = 2
            Case "Mega Punch"
                Damage = 6
                atkType = "Fighting"
                pp = 7
            Case "Rock Tomb"
                Damage = 6
                atkType = "Rock"
                pp = 7
            Case "Barrage"
                Damage = 4
                atkType = "Normal"
                pp = 10
            Case "Psychic"
                Damage = 8
                atkType = "Psychic"
                pp = 5
            Case "Karate Chop"
                Damage = 6
                atkType = "Fighting"
                pp = 7
            Case "Low Kick"
                Damage = 5
                atkType = "Fighting"
                pp = 8
            Case "Mega Drain"
                Damage = 6
                atkType = "Grass"
                pp = 7
            Case "Fetal Dance"
                Damage = 6
                atkType = "Grass"
                pp = 7
            Case "Smog"
                Damage = 6
                atkType = "Poison"
                pp = 8
            Case "Poison Jab"
                Damage = 6
                atkType = "Poison"
                pp = 8
            Case "Future Sight"
                Damage = 0
                atkType = "Psychic"
                pp = 15
            Case "Seismic Toss"
                Damage = 7
                atkType = "Fighting"
                pp = 6
            Case "Smoke Screen"
                Damage = 0
                atkType = "Normal"
                pp = 15
            Case "X-Scissor"
                Damage = 8
                atkType = "Bug"
                pp = 5
            Case "Extreme Speed"
                Damage = 7
                atkType = "Normal"
                pp = 5

            Case "Sacred Fire"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Brn"
                    MsgBox(FrmBattle.enName.Text & " was burned", , "Pokemon Cawi Version")
                    Damage = 8
                ElseIf pkmnTeam = 3 Then
                    pp = 2
                Else
                    FrmBattle.urStat.Text = "Brn"
                    MsgBox(FrmBattle.urName.Text & " was burned", , "Pokemon Cawi Version")
                    Damage = 7
                    SetPokoValue()
                    'curStat.Add "Brn", , , args
                    'curStat.Remove args
                End If
            Case "Sheer Cold"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Frz"
                    MsgBox(FrmBattle.enName.Text & " was frozen solid", , "Pokemon Cawi Version")
                    Damage = 5
                ElseIf pkmnTeam = 3 Then
                    pp = 3
                Else
                    FrmBattle.urStat.Text = "Frz"
                    Damage = 5
                    MsgBox(FrmBattle.urName.Text & " was frozen solid", , "Pokemon Cawi Version")
                    SetPokoValue()
                    ' curStat.Add "Frz", , , args
                    'curStat.Remove args
                End If
            Case "Poison Gas"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Psn"
                    MsgBox(FrmBattle.enName.Text & " was poisoned", , "Pokemon Cawi Version")
                    Damage = 0
                ElseIf pkmnTeam = 3 Then
                    pp = 5
                Else
                    FrmBattle.urStat.Text = "Psn"
                    Damage = 0
                    MsgBox(FrmBattle.urName.Text & " was poisoned", , "Pokemon Cawi Version")
                    SetPokoValue()
                    'curStat.Add "Psn", , , args
                    'curStat.Remove args
                End If
            Case "Poison Fang"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Psn"
                    MsgBox(FrmBattle.enName.Text & " was poisoned", , "Pokemon Cawi Version")
                    Damage = 3
                ElseIf pkmnTeam = 3 Then
                    pp = 4
                Else
                    FrmBattle.urStat.Text = "Psn"
                    Damage = 3
                    MsgBox(FrmBattle.urName.Text & " was poisoned", , "Pokemon Cawi Version")
                    SetPokoValue()
                    'curStat.Add "Psn", , , args
                    'curStat.Remove args
                End If
            Case "Fire Spin"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Brn"
                    MsgBox(FrmBattle.enName.Text & " was burned", , "Pokemon Cawi Version")
                    Damage = 4
                ElseIf pkmnTeam = 3 Then
                    pp = 4
                Else
                    FrmBattle.urStat.Text = "Brn"
                    MsgBox(FrmBattle.urName.Text & " was burned", , "Pokemon Cawi Version")
                    Damage = 4
                    SetPokoValue()
                    'curStat.Add "Brn", , , args
                    'curStat.Remove args
                End If
            Case "Poison Powder"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Psn"
                    MsgBox(FrmBattle.enName.Text & " was poisoned", , "Pokemon Cawi Version")
                    Damage = 0
                ElseIf pkmnTeam = 3 Then
                    pp = 5
                Else
                    FrmBattle.urStat.Text = "Psn"
                    Damage = 0
                    MsgBox(FrmBattle.urName.Text & " was poisoned", , "Pokemon Cawi Version")
                    SetPokoValue()
                    'curStat.Add "Psn", , , args
                    'curStat.Remove args
                End If

            Case "Toxic"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Psn"
                    MsgBox(FrmBattle.enName.Text & " was poisoned", , "Pokemon Cawi Version")
                    Damage = 4
                ElseIf pkmnTeam = 3 Then
                    pp = 3
                Else
                    FrmBattle.urStat.Text = "Psn"
                    Damage = 4
                    MsgBox(FrmBattle.urName.Text & " was poisoned", , "Pokemon Cawi Version")
                    SetPokoValue()
                    'curStat.Add "Psn", , , args
                    'curStat.Remove args
                End If

            Case "Sleep Powder"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Slp"
                    Damage = 0
                    MsgBox(FrmBattle.enName.Text & " fell asleep", , "Pokemon Cawi Version")
                ElseIf pkmnTeam = 3 Then
                    pp = 5
                Else
                    FrmBattle.urStat.Text = "Slp"
                    Damage = 0
                    MsgBox(FrmBattle.urName.Text & " fell asleep", , "Pokemon Cawi Version")
                    SetPokoValue()
                    'curStat.Add "Slp", , , args
                    'curStat.Remove args
                End If

            Case "Hypnosis"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Slp"
                    Damage = 0
                    MsgBox(FrmBattle.enName.Text & " fell asleep", , "Pokemon Cawi Version")
                ElseIf pkmnTeam = 3 Then
                    pp = 5
                Else
                    FrmBattle.urStat.Text = "Slp"
                    Damage = 0
                    MsgBox(FrmBattle.urName.Text & " fell asleep", , "Pokemon Cawi Version")
                    SetPokoValue()
                    'curStat.Add "Slp", , , args
                    'curStat.Remove args
                End If

            Case "Stun Spore"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Prlz"
                    Damage = 0
                    MsgBox(FrmBattle.enName.Text & " was paralyzed", , "Pokemon Cawi Version")
                ElseIf pkmnTeam = 3 Then
                    pp = 5
                Else
                    FrmBattle.urStat.Text = "Prlz"
                    Damage = 0
                    MsgBox(FrmBattle.urName.Text & " was paralyzed", , "Pokemon Cawi Version")
                    'curStat.Add "Prlz", , , args
                    'curStat.Remove args
                    SetPokoValue()
                End If

            Case "Thunder Wave"
                If pkmnTeam = 1 Then
                    FrmBattle.enStat.Text = "Prlz"
                    Damage = 0
                    MsgBox(FrmBattle.enName.Text & " was paralyzed", , "Pokemon Cawi Version")
                ElseIf pkmnTeam = 3 Then
                    pp = 5
                Else
                    FrmBattle.urStat.Text = "Prlz"
                    Damage = 0
                    MsgBox(FrmBattle.urName.Text & " was paralyzed", , "Pokemon Cawi Version")
                    'curStat.Add "Prlz", , , args
                    'curStat.Remove args
                    SetPokoValue()
                End If
        End Select
    End Sub

    Public Sub Pokedex(ByVal pkmn, ByVal args)
        Dim attacks() As String = {"dog", "cat", "fish"}
        Select Case pkmn
            'Bulbasaur
            Case "Bulbasaur"
                attacks = {"Tackle", "Growl", "Vine Whip", "Leech Seed"}
                Type1 = "Grass"
                Type2 = "Poison"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Ivysaur
            Case "Ivysaur"
                attacks = {"Poison Powder", "HeadBut", "Vine Whip", "Razor Leaf"}
                Type1 = "Grass"
                Type2 = "Poison"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Venusaur
            Case "Venusaur"
                attacks = {"Frenzy Plant", "Solar Beam", "Body Slam", "Razor Leaf"}
                Type1 = "Grass"
                Type2 = "Poison"
                runRate = 3
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'squirtle
            Case "Squirtle"
                attacks = {"Tackle", "Tail Whip", "Bubble", "Water Gun"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Wartortle
            Case "Wartortle"
                attacks = {"Bite", "Bubble Beam", "Water Pulse", "Water Gun"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Blastoise
            Case "Blastoise"
                attacks = {"Hydro Pump", "Body Slam", "Water Pulse", "Hydro Cannon"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 3
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Charmander
            Case "Charmander"
                attacks = {"Scratch", "Growl", "Ember", "Tail Whip"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Charmeleon
            Case "Charmeleon"
                attacks = {"Metal Claw", "Slash", "Ember", "Flame Thrower"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Charizard
            Case "Charizard"
                attacks = {"Dragon Breath", "Seismic Toss", "Fire Blast", "Flame Thrower"}
                Type1 = "Fire"
                Type2 = "Dragon"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Chicorita
            Case "Chicorita"
                attacks = {"Tackle", "Growl", "Vine Whip", "HeadBut"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Bayleef
            Case "Bayleef"
                attacks = {"Body Slam", "Stomp", "Vine Whip", "Razor Leaf"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 8
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Meganium
            Case "Meganium"
                attacks = {"Body Slam", "Leaf Storm", "Magical Leaf", "Razor Leaf"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Cyndaquil
            Case "Cyndaquil"
                attacks = {"Tackle", "Growl", "Ember", "Smoke Screen"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Quilava
            Case "Quilava"
                attacks = {"Quick Attack", "Flame Wheel", "HeadBut", "Flame Thrower"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Typlosion
            Case "Typlosion"
                attacks = {"Fire Spin", "Flame Wheel", "Eruption", "Flame Thrower"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Totodile
            Case "Totodile"
                attacks = {"Scratch", "Growl", "Bite", "Water Gun"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Croconaw
            Case "Croconaw"
                attacks = {"Slash", "Bite", "Water Pulse", "Crunch"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Feraligatr
            Case "Feraligatr"
                attacks = {"Slash", "Hyper Beam", "Water Pulse", "Crunch"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Treeko
            Case "Treeko"
                attacks = {"Pound", "Leer", "Bullet Seed", "Leech Seed"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Grovile
            Case "Grovile"
                attacks = {"Quick Attack", "Leaf Blade", "Bullet Seed", "Focus Punch"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Sceptile
            Case "Sceptile"
                attacks = {"Solar Beam", "Leaf Blade", "Leaf Storm", "Focus Punch"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Torchic
            Case "Torchic"
                attacks = {"Scratch", "Leer", "Peck", "Ember"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Combusken
            Case "Combusken"
                attacks = {"Double Kick", "Focus Punch", "Ember", "Flame Thrower"}
                Type1 = "Fire"
                Type2 = "Fighting"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Blaziken
            Case "Blaziken"
                attacks = {"Sky Uppercut", "OverHeat", "Flare Blitz", "Flame Thrower"}
                Type1 = "Fire"
                Type2 = "Fighting"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Mudkip
            Case "Mudkip"
                attacks = {"Tackle", "Growl", "Mud Slap", "Water Gun"}
                Type1 = "Water"
                Type2 = "Ground"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Marshtomp
            Case "Marshtomp"
                attacks = {"HeadBut", "Mud Shot", "Mud Slap", "Water Gun"}
                Type1 = "Water"
                Type2 = "Ground"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Swampert
            Case "Swampert"
                attacks = {"Earthquake", "Mud Shot", "Mud Water", "Hydro Pump"}
                Type1 = "Water"
                Type2 = "Ground"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Turtwig
            Case "Turtwig"
                attacks = {"Tackle", "Growl", "HeadBut", "Vine Whip"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Grotle
            Case "Grotle"
                attacks = {"Vine Whip", "Body Slam", "HeadBut", "Razor Leaf"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Torterra
            Case "Torterra"
                attacks = {"Earthquake", "Wood Hammer", "Leaf Storm", "Razor Leaf"}
                Type1 = "Grass"
                Type2 = "Grass"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Chimchar
            Case "Chimchar"
                attacks = {"Scratch", "Leer", "Ember", "Slash"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'monferno
            Case "Monferno"
                attacks = {"Slash", "Brick Break", "Ember", "Flame Thrower"}
                Type1 = "Fire"
                Type2 = "Fire"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Infernape
            Case "Infernape"
                attacks = {"OverHeat", "Brick Break", "Focus Blast", "Flame Thrower"}
                Type1 = "Fire"
                Type2 = "Fighting"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Piplup
            Case "Piplup"
                attacks = {"Scratch", "Tail Whip", "Bubble", "Water Gun"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Prinplup
            Case "Prinplup"
                attacks = {"Slash", "Bubble Beam", "Sheer Cold", "Water Gun"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 8
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Empoleon
            Case "Empoleon"
                attacks = {"Blizzard", "Avalanche", "Sheer Cold", "Hydro Pump"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 8
                catchrate = 3
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Rattata
            Case "Rattata"
                attacks = {"Tackle", "Tail Whip", "Quick Attack", "Bite"}
                Type1 = "Normal"
                Type2 = "Normal"
                runRate = 8
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'raticate
            Case "Raticate"
                attacks = {"Crunch", "Pursuit", "Bite", "Hyper Fang"}
                Type1 = "Normal"
                Type2 = "Normal"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Hoothoot
            Case "Hoothoot"
                attacks = {"Tackle", "Leer", "Peck", "Confusion"}
                Type1 = "Psychic"
                Type2 = "Flying"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Noctowl
            Case "Noctowl"
                attacks = {"Hypnosis", "Psybeam", "Wing Attack", "Confusion"}
                Type1 = "Psychic"
                Type2 = "Flying"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Ekans
            Case "Ekans"
                attacks = {"Bite", "Wrap", "Poison Sting", "Constrict"}
                Type1 = "Poison"
                Type2 = "Poison"
                runRate = 7
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Arbok
            Case "Arbok"
                attacks = {"Bite", "Poison Tail", "Crunch", "Poison Fang"}
                Type1 = "Poison"
                Type2 = "Poison"
                runRate = 7
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Pidgey
            Case "Pidgey"
                attacks = {"Tackle", "Sand Attack", "Gust", "Quick Attack"}
                Type1 = "Flying"
                Type2 = "Flying"
                runRate = 8
                catchrate = 8
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Pidgeoto
            Case "Pidgeoto"
                attacks = {"Wing Attack", "Aerial Ace", "Gust", "Quick Attack"}
                Type1 = "Flying"
                Type2 = "Flying"
                runRate = 8
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Pidgeot
            Case "Pidgeot"
                attacks = {"Wing Attack", "Aerial Ace", "Brave Bird", "Sky Attack"}
                Type1 = "Flying"
                Type2 = "Flying"
                runRate = 8
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Lotad
            Case "Lotad"
                attacks = {"Tackle", "Growl", "Faint", "Water Gun"}
                Type1 = "Grass"
                Type2 = "Water"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Lombre
            Case "Lombre"
                attacks = {"HeadBut", "Razor Leaf", "Faint", "Water Gun"}
                Type1 = "Grass"
                Type2 = "Water"
                runRate = 7
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Ludicolo
            Case "Ludicolo"
                attacks = {"Hydro Pump", "Solar Beam", "Body Slam", "Giga Drain"}
                Type1 = "Grass"
                Type2 = "Water"
                runRate = 7
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Beedrill
            Case "Beedrill"
                attacks = {"Poison Sting", "Pin Missile", "Silver Wind", "Poison Tail"}
                Type1 = "Bug"
                Type2 = "Bug"
                runRate = 7
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Butterfree
            Case "Butterfree"
                attacks = {"Sleep Powder", "Gust", "Psybeam", "Stun Spore"}
                Type1 = "Bug"
                Type2 = "Flying"
                runRate = 7
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Venomoth
            Case "Venomoth"
                attacks = {"Sleep Powder", "Psybeam", "Confusion", "Wing Attack"}
                Type1 = "Bug"
                Type2 = "Poison"
                runRate = 7
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Scyther
            Case "Scyther"
                attacks = {"Slash", "Fury Cutter", "X-Scissor", "Extreme Speed"}
                Type1 = "Bug"
                Type2 = "Bug"
                runRate = 7
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Pinsir
            Case "Pinsir"
                attacks = {"Mega Punch", "Hyper Beam", "Rock Tomb", "Guilotine"}
                Type1 = "Bug"
                Type2 = "Bug"
                runRate = 7
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Exeggutor
            Case "Exeggutor"
                attacks = {"Solar Beam", "Stomp", "Psychic", "Barrage"}
                Type1 = "Grass"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'mankey
            Case "Mankey"
                attacks = {"Scratch", "Karate Chop", "Tail Whip", "Low Kick"}
                Type1 = "Fighting"
                Type2 = "Fighting"
                runRate = 6
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Primeape
            Case "Primeape"
                attacks = {"Slash", "Karate Chop", "Focus Punch", "Focus Blast"}
                Type1 = "Fighting"
                Type2 = "Fighting"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Starly
            Case "Starly"
                attacks = {"Peck", "Tail Whip", "Quick Attack", "Gust"}
                Type1 = "Flying"
                Type2 = "Flying"
                runRate = 6
                catchrate = 8
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Staravia
            Case "Staravia"
                attacks = {"Wing Attack", "Sky Attack", "Aerial Ace", "Gust"}
                Type1 = "Flying"
                Type2 = "Flying"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Staraptor
            Case "Staraptor"
                attacks = {"Wing Attack", "Brave Bird", "Aerial Ace", "Air Slash"}
                Type1 = "Flying"
                Type2 = "Flying"
                runRate = 4
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Tailow
            Case "Tailow"
                attacks = {"Peck", "Sand Attack", "Quick Attack", "Gust"}
                Type1 = "Flying"
                Type2 = "Flying"
                runRate = 6
                catchrate = 8
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Swellow
            Case "Swellow"
                attacks = {"Wing Attack", "Aerial Ace", "Fly", "Air Slash"}
                Type1 = "Flying"
                Type2 = "Flying"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Odish
            Case "Odish"
                attacks = {"Poison Powder", "Absorb", "Cut", "Stun Spore"}
                Type1 = "Grass"
                Type2 = "Poison"
                runRate = 6
                catchrate = 8
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Gloom
            Case "Gloom"
                attacks = {"Poison Powder", "Mega Drain", "Sleep Powder", "Stun Spore"}
                Type1 = "Grass"
                Type2 = "Poison"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Vileplume
            Case "Vilemplume"
                attacks = {"Thrash", "Giga Drain", "Sleep Powder", "Fetal Dance"}
                Type1 = "Grass"
                Type2 = "Poison"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Stunky
            Case "Stunky"
                attacks = {"Tackle", "Tail Whip", "HeadBut", "Smog"}
                Type1 = "Normal"
                Type2 = "Poison"
                runRate = 6
                catchrate = 8
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Stuntank
            Case "Stuntank"
                attacks = {"HeadBut", "Poison Gas", "Poison Jab", "Poison Fang"}
                Type1 = "Normal"
                Type2 = "Poison"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Ralts
            Case "Ralts"
                attacks = {"Tackle", "Leer", "Future Sight", "Confusion"}
                Type1 = "Psychic"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 8
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Kirlia
            Case "Kirlia"
                attacks = {"Tackle", "HeadBut", "Future Sight", "Confusion"}
                Type1 = "Psychic"
                Type2 = "Psychic"
                runRate = 5
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Gardevoir
            Case "Gardevoir"
                attacks = {"Psychic", "Psybeam", "Psywave", "Confusion"}
                Type1 = "Psychic"
                Type2 = "Psychic"
                runRate = 3
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Parasect
            Case "Parasect"
                attacks = {"Stun Spore", "Sleep Powder", "Absorb", "Slash"}
                Type1 = "Bug"
                Type2 = "Grass"
                runRate = 5
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Pichu
            Case "Pichu"
                attacks = {"Charm", "Tail Whip", "Thunder Shock", "Quick Attack"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 8
                catchrate = 8
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Pikachu
            Case "Pikachu"
                attacks = {"Thunder Shock", "Tail Whip", "Thunder Wave", "Quick Attack"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 8
                catchrate = 8
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'raichu
            Case "Raichu"
                attacks = {"Thunder Bolt", "Thunder Punch", "Thunder", "Body Slam"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 8
                catchrate = 8
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Graveller
            Case "Graveller"
                attacks = {"Rollout", "Rock Throw", "Double Edge", "Mega Punch"}
                Type1 = "Rock"
                Type2 = "Rock"
                runRate = 8
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Golem
            Case "Golem"
                attacks = {"Rollout", "Rock Slide", "Super Power", "Stone Edge"}
                Type1 = "Rock"
                Type2 = "Rock"
                runRate = 5
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Sudowoodo
            Case "Sudowoodo"
                attacks = {"Faint", "Rock Throw", "Brick Break", "Stone Edge"}
                Type1 = "Rock"
                Type2 = "Rock"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                '    'Onix
            Case "Onix"
                attacks = {"HeadBut", "Rock Slide", "Wrap", "Ancient Power"}
                Type1 = "Rock"
                Type2 = "Rock"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Steelix
            Case "Steelix"
                attacks = {"Iron Head", "Rock Slide", "Iron Tail", "Earthquake"}
                Type1 = "Steel"
                Type2 = "Steel"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Foretress
            Case "Foretress"
                attacks = {"Giga Drain", "Metal Claw", "Rollout", "Screech"}
                Type1 = "Steel"
                Type2 = "Bug"
                runRate = 5
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Golbat
            Case "Golbat"
                attacks = {"Mega Drain", "Wing Attack", "Toxic", "Crunch"}
                Type1 = "Poison"
                Type2 = "Flying"
                runRate = 5
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Ariados
            Case "Ariados"
                attacks = {"Bite", "Bug Buzz", "Poison Sting", "Night Shade"}
                Type1 = "Bug"
                Type2 = "Bug"
                runRate = 5
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Plusle
            Case "Plusle"
                attacks = {"Thunder Shock", "Tail Whip", "Helping Hands", "Quick Attack"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 8
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Minun
            Case "Minun"
                attacks = {"Thunder Shock", "Tail Whip", "Helping Hands", "Quick Attack"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 8
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Chinchou
            Case "Chinchou"
                attacks = {"Spark", "Water Gun", "Thunder Wave", "Charge"}
                Type1 = "Water"
                Type2 = "Electric"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Lanturn
            Case "Lanturn"
                attacks = {"Spark", "Aqua Tail", "Charge Beam", "Water Pulse"}
                Type1 = "Water"
                Type2 = "Electric"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Wailmer
            Case "Wailmer"
                attacks = {"Rollout", "Water Gun", "Bite", "HeadBut"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Wailord
            Case "Wailord"
                attacks = {"Body Slam", "Hydro Pump", "Crunch", "Aqua Tail"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 3
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 7
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 7
                End If
                'Mantine
            Case "Mantine"
                attacks = {"Water Gun", "Aerial Ace", "Water Pulse", "Bubble"}
                Type1 = "Water"
                Type2 = "Flying"
                runRate = 5
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Wooper
            Case "Wooper"
                attacks = {"Water Gun", "Mud Slap", "Bubble", "HeadBut"}
                Type1 = "Water"
                Type2 = "Ground"
                runRate = 8
                catchrate = 8
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Quagsire
            Case "Quagsire"
                attacks = {"Water Pulse", "Mud Shot", "Earthquake", "Crunch"}
                Type1 = "Water"
                Type2 = "Ground"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 6
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 6
                End If
                'Politoed
            Case "Politoed"
                attacks = {"Water Gun", "HeadBut", "Water Pulse", "Mega Punch"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Staryu
            Case "Staryu"
                attacks = {"Water Gun", "Rapid Spin", "Bubble", "Tackle"}
                Type1 = "Water"
                Type2 = "Psychic"
                runRate = 7
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Starmie
            Case "Starmie"
                attacks = {"Hydro Pump", "Psycho Boost", "Aerial Ace", "Rapid Spin"}
                Type1 = "Water"
                Type2 = "Psychic"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Seel
            Case "Seel"
                attacks = {"Water Gun", "HeadBut", "Aqua Tail", "Tackle"}
                Type1 = "Water"
                Type2 = "Ice"
                runRate = 6
                catchrate = 7
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Dewgong
            Case "Dewgong"
                attacks = {"Hydro Pump", "Ice Beam", "Aurora Beam", "HeadBut"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Vaporeon
            Case "Vaporeon"
                attacks = {"Extreme Speed", "Ice Beam", "Hydro Pump", "Aqua Tail"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 6
                catchrate = 4
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 5
                End If
                'Whiscash
            Case "Whiscash"
                attacks = {"Earthquake", "HeadBut", "Water Gun", "Bubble Beam"}
                Type1 = "Water"
                Type2 = "Ground"
                runRate = 6
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Dustox
            Case "Dustox"
                attacks = {"Psybeam", "Confusion", "Silverwind", "Tackle"}
                Type1 = "Bug"
                Type2 = "Psychic"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Beautifly
            Case "Beautifly"
                attacks = {"Giga Drain", "Leech Seed", "Silverwind", "Mega Drain"}
                Type1 = "Bug"
                Type2 = "Grass"
                runRate = 5
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Electrike
            Case "Electrike"
                attacks = {"Thunder Shock", "Quick Attack", "HeadBut", "Thunder Wave"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 7
                catchrate = 6
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 3
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
                'Manectric
            Case "Manectric"
                attacks = {"Thunder Bolt", "Extreme Speed", "Thunder", "Thunder Fang"}
                Type1 = "Electric"
                Type2 = "Electric"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 5
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 4
                End If
                'Sharpedo
            Case "Sharpedo"
                attacks = {"Bite", "Crunch", "Water Gun", "Water Pulse"}
                Type1 = "Water"
                Type2 = "Water"
                runRate = 6
                catchrate = 5
                If args = 1 Then
                    FrmBattle.optAttack0.Text = attacks(0)
                    FrmBattle.optAttack1.Text = attacks(1)
                    FrmBattle.optAttack2.Text = attacks(2)
                    FrmBattle.optAttack3.Text = attacks(3)
                    urType1 = Type1
                    urType2 = Type2
                    FrmBattle.lblUrType.Text = urType1 & "/" & urType2
                    FrmBattle.urActivePkmn.Tag = 4
                Else
                    For a = 0 To 3
                        enAttack(a) = attacks(a)
                    Next a
                    enType1 = Type1
                    enType2 = Type2
                    FrmBattle.LblEnType.Text = enType1 & "/" & enType2
                    FrmBattle.enActivePkmn.Tag = 3
                End If
        End Select
        Call pokedexPart2(pkmn, args)
    End Sub




End Module
