﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSpeech
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmSpeech))
        Me.FlexGrid = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.FlexFix = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.FlexItems = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.FlexMap = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.Text1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.CmdSave = New System.Windows.Forms.Button()
        Me.TxtItem = New System.Windows.Forms.TextBox()
        Me.TxtType = New System.Windows.Forms.TextBox()
        Me.Item = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RB1 = New System.Windows.Forms.RadioButton()
        Me.RB2 = New System.Windows.Forms.RadioButton()
        Me.RB3 = New System.Windows.Forms.RadioButton()
        CType(Me.FlexGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FlexFix, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FlexItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FlexMap, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FlexGrid
        '
        Me.FlexGrid.Location = New System.Drawing.Point(493, 12)
        Me.FlexGrid.Name = "FlexGrid"
        Me.FlexGrid.OcxState = CType(resources.GetObject("FlexGrid.OcxState"), System.Windows.Forms.AxHost.State)
        Me.FlexGrid.Size = New System.Drawing.Size(310, 168)
        Me.FlexGrid.TabIndex = 0
        '
        'FlexFix
        '
        Me.FlexFix.Location = New System.Drawing.Point(497, 186)
        Me.FlexFix.Name = "FlexFix"
        Me.FlexFix.OcxState = CType(resources.GetObject("FlexFix.OcxState"), System.Windows.Forms.AxHost.State)
        Me.FlexFix.Size = New System.Drawing.Size(306, 111)
        Me.FlexFix.TabIndex = 1
        '
        'FlexItems
        '
        Me.FlexItems.Location = New System.Drawing.Point(499, 326)
        Me.FlexItems.Name = "FlexItems"
        Me.FlexItems.OcxState = CType(resources.GetObject("FlexItems.OcxState"), System.Windows.Forms.AxHost.State)
        Me.FlexItems.Size = New System.Drawing.Size(309, 163)
        Me.FlexItems.TabIndex = 2
        '
        'FlexMap
        '
        Me.FlexMap.Location = New System.Drawing.Point(499, 508)
        Me.FlexMap.Name = "FlexMap"
        Me.FlexMap.OcxState = CType(resources.GetObject("FlexMap.OcxState"), System.Windows.Forms.AxHost.State)
        Me.FlexMap.Size = New System.Drawing.Size(307, 160)
        Me.FlexMap.TabIndex = 3
        '
        'Text1
        '
        Me.Text1.Location = New System.Drawing.Point(72, 25)
        Me.Text1.Name = "Text1"
        Me.Text1.Size = New System.Drawing.Size(148, 20)
        Me.Text1.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Map"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(248, 25)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(74, 28)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Read"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(12, 72)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(459, 542)
        Me.RichTextBox1.TabIndex = 7
        Me.RichTextBox1.Text = ""
        '
        'CmdSave
        '
        Me.CmdSave.Location = New System.Drawing.Point(359, 28)
        Me.CmdSave.Name = "CmdSave"
        Me.CmdSave.Size = New System.Drawing.Size(69, 24)
        Me.CmdSave.TabIndex = 8
        Me.CmdSave.Text = "Save"
        Me.CmdSave.UseVisualStyleBackColor = True
        '
        'TxtItem
        '
        Me.TxtItem.Location = New System.Drawing.Point(547, 300)
        Me.TxtItem.Name = "TxtItem"
        Me.TxtItem.Size = New System.Drawing.Size(127, 20)
        Me.TxtItem.TabIndex = 9
        '
        'TxtType
        '
        Me.TxtType.Location = New System.Drawing.Point(736, 300)
        Me.TxtType.Name = "TxtType"
        Me.TxtType.Size = New System.Drawing.Size(67, 20)
        Me.TxtType.TabIndex = 10
        '
        'Item
        '
        Me.Item.AutoSize = True
        Me.Item.Location = New System.Drawing.Point(496, 303)
        Me.Item.Name = "Item"
        Me.Item.Size = New System.Drawing.Size(27, 13)
        Me.Item.TabIndex = 11
        Me.Item.Text = "Item"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(680, 303)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Type"
        '
        'RB1
        '
        Me.RB1.AutoSize = True
        Me.RB1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB1.Location = New System.Drawing.Point(15, 639)
        Me.RB1.Name = "RB1"
        Me.RB1.Size = New System.Drawing.Size(79, 20)
        Me.RB1.TabIndex = 13
        Me.RB1.TabStop = True
        Me.RB1.Text = "Speech"
        Me.RB1.UseVisualStyleBackColor = True
        '
        'RB2
        '
        Me.RB2.AutoSize = True
        Me.RB2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB2.Location = New System.Drawing.Point(131, 639)
        Me.RB2.Name = "RB2"
        Me.RB2.Size = New System.Drawing.Size(82, 20)
        Me.RB2.TabIndex = 14
        Me.RB2.TabStop = True
        Me.RB2.Text = "Thought"
        Me.RB2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RB2.UseVisualStyleBackColor = True
        '
        'RB3
        '
        Me.RB3.AutoSize = True
        Me.RB3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB3.Location = New System.Drawing.Point(294, 636)
        Me.RB3.Name = "RB3"
        Me.RB3.Size = New System.Drawing.Size(70, 20)
        Me.RB3.TabIndex = 15
        Me.RB3.TabStop = True
        Me.RB3.Text = "Pence"
        Me.RB3.UseVisualStyleBackColor = True
        '
        'FrmSpeech
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(815, 668)
        Me.Controls.Add(Me.RB3)
        Me.Controls.Add(Me.RB2)
        Me.Controls.Add(Me.RB1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Item)
        Me.Controls.Add(Me.TxtType)
        Me.Controls.Add(Me.TxtItem)
        Me.Controls.Add(Me.CmdSave)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Text1)
        Me.Controls.Add(Me.FlexMap)
        Me.Controls.Add(Me.FlexItems)
        Me.Controls.Add(Me.FlexFix)
        Me.Controls.Add(Me.FlexGrid)
        Me.Name = "FrmSpeech"
        Me.Text = "FrmSpeech"
        CType(Me.FlexGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FlexFix, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FlexItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FlexMap, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents FlexGrid As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents FlexFix As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents FlexItems As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents FlexMap As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents Text1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents CmdSave As System.Windows.Forms.Button
    Friend WithEvents TxtItem As System.Windows.Forms.TextBox
    Friend WithEvents TxtType As System.Windows.Forms.TextBox
    Friend WithEvents Item As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents RB1 As System.Windows.Forms.RadioButton
    Friend WithEvents RB2 As System.Windows.Forms.RadioButton
    Friend WithEvents RB3 As System.Windows.Forms.RadioButton
End Class
