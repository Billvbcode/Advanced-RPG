﻿Public Class Form1
    Dim iKeycode As Integer
    Public Sub EraseItem(ByVal cEItem As String)
        Dim i As Integer
        For i = 133 To 138
            If UCase(PB(i).Tag) = UCase(cEItem) Then
                PB(i).Tag = ""
                PB(i).Visible = False
            End If
        Next
    End Sub
    Private Sub MeFind()
        ' Dim j As Integer
        DGrid.Visible = False
        Panel1.Visible = True
        For i = 1 To 8
            Choice(i).Visible = False
        Next
        Pitanje.Text = "You found " & IName
        For i = 1 To 1
            'Choice(i).AutoSize = True
            Choice(i).Visible = True
            Choice(i).Tag = "0000"
            Choice(i).Text = ">>> Goodby"
            Choice(i).BackColor = Panel1.BackColor
        Next
    End Sub
    Private Sub MeRabbit()

        Dim j As Integer
        DGrid.Visible = False
        Panel1.Visible = True
        For i = 1 To 8
            Choice(i).Visible = False
        Next
        Pitanje.Text = "You caught a rabbit"
        For i = 1 To 1
            'Choice(i).AutoSize = True
            Choice(i).Visible = True
            Choice(i).Tag = "0000"
            Choice(i).Text = ">>> Goodby"
            Choice(i).BackColor = Panel1.BackColor


        Next

    End Sub
    Private Sub MeGot()

        Dim j As Integer
        DGrid.Visible = False
        Panel1.Visible = True
        For i = 1 To 8
            Choice(i).Visible = False
        Next
        Pitanje.Text = "You got " & IName
        For i = 1 To 1
            'Choice(i).AutoSize = True
            Choice(i).Visible = True
            Choice(i).Tag = "0000"
            Choice(i).Text = ">>> Goodby"
            Choice(i).BackColor = Panel1.BackColor


        Next
    End Sub
    Private Sub MagicTalk()
        Dim i As Integer
        Dim cMsg As String
        DGrid.Visible = False
        Panel1.Visible = True
        For i = 1 To 8
            Choice(i).Visible = False
        Next
        Pitanje.Visible = True
        Pitanje.Text = "Not Enough Magic!"
        cMsg = "Exit"
        For i = 1 To 1
            Choice(i).Text = ">>> " & cMsg
            Choice(i).AutoSize = True
            Choice(i).Visible = True
            Choice(i).Tag = cMsg
            cMsg = "No"
        Next
    End Sub
    Private Sub ChestTalk()
        Dim i As Integer
        Dim cMsg As String
        DGrid.Visible = False
        Panel1.Visible = True
        For i = 1 To 8
            Choice(i).Visible = False
        Next
        Pitanje.Visible = True
        Pitanje.Text = "Do you want to open the chest?"
        cMsg = "Yes"
        For i = 1 To 2
            Choice(i).Text = ">>> " & cMsg
            Choice(i).AutoSize = True
            Choice(i).Visible = True
            Choice(i).Tag = cMsg
            cMsg = "No"
        Next
    End Sub
    Private Sub MeSpeek()
        Dim cMsg As String
        Dim iEQuest As Integer
        Dim iBQuest As Integer
        Dim iSQuest As Integer
        Dim iQuestYes As Integer
        Dim iQuestNo As Integer
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        Dim L1 As Integer
        Dim l2 As Integer
        Dim sPerson As String
        Dim sMeGive2 As String
        Dim bTalked As Boolean
        Dim bAddBadge As Boolean
        Dim bInvAdd As Boolean
        DGrid.Visible = False
StartMeSpeek:
        sGiveBadge = ""
        Panel1.Visible = True
        bTalked = False
        bAddBadge = False
        bFoundChest = False

        For i = 1 To 8
            Choice(i).Visible = False
        Next
        For Each doors In nDoors
            If doors.DooriX = iNewx + 5 And doors.DooriY = iNewy + 3 Then
                sPerson = doors.Name
            End If

        Next
        Pitanje.Visible = True
        'Holder.Visible = True
        'Holder.Enabled = True
        For Each speech In nSpeech
            sGiveBadge = speech.Badge
            If sTalkTag <> "" And sTalkTag <> speech.RNumber Then GoTo MySkip
            If speech.Name = sPerson Then
                If speech.SayOnce = "D" Then GoTo MySkip
                If speech.MyType <> UCase(sTalkType) Then GoTo MySkip

                iEQuest = Val(speech.EndQuest)
                iBQuest = Val(speech.BeforeQuest)
                iSQuest = Val(speech.StartQuest)
                iQuestYes = Val(speech.QuestYes)
                iQuestNo = Val(speech.QuestNo)
                If iBQuest > 0 And Mquest(iBQuest) <> "" Then GoTo MySkip
                If iEQuest > 0 And Mquest(iEQuest) <> "N" Then GoTo MySkip
                If iQuestYes > 0 And Mquest(iQuestYes) <> "Y" Then GoTo MySkip
                If iQuestNo > 0 And Mquest(iQuestNo) <> "N" Then GoTo MySkip
                'If speech.Need <> "" Then
                If Mid(speech.Need, 1, 5) = "BADGE" Then
                    If sMeGive <> "" Then GoTo MySkip
                    cMsg = Mid(speech.Need, 6, Len(speech.Need) - 5)
                    sMeGive2 = "***"
                    For j = 1 To 30
                        If UCase(cMsg) = UCase(sBadge(j)) Then sMeGive2 = speech.Need
                    Next
                    If speech.Need <> sMeGive2 Then GoTo MySkip
                Else
                    If UCase(speech.Need) <> UCase(sMeGive) Then GoTo MySkip
                    If speech.NeedQty > iMeQty Then GoTo MySkip
                    If UCase(speech.Need) = "WOOD" Then Wood = Wood - speech.NeedQty
                    If UCase(speech.Need) = "COIN" Then Coin = Coin - speech.NeedQty
                    If UCase(speech.Need) = "TICKET" Then Ticket = Ticket - speech.NeedQty
                    If UCase(speech.Need) = "TOAST" Then Toast = Toast - speech.NeedQty
                    If speech.Need <> "" Then Call EraseItem(speech.Need)
                End If
                ' End If
                bTalked = True
                If iSQuest > 0 And Mquest(iSQuest) = "" Then
                    Mquest(iSQuest) = "N"
                    MquestName(iSQuest) = speech.QuestName
                End If
                If iEQuest > 0 Then
                    If Mquest(iEQuest) = "N" Then Mquest(iEQuest) = "Y"
                End If

                '     If speech.Need <> "" Then
                '       j = InStr(1, UCase(TxtItem.Text), UCase(speech.Need))
                '       If j = 0 Then GoTo MySkip
                '     End If
                If speech.BombQty > 0 Then
                    Bomb = Bomb + speech.BombQty
                End If
                '
                ' Give Item
                '
                If speech.Give <> "" Then
                    If Mid(speech.Give, 1, 4) = "SPEL" Then
                        If UCase(speech.Give) = "SPELLL" Then
                            SpellLight = True
                            'LblLight.BackColor = LblGreen.BackColor
                        End If
                        If UCase(speech.Give) = "SPELLD" Then
                            SpellDestroy = True
                            'LblDestroy.BackColor = LblGreen.BackColor
                        End If
                        If UCase(speech.Give) = "SPELLA" Then
                            SpellAxe = True
                            'LblAxe.BackColor = LblGreen.BackColor
                        End If
                        If UCase(speech.Give) = "SPELLC" Then
                            SpellCut = True
                            ' LblCut.BackColor = LblGreen.BackColor
                        End If
                        If UCase(speech.Give) = "SPELLF" Then
                            SpellFill = True
                            'LblFill.BackColor = LblGreen.BackColor
                        End If
                        If UCase(speech.Give) = "SPELLG" Then
                            SpellGrow = True
                            'LblGrow.BackColor = LblGreen.BackColor
                        End If
                        If UCase(speech.Give) = "SPELL1" Then
                            Spell1 = True
                            'Lbl1.BackColor = LblGreen.BackColor
                        End If
                    ElseIf Mid(speech.Give, 1, 5) = "BADGE" Then
                        sGiveBadge = Mid(speech.Give, 6, Len(speech.Give) - 5)
                        ' If speech.Pokemon = "" Then AddBadge()
                    Else
                        bInvAdd = False
                        If UCase(speech.Give) = "WOOD" Then
                            bInvAdd = True
                            Wood = Wood + speech.GiveQty
                        End If

                        If UCase(speech.Give) = "COIN" Then
                            bInvAdd = True
                            Coin = Coin + speech.GiveQty
                        End If
                        If UCase(speech.Give) = "TICKET" Then
                            bInvAdd = True
                            Ticket = Ticket + speech.GiveQty
                        End If
                        If UCase(speech.Give) = "TOAST" Then
                            bInvAdd = True
                            Toast = Toast + speech.GiveQty
                        End If
                        For Each cTile In nTiles
                            If UCase(speech.Give) = UCase(cTile.TileName) Then
                                bInvAdd = False
                                For i = 133 To 138
                                    If PB(i).Visible = False And bInvAdd = False Then
                                        'ImgBlue(iItemCnt).Picture = imgA(iTilePos2).Picture
                                        PB(i).Tag = cTile.TileName
                                        PB(i).Image = PB(cTile.MyTileCnt + m144).Image
                                        Me.ToolTip1.SetToolTip(PB(i), cTile.TileName)
                                        PB(i).Visible = True
                                        If UCase(cTile.TileName) = "CANDLE" Then SAVE_Candle = 18
                                        bInvAdd = True
                                    End If
                                Next
                            End If
                        Next
                    End If
                    MyList()
                End If
                '
                '
                '
                If speech.Pokemon <> "" Then
                    L1 = 1
                    l2 = InStr(1, speech.Pokemon, ",")
                    For k = 0 To 5
                        enParty(k) = ""
                        If l2 > 0 Then
                            enParty(k) = Mid(speech.Pokemon, L1, l2 - L1)
                            L1 = l2 + 1
                            l2 = InStr(L1, speech.Pokemon, ",")
                        End If
                    Next
                    L1 = 1
                    l2 = InStr(1, speech.PokeLevel, ",")
                    For k = 0 To 5
                        enPartyLevel(k) = ""
                        If l2 > 0 Then
                            enPartyLevel(k) = Mid(speech.PokeLevel, L1, l2 - L1)
                            L1 = l2 + 1
                            l2 = InStr(L1, speech.PokeLevel, ",")
                        End If
                    Next
                    'enParty = Array(speech.Pokemon)
                    'enPartyLevel = Array(speech.PokeLevel)
                    'CmdBattle.Visible = True
                    'CmdBattle.Tag = "OK"
                End If
                '
                'Fix(Map)
                '
                If speech.FixX > 0 And speech.FixY > 0 Then
                    For Each cTile In nTiles
                        If UCase(speech.FixMap) = UCase(cTile.TileName) Then
                            Mid(Map(speech.FixY), speech.FixX, 1) = Mid(cTile.TileLet, 1, 1)
                            Mid(Map2(speech.FixY), speech.FixX, 1) = Mid(cTile.TileLet, 2, 1)
                            DrawIt2()
                            speech.FixX = 0
                            speech.FixY = 0
                            Exit For
                        End If
                    Next
                End If

                ' Speech
                '
                Pitanje.Text = speech.Name & speech.Talk
                If speech.SayOnce = "Y" Then speech.SayOnce = "D"
                For i = 1 To speech.Count
                    'Load Choice(Choice.Count)
                    'Choice(i - 1).Left = 120
                    'If i > 1 Then Choice(i - 1).Top = Choice(i - 2).Top + Choice(i - 2).Height + 60
                    Choice(i).Text = "<" & LCase(speech.MyType) & "> " & Mid(speech.Question(i - 1), 6, Len(speech.Question(i - 1)) - 5)
                    'Choice(i).AutoSize = True
                    Choice(i).Visible = True
                    Choice(i).Tag = Mid(speech.Question(i - 1), 1, 4)
                    Choice(i).BackColor = Panel1.BackColor
                    If UCase(sTalkType) = "THOUGHT" Then Choice(i).BackColor = Color.CadetBlue
                    If UCase(sTalkType) = "PENCE" Then Choice(i).BackColor = Color.Chocolate
                Next
                If UCase(sTalkType) = "THOUGHT" Or UCase(sTalkType) = "PENCE" Then
                    ' Choice(speech.Count).Left = 120
                    '  Choice(speech.Count).Top = Choice(speech.Count - 1).Top + Choice(speech.Count - 1).Height + 60
                    Choice(speech.Count + 1).Text = "Click to Speak "
                    Choice(speech.Count + 1).AutoSize = True
                    Choice(speech.Count + 1).Visible = True
                    Choice(speech.Count + 1).Tag = "SPEECH"
                    Choice(i).BackColor = Panel1.BackColor
                End If
                If UCase(sTalkType) = "PENCE" Then
                    'Choice(speech.Count + 2).Left = 120
                    'Choice(speech.Count + 2).Top = Choice(speech.Count).Top + Choice(speech.Count).Height + 60
                    Choice(speech.Count + 2).Text = "Click to Read Thought "
                    Choice(speech.Count + 2).AutoSize = True
                    Choice(speech.Count + 2).Visible = True
                    Choice(speech.Count + 2).Tag = "THOUGHT"
                    Choice(i).BackColor = Color.CadetBlue
                End If
                GoTo MyExit
            End If
MySkip:
        Next
MyExit:
        MyList()
        If bTalked Then Exit Sub
        If UCase(sTalkType) = "PENCE" Then
            sTalkType = "THOUGHT"
            GoTo StartMeSpeek
        End If
        If UCase(sTalkType) = "THOUGHT" Then
            sTalkType = "SPEECH"
            GoTo StartMeSpeek
        End If
        Choice(1).AutoSize = True
        Choice(1).Visible = True
        Choice(1).Tag = "0000"
        If sMeGive = "" Then
            Pitanje.Text = sPerson & " I do not know what to say"
            Choice(1).Text = ">>> Goodby"
        Else
            Pitanje.Text = sPerson & " I do not need that"
            Choice(1).Text = ">>> Goodby"
        End If
    End Sub
    Private Sub NextLevel()
        ReadMapFile(cMapFile)
        TxtMap.Text = cMapFile
        ReadDoorFile(cMapFile)
        ReadSpeech(cMapFile)
        DrawIt2()
    End Sub
    Private Sub Moveme(ByVal KeyCode As Integer)
        Dim bInvFree As Boolean
        Dim bInvAdd As Boolean
        Dim PositionMap As String
        Dim PositionMap2 As String
        Dim cTileType As String
        Dim cTilename As String
        Dim cTilename2 As String
        Dim iTilePos As Integer
        Dim iTilePos2 As Integer
        Dim i As Integer
        Dim j As Integer
        Dim j1 As Integer
        'TimBunny.Enabled = False
        For i = 121 To 126
            sMeGive = ""
            iMeQty = 1
            sTalkTag = ""
            LblJar.Text = ""
            LblJar.Visible = False
            PB(i).BorderStyle = BorderStyle.None
        Next
        cTilename2 = ""
        LblJar.Text = ""
        bOnWater = False
        bHaveBoat = False
        For i = 133 To 138
            If PB(i).Visible Then
                If UCase(PB(i).Tag) = "BOAT" Then bHaveBoat = True
            End If
        Next
        Select Case KeyCode
            Case Keys.R   'Load Game
                TimBunny.Enabled = False
                LoadGame()
                'If bDark Then DarkMapFile(TxtMap.Text)
                j = 1
                j1 = InStr(j, sInventory, ";")
                For i = 133 To 138
                    PB(i).Tag = ""
                    PB(i).Visible = False
                    If (j1 - j) > 1 Then
                        PB(i).Tag = Mid(sInventory, j, j1 - j)
                        PB(i).Visible = True
                        FileTile = My.Application.Info.DirectoryPath & "\tiles\" & PB(i).Tag & ".bmp"
                        PB(i).Image = Image.FromFile(FileTile)
                    End If
                    j = j1 + 1
                    j1 = InStr(j, sInventory, ";")
                Next
                ReadDoorFile(cMapFile)
                ReadMapFile(cMapFile)
                ReadSpeech(cMapFile)
                If bDark Then DarkMapFile(cMapFile)
                TxtMap.Text = cMapFile
                FindBunnies()
                If iBunny > 0 Then TimBunny.Enabled = True
                TimMove.Enabled = False
                MyList()
                DrawIt2()
                Exit Sub
            Case Keys.E  'Exit
                TimMove.Enabled = False
                Me.Close()
                Me.Dispose()
                End
            Case Keys.D1
                TimMove.Enabled = False
                If iMagicPoints > 34 Then
                    Transport(2)
                End If
                Exit Sub
            Case Keys.D2
                TimMove.Enabled = False
                If iMagicPoints > 44 Then
                    Transport(3)
                End If
                Exit Sub
            Case Keys.D3
                TimMove.Enabled = False
                If iMagicPoints > 54 Then
                    Transport(4)
                End If
                Exit Sub
            Case Keys.W
                wildAppear()
                TimMove.Enabled = False
            Case Keys.S  'Save Game
                TimMove.Enabled = False
                For i = 133 To 138
                    If PB(i).Visible = False Then PB(i).Tag = ""
                Next
                sStoreOld = sStoreItems
                sInventory = PB(133).Tag & ";" & PB(134).Tag & ";" & PB(135).Tag
                sInventory = sInventory & ";" & PB(136).Tag & ";" & PB(137).Tag & ";" & PB(138).Tag & ";"
                sChestOld = Format(iChestX, "00") & Format(iChestY, "00") & sChestItems
                SAVE_MapLoaded = TxtMap.Text
                SaveGame()
            Case Keys.D
                TimMove.Enabled = False
                If SpellDestroy Then
                    If Magic > 3 Then
                        Make_Spell_Destroy()
                        If Magic < 0 Then Magic = 0
                        MyList()
                        DrawIt2()
                        If iBunny > 0 Then TimBunny.Enabled = True
                        Exit Sub
                    Else
                        MagicTalk()
                        Exit Sub
                    End If
                End If
            Case Keys.A
                TimMove.Enabled = False
                If SpellAxe Then
                    If Magic > 3 Then
                        Make_Spell_Axe()
                        If Magic < 0 Then Magic = 0
                        MyList()
                        DrawIt2()
                        If iBunny > 0 Then TimBunny.Enabled = True
                        Exit Sub
                    Else
                        MagicTalk()
                        Exit Sub
                    End If
                End If
            Case Keys.C
                TimMove.Enabled = False
                If SpellCut Then
                    If Magic > 3 Then
                        Make_Spell_Cut()
                        If Magic < 0 Then Magic = 0
                        MyList()
                        DrawIt2()
                        If iBunny > 0 Then TimBunny.Enabled = True
                        Exit Sub
                    Else
                        MagicTalk()
                        Exit Sub
                    End If
                End If
            Case Keys.F
                TimMove.Enabled = False
                If SpellFill Then
                    If Magic > 3 Then
                        Make_FillSwamp()
                        MyList()
                        DrawIt2()
                        If iBunny > 0 Then TimBunny.Enabled = True
                        Exit Sub
                    Else
                        MagicTalk()
                        Exit Sub
                    End If
                End If
            Case Keys.G
                TimMove.Enabled = False
                If SpellGrow Then
                    If Magic > 3 Then
                        Make_GrassGrow()
                        MyList()
                        DrawIt2()
                        If iBunny > 0 Then TimBunny.Enabled = True
                        Exit Sub
                    Else
                        MagicTalk()
                        Exit Sub
                    End If
                End If
           '
           ' View Store
           '
            Case Keys.V
                TimMove.Enabled = False
                If bStore Then
                    For i = 1 To 10
                        myInv(i) = ""
                        If PB(i + 132).Visible Then myInv(i) = PB(i + 132).Tag
                    Next
                    ' sStoreItems = "1015202501020304Axe;Wand;claw;Hat;"
                    FrmStore.ShowDialog()
                    For i = 1 To 10
                        If myInv(i) <> "" Then
                            PB(i + 132).Visible = True
                            PB(i + 132).Tag = myInv(i)
                            FileTile = My.Application.Info.DirectoryPath & "\tiles\" & myInv(i) & ".bmp"
                            PB(i + 132).Image = Image.FromFile(FileTile)
                            Me.ToolTip1.SetToolTip(PB(i + 132), PB(i + 132).Tag)
                        End If
                    Next
                    MyList()
                    If iBunny > 0 Then TimBunny.Enabled = True
                    Exit Sub
                End If
                '
                ' Bomb
                '
            Case Keys.B
                TimMove.Enabled = False
                If Bomb < 1 Then Exit Sub
                Call BombWall()
                SAVE_Life = SAVE_Life - iDamage
                'life
                DrawIt2()
                If iDamage > 0 Then
                    'bRun = False
                    'Holder.Visible = True
                    'Frame2.Visible = False
                    Panel1.Visible = True
                    Pitanje.Text = "Boom..."
                    Choice(1).Text = ">>>Ouch"
                    Choice(1).Visible = True
                    Choice(1).Tag = "NO"
                    Choice(1).Enabled = True
                End If
                Exit Sub
                '
                ' Right
                '
            Case Keys.Right, Keys.K
                iNewx = CharX
                iNewy = CharY
                CharFacing = 3
                PositionMap = Mid(Map(CharY + 6), CharX + 9, 1) & Mid(Map2(CharY + 6), CharX + 9, 1)
                PositionMap2 = Mid(Map3(CharY + 6), CharX + 9, 1) & Mid(Map4(CharY + 6), CharX + 9, 1)
                If bDark Then
                    If PositionMap = sNone Then
                        If SAVE_Candle > 0 Or (SpellLight = True And Magic > 1) Then
                            Make_Spell_Light()
                            PositionMap = Mid(Map(CharY + 3), CharX + 4, 1) & Mid(Map2(CharY + 3), CharX + 4, 1)
                            If SAVE_Candle <= 0 Then EraseItem("CANDLE")
                        End If
                    End If
                End If
                If PositionMap = sJar Then
                    Call Jar(CharY + 6, CharX + 9)
                    If Item > 0 Then
                        DrawIt2()
                        MyList()
                        Exit Sub
                    End If
                End If
                For Each cTile In nTiles
                    'Pick up hidden object
                    If cTile.TileLet = PositionMap2 And cTile.TileType = "ITEM" Then
                        cTilename2 = cTile.TileName
                        iTilePos2 = cTile.MyTileCnt
                    End If
                    If cTile.TileLet = PositionMap Then
                        sNewTileName = cTile.TileName
                        TxtLet.Text = cTile.TileLet
                        If cTile.TileType = "WALK" Or cTile.TileType = "ITEM" Or cTile.TileType = "DOOR" _
                                 Or (cTile.TileType = "BOATWATER" And bHaveBoat) Or cTile.TileType = "BUNNY" Then
                            If cTile.TileType = "WALK" Or cTile.TileType = "BOATWATER" Then SGrass = PositionMap
                            If cTile.TileType = "BOATWATER" Then bOnWater = True
                            cTileType = cTile.TileType
                            iTilePos = cTile.MyTileCnt 's..TileCnt
                            cTilename = cTile.TileName 's.Name
                            CharFacing = 3
                            CharX = CharX + 1
                            txtX.Text = CharX
                            TxtY.Text = CharY
                            TxtName.Text = cTilename
                            TxtType.Text = cTile.TileType
                            DrawIt2()
                            'Exit Sub
                            If iWildLevel > 0 Then wildAppear()
                        Else
                            iNewx = CharX + 1
                            txtX.Text = iNewx
                            TxtY.Text = CharY
                            TxtName.Text = cTile.TileName
                            TxtType.Text = cTile.TileType
                            DrawIt2()
                        End If
                    End If
                Next
                '
                ' Left
                ' 
            Case Keys.Left, Keys.J
                iNewx = CharX
                iNewy = CharY
                CharFacing = 4
                PositionMap = Mid(Map(CharY + 6), CharX + 7, 1) & Mid(Map2(CharY + 6), CharX + 7, 1)
                PositionMap2 = Mid(Map3(CharY + 6), CharX + 7, 1) & Mid(Map4(CharY + 6), CharX + 7, 1)
                If bDark Then
                    If PositionMap = sNone Then
                        If SAVE_Candle > 0 Or (SpellLight = True And Magic > 1) Then
                            Make_Spell_Light()
                            PositionMap = Mid(Map(CharY + 3), CharX + 4, 1) & Mid(Map2(CharY + 3), CharX + 4, 1)
                            If SAVE_Candle <= 0 Then EraseItem("CANDLE")
                        End If
                    End If
                End If
                If PositionMap = sJar Then
                    Call Jar(CharY + 6, CharX + 7)
                    If Item > 0 Then
                        DrawIt2()
                        MyList()
                        Exit Sub
                    End If
                End If
                For Each cTile In nTiles
                    'Pick up hidden object
                    If cTile.TileLet = PositionMap2 And cTile.TileType = "ITEM" Then
                        cTilename2 = cTile.TileName
                        iTilePos2 = cTile.MyTileCnt
                    End If
                    If cTile.TileLet = PositionMap Then
                        sNewTileName = cTile.TileName
                        TxtLet.Text = cTile.TileLet
                        If cTile.TileType = "WALK" Or cTile.TileType = "ITEM" Or cTile.TileType = "DOOR" _
                                 Or (cTile.TileType = "BOATWATER" And bHaveBoat) Or cTile.TileType = "BUNNY" Then
                            If cTile.TileType = "WALK" Or cTile.TileType = "BOATWATER" Then SGrass = PositionMap
                            If cTile.TileType = "BOATWATER" Then bOnWater = True
                            cTileType = cTile.TileType
                            iTilePos = cTile.MyTileCnt 's..TileCnt
                            cTilename = cTile.TileName 's.Name
                            CharX = CharX - 1
                            txtX.Text = CharX
                            TxtY.Text = CharY
                            TxtName.Text = cTilename
                            TxtType.Text = cTile.TileType
                            DrawIt2()
                            'Exit Sub
                            If iWildLevel > 0 Then wildAppear()
                        Else
                            iNewx = CharX - 1
                            txtX.Text = iNewx
                            TxtY.Text = CharY
                            TxtName.Text = cTile.TileName
                            TxtType.Text = cTile.TileType
                            DrawIt2()
                        End If
                    End If
                Next
                '
                ' up
                ' 
            Case Keys.Up, Keys.I
                iNewx = CharX
                iNewy = CharY
                CharFacing = 1
                'PositionMap = Mid(Map(CharY + 4), CharX + 3, 1)
                PositionMap = Mid(Map(CharY + 5), CharX + 8, 1) & Mid(Map2(CharY + 5), CharX + 8, 1)
                PositionMap2 = Mid(Map3(CharY + 5), CharX + 8, 1) & Mid(Map4(CharY + 5), CharX + 8, 1)
                If bDark Then
                    If PositionMap = sNone Then
                        If SAVE_Candle > 0 Or (SpellLight = True And Magic > 1) Then
                            Make_Spell_Light()
                            PositionMap = Mid(Map(CharY + 2), CharX + 3, 1) & Mid(Map2(CharY + 2), CharX + 3, 1)
                            If SAVE_Candle <= 0 Then EraseItem("CANDLE")
                        End If
                    End If
                End If
                If PositionMap = sJar Then
                    Call Jar(CharY + 5, CharX + 8)
                    If Item > 0 Then
                        DrawIt2()
                        MyList()
                        Exit Sub
                    End If
                End If
                For Each cTile In nTiles
                    'Pick up hidden object
                    If cTile.TileLet = PositionMap2 And cTile.TileType = "ITEM" Then
                        cTilename2 = cTile.TileName
                        iTilePos2 = cTile.MyTileCnt
                    End If
                    If cTile.TileLet = PositionMap Then
                        sNewTileName = cTile.TileName
                        TxtLet.Text = cTile.TileLet
                        If cTile.TileType = "WALK" Or cTile.TileType = "ITEM" Or cTile.TileType = "DOOR" _
                                 Or (cTile.TileType = "BOATWATER" And bHaveBoat) Or cTile.TileType = "BUNNY" Then
                            If cTile.TileType = "WALK" Or cTile.TileType = "BOATWATER" Then SGrass = PositionMap
                            If cTile.TileType = "BOATWATER" Then bOnWater = True
                            cTileType = cTile.TileType
                            iTilePos = cTile.MyTileCnt 's..TileCnt
                            cTilename = cTile.TileName 's.Name
                            CharY = CharY - 1
                            txtX.Text = CharX
                            TxtY.Text = CharY
                            TxtName.Text = cTilename
                            TxtType.Text = cTile.TileType
                            DrawIt2()
                            'Exit Sub
                            If iWildLevel > 0 Then wildAppear()
                        ElseIf cTile.TileType = "LOCK" Then
                            'cTileType = tiles.Mytype
                            cTilename = UCase(Mid(cTile.TileName, 1, 1)) & "KEY"
                            TxtName.Text = cTilename
                            'k = -1
                            For i = 133 To 137
                                If UCase(PB(i).Tag) = cTilename And PB(i).Visible Then
                                    CharFacing = 1
                                    CharY = CharY - 1
                                    txtX.Text = CharX
                                    TxtY.Text = CharY
                                    ' PositionMap = Mid(Map(CharY + 5), CharX + 8, 1) & Mid(Map2(CharY + 5), CharX + 8, 1)
                                    Mid(Map(CharY + 6), CharX + 8, 1) = Mid(sDoor, 1, 1)
                                    Mid(Map2(CharY + 6), CharX + 8, 1) = Mid(sDoor, 2, 1)
                                    PB(i).Visible = False
                                    cTileType = "DOOR"
                                End If
                            Next
                        Else
                            iNewy = CharY - 1
                            txtX.Text = iNewx
                            TxtY.Text = iNewy
                            TxtName.Text = cTile.TileName
                            TxtType.Text = cTile.TileType
                            DrawIt2()
                        End If
                    End If
                Next
                '
                ' down
                ' 
            Case Keys.Down, Keys.M
                iNewx = CharX
                iNewy = CharY
                CharFacing = 2
                'PositionMap = Mid(Map(CharY + 4), CharX + 3, 1)
                PositionMap = Mid(Map(CharY + 7), CharX + 8, 1) & Mid(Map2(CharY + 7), CharX + 8, 1)
                PositionMap2 = Mid(Map3(CharY + 7), CharX + 8, 1) & Mid(Map4(CharY + 7), CharX + 8, 1)
                If bDark Then
                    If PositionMap = sNone Then
                        If SAVE_Candle > 0 Or (SpellLight = True And Magic > 1) Then
                            Make_Spell_Light()
                            PositionMap = Mid(Map(CharY + 3), CharX + 4, 1) & Mid(Map2(CharY + 3), CharX + 4, 1)
                            If SAVE_Candle <= 0 Then EraseItem("CANDLE")
                        End If
                    End If
                End If
                If PositionMap = sJar Then
                    Call Jar(CharY + 7, CharX + 8)
                    If Item > 0 Then
                        DrawIt2()
                        MyList()
                        Exit Sub
                    End If
                End If
                For Each cTile In nTiles
                    'Pick up hidden object
                    If cTile.TileLet = PositionMap2 And cTile.TileType = "ITEM" Then
                        cTilename2 = cTile.TileName
                        iTilePos2 = cTile.MyTileCnt
                    End If
                    If cTile.TileLet = PositionMap Then
                        sNewTileName = cTile.TileName
                        TxtLet.Text = cTile.TileLet
                        If cTile.TileType = "WALK" Or cTile.TileType = "ITEM" Or cTile.TileType = "DOOR" _
                                 Or (cTile.TileType = "BOATWATER" And bHaveBoat) Or cTile.TileType = "BUNNY" Then
                            If cTile.TileType = "WALK" Or cTile.TileType = "BOATWATER" Then SGrass = PositionMap
                            If cTile.TileType = "BOATWATER" Then bOnWater = True
                            cTileType = cTile.TileType
                            iTilePos = cTile.MyTileCnt 's..TileCnt
                            cTilename = cTile.TileName 's.Name
                            CharY = CharY + 1
                            txtX.Text = CharX
                            TxtY.Text = CharY
                            TxtName.Text = cTilename
                            TxtType.Text = cTile.TileType
                            DrawIt2()
                            'Exit Sub
                            If iWildLevel > 0 Then wildAppear()
                        Else
                            iNewy = CharY + 1
                            txtX.Text = iNewx
                            TxtY.Text = iNewy
                            TxtName.Text = cTile.TileName
                            TxtType.Text = cTile.TileType
                            DrawIt2()
                        End If
                    End If
                Next
        End Select
        bFoundChest = False
        '
        ' Chest
        '
        If PositionMap = sChest Then
            TimMove.Enabled = False
            If iNewx = iChestX And iNewy = iChestY Then bFoundChest = True
            ChestTalk()
        End If
        '
        ' Bunny
        '
        If PositionMap = sBunny Then
            TimMove.Enabled = False
            Mid(Map(CharY + 6), CharX + 8, 1) = Mid(SGrass, 1, 1)
            Mid(Map2(CharY + 6), CharX + 8, 1) = Mid(SGrass, 2, 1)
            iBunnyCaught = iBunnyCaught + 1
            MeRabbit()
            For i = 1 To iBunny
                If CharX + 5 = iBunnylocX(i) And CharY + 3 = iBunnylocY(i) Then
                    iBunnylocD(i) = 0
                End If
            Next
        End If
        '
        'Add inventory
        '
        If cTilename2 <> "" Then
            TimMove.Enabled = False
            bInvFree = False
            bInvAdd = False
            Mid(Map3(CharY + 6), CharX + 8, 1) = Mid(SGrass, 1, 1)
            Mid(Map4(CharY + 6), CharX + 8, 1) = Mid(SGrass, 2, 1)
            For i = 133 To 138
                If PB(i).Visible = False And bInvAdd = False Then
                    'ImgBlue(iItemCnt).Picture = imgA(iTilePos2).Picture
                    PB(i).Tag = cTilename2
                    PB(i).Image = PB(iTilePos2 + m144).Image
                    Me.ToolTip1.SetToolTip(PB(i), cTilename2)
                    PB(i).Visible = True
                    If UCase(cTilename) = "CANDLE" Then SAVE_Candle = 18
                    bInvAdd = True
                    IName = cTilename2
                    MeFind()
                End If

            Next
            If bInvAdd = False Then
                Mid(Map(CharY + 6), CharX + 8, 1) = Mid(PositionMap2, 1, 1)
                Mid(Map2(CharY + 6), CharX + 8, 1) = Mid(PositionMap2, 2, 1)
            End If
        End If
        '
        '  Speech
        '
        If TxtType.Text = "TALK" Then
            TimMove.Enabled = False
            sTalkType = "SPEECH"
            sTalkTag = ""
            If iMagicPoints > 14 Then sTalkType = "Thought"
            If iMagicPoints > 24 Then sTalkType = "Pence"
            Call MeSpeek()
        End If
        '
        ' Door
        '
        If cTileType = "DOOR" Then
            TimMove.Enabled = False
            For Each doors In nDoors
                If CharX + 5 = doors.DooriX And CharY + 3 = doors.DooriY Then
                    TimBunny.Enabled = False
                    bDark = False
                    CharX = doors.DooriToX - 5
                    CharY = doors.DooriToY - 3
                    txtX.Text = CharX
                    TxtY.Text = CharY
                    cNewMap = doors.Name
                    cMapFile = cNewMap
                    'ReadDoorFile (cNewMap)
                    iWildLevel = 0
                    TxtMap.Text = cNewMap
                    sStoreOld = sStoreItems
                    sChestOld = Format(iChestX, "00") & Format(iChestY, "00") & sChestItems
                    ReadDoorFile(cNewMap)
                    ReadMapFile(cNewMap)
                    ReadSpeech(cNewMap)
                    FindBunnies()
                    If iBunny > 0 Then TimBunny.Enabled = True
                    If bDark Then
                        DarkMapFile(cMapFile)
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(DarkMap(CharY + 5), CharX + 8, 1)
                        Mid(Map(CharY + 4), CharX + 8, 1) = Mid(DarkMap(CharY + 4), CharX + 8, 1)
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(DarkMap(CharY + 6), CharX + 9, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(DarkMap2(CharY + 5), CharX + 8, 1)
                        Mid(Map2(CharY + 4), CharX + 8, 1) = Mid(DarkMap2(CharY + 4), CharX + 8, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(DarkMap2(CharY + 6), CharX + 9, 1)
                        Mid(Map(CharY + 6), CharX + 8, 1) = Mid(DarkMap(CharY + 6), CharX + 8, 1)
                        Mid(Map2(CharY + 6), CharX + 8, 1) = Mid(DarkMap2(CharY + 6), CharX + 8, 1)
                    End If
                    DrawIt2()
                End If
            Next


        End If
        MyList()

    End Sub
    Private Sub ReadTile()
        FileTile = My.Application.Info.DirectoryPath & "\tiles\"
        For Each cTile In nTiles
            iTileloc = cTile.MyTileCnt + m144
            FileTile = My.Application.Info.DirectoryPath & "\tiles\" & cTile.TileName & ".bmp"
            sToolTip = cTile.TileName
            'zzTile(iTileloc).Image = Image.FromFile(FileTile)
            'ShowTile()
            PB(iTileloc).Image = Image.FromFile(FileTile)
            Me.ToolTip1.SetToolTip(PB(iTileloc), cTile.TileName)
            PB(iTileloc).Tag = cTile.TileLet
            bNewLevel = False
            'Exit Sub
        Next
        ' ReadMapFile(cMapFile)
    End Sub
    Public Sub DrawIt2()
        Dim kk As Integer
        Dim PositionMap As String
        Dim cEvent As String
        Dim cDesc As String
        Dim mPB As Integer
        mPB = 1
        For Y = 1 To 10
            For X = 1 To 12
                'If the result to Paint is 0 then it will get error.
                'This will prevent this.
                'PassToNext = 0
                If Y + CharY + 0 < 1 Then Exit Sub
                If X + CharX + 0 < 1 Then Exit Sub
                If X + CharX + 0 > Len(Map(1)) Then Exit Sub
                If Y + CharY + 0 > 99 Then Exit Sub
                'If ChkTop.Value Then
                PositionMap = Mid(Map(Y + CharY + 1), (X + CharX + 1), 1) & Mid(Map2(Y + CharY + 1), (X + CharX + 1), 1)
                'Else
                '    PositionMap = Mid(Map3(Y + CharY + 1), (X + CharX + 1), 1) & Mid(Map4(Y + CharY + 1), (X + CharX + 1), 1)
                'End If
                If Y = 4 And X = 6 Then
                    kk = 1
                End If
                'If X = 0 And Y = 0 Then GoTo skip:
                For Each cTile In nTiles
                    'add all events and descriptions
                    cEvent = cTile.TileLet 'ctile.letter
                    cDesc = cTile.TileName 'tiles.Name
                    If cEvent = PositionMap Then
                        If UCase(cTile.TileType) = "ITEM" Then
                            kk = 1
                        End If
                        'ImgPaint = LoadPicture(App.Path & "\tiles\" & cDesc & ".jpg")
                        If cTile.MyTileCnt = 143 Or cTile.MyTileCnt = 144 Or cTile.MyTileCnt = 145 _
                            Or cTile.MyTileCnt = 146 Or cTile.MyTileCnt = 147 Then
                            PB(mPB).Image = PB(23 + m144).Image
                        Else
                            PB(mPB).Image = PB(cTile.MyTileCnt + m144).Image
                        End If
                        mPB = mPB + 1
                    End If

                    'Text1.Text = Text1.Text & cEvent & " -- " & cDesc & Chr(13) & Chr(10)
                Next
            Next
        Next
        Y = 3
        'Character Movements.
        Select Case CharFacing
            Case Is = 1
                If bOnWater Then
                    PB(55).Image = Imgboat2.Image '        PaintPicture(Imgboat2.Picture, 5 * i32, 5 * i32, i32, i32)
                    Label14.Text = "C=1  B2"
                Else
                    PB(55).Image = imgUpChar.Image
                End If
            Case Is = 2
                If bOnWater Then
                    PB(55).Image = Imgboat.Image  '        PaintPicture(Imgboat2.Picture, 5 * i32, 5 * i32, i32, i32)
                    Label14.Text = "C=2  B"
                Else
                    PB(55).Image = imgDownChar.Image
                    'PB(55).Image = imgLeftChar.Image
                End If
            Case Is = 3
                If bOnWater Then
                    PB(55).Image = Imgboat3.Image '        PaintPicture(ImgBoat.Picture, 5 * i32, 5 * i32, i32, i32)
                    Label14.Text = "C=3  B3"
                Else
                    PB(55).Image = imgRightChar.Image ',    PaintPicture(imgRightChar.Picture, 5 * i32, 5 * i32, i32, i32)
                End If
            Case Is = 4
                If bOnWater Then
                    PB(55).Image = Imgboat1.Image   '        PaintPicture(Imgboat1.Picture, 5 * i32, 5 * i32, i32, i32)
                    Label14.Text = "C=4  B1"
                Else
                    PB(55).Image = imgLeftChar.Image
                    'PB(55).Image = imgDownChar.Image
                End If
            Case Is = 5
                PB(55).Image = imgCarryChar.Image
                PB(43).Image = PB(CharJar).Image 'jar
        End Select
    End Sub



    Private Sub ShowMap()
        Dim bm As New Bitmap(FileTile)
        '  bm=New 
        ' Display the results.
        PB(iTileloc).Image = bm

    End Sub
    Function wildAppear()
        Dim iFx As Integer
        Dim iFy As Integer
        Dim xyzlevel As Integer
        'Randomize
        iFx = Int((40 - 1 + 1) * Rnd() + 1)
        iFx = 227


        'found wild pokemon
        If iFx > 26 And iFx < 29 Then
            Randomize()
            iFy = Int(Rnd() * (ListBox1.Items.Count - 1))
            xyzlevel = Int((iWildLevel - (iWildLevel - 5) + 1) * Rnd() + (iWildLevel - 5))
            'z = enPkmn(Y)
            'enParty = Array(z)
            'enPartyLevel = Array(xyzlevel)
            enParty(0) = Mid(ListBox1.Items(iFy).ToString, 1, Len(ListBox1.Items(iFy).ToString) - 4) 'ListBox1.Items(iFy).ToString ' Mid(File1.List(iFy), 1, Len(File1.List(iFy)) - 4)
            enPartyLevel(0) = xyzlevel
            enParty(1) = ""
            frmSplash.tmrHeal.Enabled = False
            frmSplash.Timer1.Enabled = True
            frmSplash.ShowDialog()
            FrmBattle.ShowDialog()
        End If
    End Function
    Private Sub MyList()
        Dim i As Integer
        Dim iGcnt As Integer
        LblTicket.Text = Ticket
        LblCoin.Text = Coin
        LblToast.Text = Toast
        LblMagic.Text = Magic
        LblWood.Text = Wood
        LblBomb.Text = Bomb
        DGrid.Rows.Clear()
        DGrid.Columns.Clear()
        'FlexGrid.Rows = 1
        ' FlexGrid.Clear()
        ' FlexGrid.Enabled = flase
        If SpellLight Then LblLight.BackColor = Color.LightGreen
        If SpellDestroy Then LblDestroy.BackColor = Color.LightGreen
        If SpellAxe Then LblAxe.BackColor = Color.LightGreen
        If SpellCut Then LblCut.BackColor = Color.LightGreen
        If SpellFill Then LblFill.BackColor = Color.LightGreen
        If SpellGrow Then LblGrow.BackColor = Color.LightGreen
        'FlexGrid.FormatString = "Done" & vbTab & "Name:                 "
        DGrid.ColumnCount = 2
        DGrid.Columns(0).Name = "Done"
        DGrid.Columns(1).Name = "Name:-------------------------=-"
        iGcnt = 0
        For i = 1 To 100
            If Mquest(i) = "N" Then
                'FlexGrid.AddItem(Mquest(i) & vbTab & MquestName(i))
                DGrid.Rows.Insert(iGcnt, New String() {Mquest(i), MquestName(i)})
                iGcnt = iGcnt + 1
            End If
        Next
        For i = 1 To 100
            If Mquest(i) = "Y" Then
                'FlexGrid.AddItem(Mquest(i) & vbTab & MquestName(i))
                DGrid.Rows.Insert(iGcnt, New String() {Mquest(i), MquestName(i)})
                iGcnt = iGcnt + 1
            End If
        Next
        LblBunny.Text = "Bunny = " & iBunnyCaught
        iMagicPoints = 5 + iBunnyCaught * 5
        If SpellCut Then iMagicPoints = iMagicPoints + 5
        If SpellDestroy Then iMagicPoints = iMagicPoints + 5
        If SpellFill Then iMagicPoints = iMagicPoints + 5
        If SpellLight Then iMagicPoints = iMagicPoints + 5
        If SpellAxe Then iMagicPoints = iMagicPoints + 5
        If SpellGrow Then iMagicPoints = iMagicPoints + 5
        If Spell1 Then iMagicPoints = iMagicPoints + 5
        If iMagicPoints < 15 Then
            LblLevel.Text = "Level = None (" & iMagicPoints & ")"
        ElseIf iMagicPoints > 14 And iMagicPoints < 25 Then
            LblLevel.Text = "Level = Thought (" & iMagicPoints & ")"
        ElseIf iMagicPoints > 24 And iMagicPoints < 35 Then
            LblLevel.Text = "Level = Pence (" & iMagicPoints & ")"
        ElseIf iMagicPoints > 34 And iMagicPoints < 55 Then
            LblLevel.Text = "Level = Transport 1 (" & iMagicPoints & ")"
        ElseIf iMagicPoints > 44 And iMagicPoints < 65 Then
            LblLevel.Text = "Level = Transport 2 (" & iMagicPoints & ")"
        ElseIf iMagicPoints > 54 And iMagicPoints < 135 Then
            LblLevel.Text = "Level = Transport 3 (" & iMagicPoints & ")"
        End If
        For i = 145 To 184
            PB(i).Visible = False
            If sBadge(i - 144) <> "" Then
                FileTile = My.Application.Info.DirectoryPath & "\Images\badges\" & sBadge(i - 144) & ".gif"
                PB(i).Image = Image.FromFile(FileTile)
                PB(i).Visible = True
                Me.ToolTip1.SetToolTip(PB(i), sBadge(i - 144))
            End If
        Next
    End Sub
    Private Sub GetFiles()
        '
        ' Read all the levels
        '
        Dim value As String = My.Application.Info.DirectoryPath & "\images\PokemonPics\"
        Dim di As New IO.DirectoryInfo(value)
        Dim diar1 As IO.FileInfo() = di.GetFiles("*.*")
        Dim dra As IO.FileInfo
        Dim sMsg As String
        sMsg = value
        'list the names of all files in the specified directory
        For Each dra In diar1
            ListBox1.Items.Add(dra)
        Next
    End Sub
    Private Sub ShowTile()
        Dim bm As New Bitmap(FileTile)
        '  bm=New 
        ' Display the results.
        'zzTile(iTileloc).Image = bm
        PB(iTileloc).Image = bm
        Me.ToolTip1.SetToolTip(PB(iTileloc), sToolTip)
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim kLR As Integer
        Dim kUD As Integer
        Dim m As Integer
        Dim i As Integer
        Dim j As Integer
        Dim j1 As Integer
        Dim value As String = My.Application.Info.DirectoryPath
        sFilebug = value & "\text.txt"
        srFilebug = New System.IO.StreamWriter(sFilebug)
        bPlayGame = True
        TimBunny.Enabled = False
        GetFiles()        '
        Randomize()
        m144 = 144 + 50
        If bLoadMap = False Then
            frmSelectPkmn.ShowDialog()
            For m = 1 To 90
                Mquest(m) = ""
                MquestName(m) = ""
                sBadge(m) = ""
            Next
            Pokeballs = 10
            SpellCut = False
            SpellDestroy = False
            SpellFill = False
            SpellLight = False
            SpellAxe = False
            SpellGrow = False
            bOnWater = False
            iMapReadIn = 0
            bHaveBoat = False
            bFoundChest = False
            iBunnyCaught = 0
            cMapFile = "New"
            Coin = 0
            Magic = 0
            Wood = 0
            Toast = 0
            Bomb = 0
            Ticket = 0
            iItemCnt = 0
            strChrName = "George"
            CharFacing = 3
            CharX = 4
            CharY = 5
            SAVE_Candle = 0 ' 118
            sInventory = ""
        End If
        sNewTileName = ""
        FileTile = My.Application.Info.DirectoryPath & "\tiles\mLeft.jpg"
        imgLeftChar.Image = Image.FromFile(FileTile)
        FileTile = My.Application.Info.DirectoryPath & "\tiles\mright.jpg"
        imgRightChar.Image = Image.FromFile(FileTile)
        FileTile = My.Application.Info.DirectoryPath & "\tiles\mup.jpg"
        imgUpChar.Image = Image.FromFile(FileTile)
        FileTile = My.Application.Info.DirectoryPath & "\tiles\mdown.jpg"
        imgDownChar.Image = Image.FromFile(FileTile)
        FileTile = My.Application.Info.DirectoryPath & "\tiles\mcarry.jpg"
        imgCarryChar.Image = Image.FromFile(FileTile)
        FileTile = My.Application.Info.DirectoryPath & "\tiles\boat1.jpg"
        Imgboat1.Image = Image.FromFile(FileTile)
        FileTile = My.Application.Info.DirectoryPath & "\tiles\boat2.jpg"
        Imgboat2.Image = Image.FromFile(FileTile)
        FileTile = My.Application.Info.DirectoryPath & "\tiles\boat3.jpg"
        Imgboat3.Image = Image.FromFile(FileTile)
        FileTile = My.Application.Info.DirectoryPath & "\tiles\boat4.jpg"
        Imgboat.Image = Image.FromFile(FileTile)
        iTileloc = 1
        ReadTiles()
        iLevel = 1
        bNewLevel = True
        FileTile = My.Application.Info.DirectoryPath & "\tiles\grass.bmp"
        '
        ' Map
        '
        For kUD = 1 To 12
            For kLR = 1 To 12
                m = kLR + kUD * 12 - 12
                PB(m) = New System.Windows.Forms.PictureBox()
                With PB(m)
                    .Name = m
                    .Location = New System.Drawing.Point(30 * kLR - 10, 30 * kUD - 5)
                    .Size = New Size(30, 30)
                End With

                '  This is the line that sometimes catches people out!
                '  This is the line that sometimes catches people out!
                Me.Controls.Add(PB(m))
                AddHandler PB(m).Click, AddressOf pbe_Click
            Next
        Next
        For kUD = 1 To 10
            For kLR = 1 To 25
                m = kLR + kUD * 25 - 25 + m144
                PB(m) = New System.Windows.Forms.PictureBox()
                With PB(m)
                    .Name = m
                    .Location = New System.Drawing.Point(30 * kLR - 10, 30 * kUD + 375)
                    .Size = New Size(30, 30)
                    .Tag = ""
                    .Visible = False
                End With

                '  This is the line that sometimes catches people out!
                Me.Controls.Add(PB(m))
                ' AddHandler PB(m).Click, AddressOf pb_Click
            Next
        Next
        'For m = 1 To 300
        '    If m > 120 Then FileTile = My.Application.Info.DirectoryPath & "\tiles\apple.bmp"
        '    iTileloc = m
        '    ShowMap()
        'Next
        FileTile = My.Application.Info.DirectoryPath & "\tiles\sign.jpg"
        PB(121).Image = Image.FromFile(FileTile)
        PB(121).Tag = "Ticket"
        Me.ToolTip1.SetToolTip(PB(121), "Ticket")
        FileTile = My.Application.Info.DirectoryPath & "\tiles\wood.jpg"
        PB(122).Image = Image.FromFile(FileTile)
        Me.ToolTip1.SetToolTip(PB(122), "Wood")
        PB(122).Tag = "Wood"
        FileTile = My.Application.Info.DirectoryPath & "\tiles\magic.jpg"
        PB(123).Image = Image.FromFile(FileTile)
        Me.ToolTip1.SetToolTip(PB(123), "Magic")
        PB(123).Tag = "Magic"
        FileTile = My.Application.Info.DirectoryPath & "\tiles\toast.jpg"
        PB(124).Image = Image.FromFile(FileTile)
        Me.ToolTip1.SetToolTip(PB(124), "Toast")
        PB(124).Tag = "Toast"
        FileTile = My.Application.Info.DirectoryPath & "\tiles\coin.jpg"
        PB(125).Image = Image.FromFile(FileTile)
        Me.ToolTip1.SetToolTip(PB(125), "Coin")
        PB(125).Tag = "Coin"
        FileTile = My.Application.Info.DirectoryPath & "\tiles\bomb.jpg"
        PB(126).Image = Image.FromFile(FileTile)
        PB(126).Tag = "Bomb"

        Me.ToolTip1.SetToolTip(PB(126), "Bomb")
        For m = 127 To 144
            PB(m).Top = PB(m).Top + 25
            PB(m).Visible = False
        Next
        '
        ' Inventory
        '
        FileTile = My.Application.Info.DirectoryPath & "\tiles\boatwater.bmp"
        'For i = 133 To 138
        '    PB(i).Image = Image.FromFile(FileTile)
        '    ' PB(i).Visible = True
        '    '(i).Left = PB(i - 6).Left
        '    'PB(i).Top = PB(i - 6).Top + 55
        'Next
        ReadTile()
        'FileTile = My.Application.Info.DirectoryPath & "\tiles\YKey.bmp"
        'PB(133).Image = Image.FromFile(FileTile)
        'PB(133).Tag = "YKey"
        'PB(133).Visible = True
        'Me.ToolTip1.SetToolTip(PB(133), "BOAT")
        'FileTile = My.Application.Info.DirectoryPath & "\tiles\candle.bmp"
        'PB(134).Image = Image.FromFile(FileTile)
        'PB(134).Tag = "CANDLE"
        'PB(134).Visible = True
        'Me.ToolTip1.SetToolTip(PB(134), "CANDLE")
        If bLoadMap Then
            j = 1
            j1 = InStr(j, sInventory, ";")
            For i = 133 To 138
                PB(i).Tag = ""
                PB(i).Visible = False
                If (j1 - j) > 1 Then
                    PB(i).Tag = Mid(sInventory, j, j1 - j)
                    PB(i).Visible = True
                    FileTile = My.Application.Info.DirectoryPath & "\tiles\" & PB(i).Tag & ".bmp"
                    PB(i).Image = Image.FromFile(FileTile)
                    Me.ToolTip1.SetToolTip(PB(i), PB(i).Tag)
                End If
                j = j1 + 1
                j1 = InStr(j, sInventory, ";")
            Next
            bHaveBoat = False
            j = InStr(1, UCase(sInventory), "BOAT")
            If j > 0 Then bHaveBoat = True
        End If
        NextLevel()
        Dim myfont As New Font("Sans Serif", 10, FontStyle.Bold)
        For i = 1 To 8
            Choice(i) = New System.Windows.Forms.Label
            With Choice(i)
                .Name = i
                .Location = New System.Drawing.Point(40, 20 + 25 * i)
                .Size = New Size(30, 30)
                .AutoSize = True
                .Font = myfont

            End With

            '  This is the line that sometimes catches people out!
            Panel1.Controls.Add(Choice(i))
            ' Choice(i).Text = "HELLO" & i
            AddHandler Choice(i).Click, AddressOf pbc_Click
            AddHandler Choice(i).MouseMove, AddressOf pbc_MouseMove
        Next
        FileTile = My.Application.Info.DirectoryPath & "\tiles\apple.bmp"
        For kUD = 1 To 8
            For kLR = 1 To 5
                i = kLR + kUD * 5 - 5 + 144
                PB(i) = New System.Windows.Forms.PictureBox
                With PB(i)
                    .Name = i
                    .Location = New System.Drawing.Point(35 * kLR - 10, 35 * kUD)
                    .Size = New Size(30, 30)
                    ' .AutoSize = True
                    '.Font = myfont
                    .Visible = False
                    .SizeMode = PictureBoxSizeMode.StretchImage
                End With

                '  This is the line that sometimes catches people out!
                Panel2.Controls.Add(PB(i))
                PB(i).Image = Image.FromFile(FileTile)
                ' Choice(i).Text = "HELLO" & i
                ' AddHandler Choice(i).Click, AddressOf pbc_Click
                ' AddHandler Choice(i).MouseMove, AddressOf pbc_MouseMove
            Next
        Next
        MyList()
        FindBunnies()
        If iBunny > 0 Then TimBunny.Enabled = True
        'sGiveBadge = "boulder"
        'AddBadge()
    End Sub
    Private Sub pbe_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim cmsg As PictureBox
        cmsg = sender
        Dim i As Integer
        i = Val(cmsg.Name)
        If i > 120 And i < m144 Then
            If PB(i).BorderStyle = BorderStyle.Fixed3D Then
                sMeGive = ""
                iMeQty = 1
                sTalkTag = ""
                LblJar.Text = ""
                LblJar.Visible = False
                PB(i).BorderStyle = BorderStyle.None
            Else
                sMeGive = PB(i).Tag
                iMeQty = 1
                sTalkTag = ""
                LblJar.Text = sMeGive
                LblJar.Visible = True
                PB(i).BorderStyle = BorderStyle.Fixed3D
                Select Case i
                    Case 121
                        iMeQty = Ticket
                    Case 122
                        iMeQty = Wood
                    Case 123
                        iMeQty = Magic
                    Case 124
                        iMeQty = Toast
                    Case 125
                        iMeQty = Coin
                    Case 126
                        iMeQty = Bomb
                End Select
                LblJar.Text = iMeQty & " " & sMeGive
                If TxtType.Text = "TALK" And iMeQty > 0 Then MeSpeek()
            End If
        End If
        'PBE(i).Tag = PicAll.Tag
        'iMapE(i) = PicAll.Tag
        'PBE(i).Image = PicAll.Image
        '  MessageBox.Show("btn_Click method " & cmsg.Name, "Events Demonstration ")
    End Sub
    Private Sub pbc_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim clabel As Label
        clabel = sender
        Dim i As Integer
        For i = 1 To 8
            Choice(i).ForeColor = Color.Black
        Next
        i = Val(clabel.Name)
        If i < 1 Or i > 8 Then Exit Sub
        Choice(i).ForeColor = Color.Red
    End Sub
    Private Sub pbc_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim clabel As Label
        Dim bInvAdd As Boolean
        clabel = sender
        Dim i As Integer
        i = Val(clabel.Name)
        Dim cMsg As String
        Dim iTilePos As Integer
        sTalkTag = Choice(i).Tag
        If sTalkTag = "0000" Or UCase(sTalkTag) = "NO" Then
            Panel1.Visible = False
            MyList()
            DGrid.Visible = True
            'Holder.Visible = False
            'If bMyPlayGame Then
            '    ShowQuest()
            '    CmdBattle.Visible = False
            'End If
            sTalkTag = ""
        ElseIf UCase(sTalkTag) = "CURE" Then ' Cure Pokemon
            CurePoko()
        ElseIf UCase(sTalkTag) = "POKE" Then  ' Battle
            '  sGiveBadge =
            ' FrmBattle.CmdCatch.Visible = False
            FrmBattle.CmdRun.Visible = False
            FrmBattle.ShowDialog()
            ' FlexGrid.Visible = False
            Panel1.Visible = True
            For i = 1 To 6
                Choice(1).AutoSize = False
            Next
            If sGiveBadge <> "" Then
                Pitanje.Text = speech.Name & " Here is the " & sGiveBadge & " Badge"
            ElseIf bYouWin Then
                Pitanje.Text = speech.Name & " You Won!!"
            Else
                Pitanje.Text = speech.Name & " You Lost.."
            End If
            Choice(1).Text = "<Speech> Bye"
            Choice(1).AutoSize = True
            Choice(1).Visible = True
            Choice(1).Tag = "0000"
            If sGiveBadge <> "" Then AddBadge()
            sGiveBadge = ""
        ElseIf sTalkTag = "SPEECH" Then
            sTalkType = "Speech"
            sTalkTag = ""
            Call MeSpeek()
        ElseIf sTalkTag = "THOUGHT" Then
            sTalkType = "Thought"
            sTalkTag = ""
            Call MeSpeek()
        ElseIf UCase(sTalkTag) = "YES" Then
            'Holder.Visible = False
            'sTag = ""
            If bFoundChest Then
                Pitanje.Text = "You found a " & sChestItems '"Boommmm.... "
                Choice(1).Text = ">>>Bye" '">>>Ouch"
                Choice(1).Tag = "0000"
                Choice(1).Visible = True
                Choice(2).Visible = False
                bInvAdd = False
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 2, 1)
                For Each cTile In nTiles
                    If UCase(cTile.TileName) = UCase(sChestItems) Then
                        For i = 133 To 138
                            If PB(i).Visible = False And bInvAdd = False Then
                                'ImgBlue(iItemCnt).Picture = imgA(iTilePos2).Picture
                                PB(i).Tag = sChestItems
                                PB(i).Image = PB(cTile.MyTileCnt + m144).Image
                                Me.ToolTip1.SetToolTip(PB(i), sChestItems)
                                PB(i).Visible = True
                                If UCase(sChestItems) = "CANDLE" Then SAVE_Candle = 18
                                bInvAdd = True
                            End If
                        Next
                        If bInvAdd = False Then
                            Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(cTile.TileLet, 1, 1)
                            Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(cTile.TileLet, 2, 1)
                        End If
                        DrawIt2()
                    End If
                Next
            Else
                Pitanje.Text = "Nothing" '"Boommmm.... "
                Choice(1).Text = ">>>Bye" '">>>Ouch"

                Choice(1).Tag = "0000"
                Choice(1).Visible = True
                Choice(2).Visible = False
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 2, 1)
                DrawIt2()
            End If
        Else
            Call MeSpeek()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        PB(43).Image = PB(123).Image 'jar
        PB(43).Image = PB(125).Image 'coin
        PB(43).Image = PB(122).Image 'wood
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim i As Integer
        Dim j As Integer
        Dim j1 As Integer
        Dim p As String
        p = Mid(Map(8 + 6), 12 + 8, 1) & Mid(Map2(8 + 6), 12 + 8, 1)
        LoadGame()
        'If bDark Then DarkMapFile(TxtMap.Text)
        p = Mid(Map(8 + 6), 12 + 8, 1) & Mid(Map2(8 + 6), 12 + 8, 1)
        j = 1
        j1 = InStr(j, sInventory, ";")
        For i = 133 To 138
            PB(i).Tag = ""
            PB(i).Visible = False
            If (j1 - j) > 1 Then
                PB(i).Tag = Mid(sInventory, j, j1 - j)
                PB(i).Visible = True
                FileTile = My.Application.Info.DirectoryPath & "\tiles\" & PB(i).Tag & ".bmp"
                PB(i).Image = Image.FromFile(FileTile)
            End If
            j = j1 + 1
            j1 = InStr(j, sInventory, ";")
        Next
        ReadDoorFile(cMapFile)
        ReadMapFile(cMapFile)
        ReadSpeech(cMapFile)
        If bDark Then DarkMapFile(cMapFile)
        TxtMap.Text = cMapFile
        MyList()
        DrawIt2()
    End Sub

    Private Sub Button1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Button1.KeyDown
        Call Moveme(e.KeyCode)
    End Sub
    Private Sub Button2_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Button2.KeyDown
        Call Moveme(e.KeyCode)
    End Sub

    Private Sub Button1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Button1.KeyUp
        'Call Moveme(KeyCode)
    End Sub




    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub MenuStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub MapsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MapsToolStripMenuItem.Click
        FrmEdit.ShowDialog()
    End Sub

    Private Sub SpeechToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SpeechToolStripMenuItem.Click
        FrmSpeech.ShowDialog()
    End Sub

    Private Sub TimBunny_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimBunny.Tick
        Dim i As Integer
        Dim j As Integer
        Dim iBx As Integer
        Dim iBy As Integer
        Dim iBxold As Integer
        Dim iByold As Integer
        Dim bPos As String
        Dim bMove As Boolean
        If iBunny > 0 Then
            For j = 1 To iBunny
                bMove = False
                iBxold = iBunnylocX(j)
                iByold = iBunnylocY(j)
                bPos = Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) & Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1)
                If bPos <> sBunny Then iBunnylocD(j) = 0
                If iBunnylocD(j) > 0 Then
                    If iBunnylocD(j) = 1 Then
                        'right
                        bPos = Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 4, 1) & Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 4, 1)
                        If bPos = sGrass2 Then
                            Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sGrass2, 1, 1)
                            Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sGrass2, 2, 1)
                            iBunnylocX(j) = iBunnylocX(j) + 1
                            Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sBunny, 1, 1)
                            Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sBunny, 2, 1)
                            bMove = True
                        Else
                            iBunnylocD(j) = 2
                            ' Label12.Text = bPos & " " & sGrass2
                        End If
                    End If
                    If iBunnylocD(j) = 2 Then
                        'up
                        bPos = Mid(Map(iBunnylocY(j) + 2), iBunnylocX(j) + 3, 1) & Mid(Map2(iBunnylocY(j) + 2), iBunnylocX(j) + 3, 1)
                        If bPos = sGrass2 Then
                            Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sGrass2, 1, 1)
                            Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sGrass2, 2, 1)
                            iBunnylocY(j) = iBunnylocY(j) - 1
                            Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sBunny, 1, 1)
                            Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sBunny, 2, 1)
                            bMove = True
                        Else
                            iBunnylocD(j) = 3
                            'Label13.Text = bPos & " " & sGrass2
                        End If
                    End If
                    If iBunnylocD(j) = 3 Then
                        'left
                        bPos = Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 2, 1) & Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 2, 1)
                        If bPos = sGrass2 Then
                            Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sGrass2, 1, 1)
                            Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sGrass2, 2, 1)
                            iBunnylocX(j) = iBunnylocX(j) - 1
                            Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sBunny, 1, 1)
                            Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sBunny, 2, 1)
                            bMove = True
                        Else
                            iBunnylocD(j) = 4
                        End If
                    End If
                    If iBunnylocD(j) = 4 Then
                        'down
                        bPos = Mid(Map(iBunnylocY(j) + 4), iBunnylocX(j) + 3, 1) & Mid(Map2(iBunnylocY(j) + 4), iBunnylocX(j) + 3, 1)
                        If bPos = sGrass2 Then
                            Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sGrass2, 1, 1)
                            Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sGrass2, 2, 1)
                            iBunnylocY(j) = iBunnylocY(j) + 1
                            Mid(Map(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sBunny, 1, 1)
                            Mid(Map2(iBunnylocY(j) + 3), iBunnylocX(j) + 3, 1) = Mid(sBunny, 2, 1)
                            bMove = True
                        Else
                            iBunnylocD(j) = 1
                        End If
                    End If
                    ' If bMove Then
                    'For Y = -3 To 6
                    'For X = -3 To 8
                    bPos = Mid(Map(iBunnylocY(j) + 2), iBunnylocX(j) + 3, 1) & Mid(Map2(iBunnylocY(j) + 2), iBunnylocX(j) + 3, 1)
                    If bPos = "1v" Then
                        iBy = Math.Abs(CharY - iBunnylocY(j))
                    End If
                    iBy = Math.Abs(CharY - iBunnylocY(j))
                    iBx = Math.Abs(CharX - iBunnylocX(j))
                    ' TimBunny.Enabled = False
                    ' Exit Sub
                    If iBy < 12 And iBx < 14 Then DrawIt2()
                    'If iBx = (iBunnylocX(j) + 3) And iBy = (iBunnylocY(j) + 3) Then
                    '    'PaintPicture(imgA(iBunnyTile).Picture, (X + 3) * i32, (Y + 3) * i32)
                    '    PB(mPB).Image = PB(cTile.MyTileCnt + m144).Image
                    'End If
                    'If iBx = (iBxold + 3) And iBy = (iByold + 3) Then
                    '    'PaintPicture(imgA(iGrassTile).Picture, (X + 3) * i32, (Y + 3) * i32)
                    '    PB(mPB).Image = PB(cTile.MyTileCnt + m144).Image
                    'End If
                    ' Next
                    '  Next
                    ' End If
                End If
            Next
        End If
    End Sub

    Private Sub Pitanje_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pitanje.Click

    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        ' Call Moveme(e.KeyCode)
        LblMe.Text = e.KeyCode
        iKeycode = e.KeyCode
        If TimMove.Enabled = False Then Call Moveme(iKeycode)
        If e.KeyCode = Keys.Right Or e.KeyCode = Keys.Left Or
            e.KeyCode = Keys.Up Or e.KeyCode = Keys.Down Then
            TimMove.Enabled = True
        End If
    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        TimMove.Enabled = False
    End Sub

    Private Sub TimMove_Tick(sender As Object, e As EventArgs) Handles TimMove.Tick
        '  TimMove.Enabled = False
        Call Moveme(iKeycode)
        ' TimMove.Enabled = True
    End Sub
End Class
