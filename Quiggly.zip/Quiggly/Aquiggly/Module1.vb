﻿Module Module1
    Public sImaster As String
    Public iScnt44 As Integer
    Public bLoadStore As Boolean
    Public PB(900) As PictureBox
    Public ImgItem(600) As PictureBox
    Public PBadge(50) As PictureBox
    Public TxtPrice(20) As TextBox
    Public Choice(20) As Label
    Public PBTile(500) As PictureBox
    Public zzTile(500) As PictureBox
    Public CharJar As Integer
    Public RB(40) As RadioButton
    Public myInv(10) As String
    Public sCode As String
    Public iLevel As Integer
    Public iLAstTile As Integer
    Public iBunny As Integer
    Public iBadgecnt As Integer
    Public iTilecnt As Integer
    Public iTileloc As Integer
    Public bNewLevel As Boolean
    Public nTiles As Collection
    Public m144 As Integer
    ' Public cFoe As ClsFoe
    Public cTile As ClsTile
    Public FileTile As String
    Public sToolTip As String
    Public sBunny As String
    Public iBunnyTile As Integer
    Public sGrass2 As String
    Public iGrassTile As Integer
    Public strChrName As String
    Public sChestItems As String
    Public SAVE_MapLoaded As String
    Public sInventory As String
    Public itemHouseFound1 As Boolean
    Public itemHouseFound2 As Boolean
    Public itemHouseFound3 As Boolean
    Public iJar(2, 100) As Integer
    Public iJarCnt As Integer
    Public bPlayGame As Boolean
    Public iJarLast As Integer
    Public iWildLevel As Integer
    Public iNewx As Integer
    Public iNewy As Integer
    Public sNewTileName As String
    Public Coin As Integer
    Public Wood As Integer
    Public Magic As Integer
    Public Ticket As Integer
    Public Toast As Integer
    Public Bomb As Integer
    Public iMeQty As Integer
    Public iDamage As Integer
    Public Item As Integer
    Public SAVE_Candle As Integer
    Public SAVE_Life As Integer
    Public sTalkType As String
    Public sChest As String
    Public sMeGive As String
    Public sWall As String
    Public sTree As String
    Public sTreeDoor As String
    Public nPoko As Collection
    Public poko As ClsPoko
    Public sWeed As String
    Public sWeedDoor As String
    Public sSwamp As String
    Public sSwampDoor As String
    Public sGrow As String
    Public sGrowDoor As String
    Public sRock As String
    Public sRockDoor As String
    Public sJar As String
    Public sTalkTag As String
    Public Map(100) As String
    Public Map2(100) As String
    Public sDoor As String
    Public Map3(100) As String
    Public Map4(100) As String
    Public DarkMap(100) As String
    Public DarkMap2(100) As String
    Public sOldMapFile As String
    Public sGiveBadge As String
    Public iMapReadIn As Integer
    Public Mquest(100) As String
    Public MquestName(100) As String
    Public sBadge(100) As String
    Public sStoreItems As String
    Public sNone As String
    Public sStoreOld As String
    Public sChestOld As String
    Public cNewMap As String
    Public cMapFile As String
    Public SGrass As String
    Public sWallDoor As String
    Public sStairs As String
    Public sWallGrass As String
    Public CharX As Integer
    Public CharY As Integer
    Public X As Integer
    Public Y As Integer
    Public Pokeballs As Integer
    Public iBunnyCaught As Integer
    Public CharFacing As Integer
    Public bOnWater As Boolean
    Public bHaveBoat As Boolean
    Public bDark As Boolean
    Public bStore As Boolean
    Public iChest As Integer
    Public iMagicPoints As Integer
    Public iChestX As Integer
    Public iChestY As Integer
    Public iItemCnt As Integer
    Public nDoors As Collection
    Public doors As ClsDoor
    Public nSpeech As Collection
    Public speech As ClsSpeech
    Public SpellCut As Boolean
    Public SpellDestroy As Boolean
    Public SpellFill As Boolean
    Public SpellLight As Boolean
    Public SpellAxe As Boolean
    Public SpellGrow As Boolean
    Public SpellWade As Boolean
    Public Spell1 As Boolean
    Public bFoundChest As Boolean
    Public nSaveMap As Collection
    Public SaveMap As ClsSaveMap
    Public bLoadMap As Boolean
    Public Function CheckWalk(ByVal sChecktile As String) As Boolean
        CheckWalk = False
        For Each cTile In nTiles
            If cTile.TileLet = sChecktile Then
                If cTile.TileType = "WALK" Or (cTile.TileType = "BOATWATER" And bHaveBoat) Then
                    CheckWalk = True
                    Exit Function
                Else
                    CheckWalk = False
                    Exit Function
                End If
            End If
        Next

    End Function
    Public Sub Transport(ByVal iMove As Integer)
        Dim PositionMap As String
        If Magic > 4 + iMove Then
            If CharFacing = 1 Then 'Up
                PositionMap = Mid(Map(CharY + 6 - iMove), CharX + 8, 1) & Mid(Map2(CharY + 6 - iMove), CharX + 8, 1)
                If CheckWalk(PositionMap) Then
                    CharY = CharY - iMove
                    'Mid(Map(CharY + 2), CharX + 3, 1) = "#"
                    ' Mid(Map(CharY + 3 - iMove), CharX + 3, 1) = "~"
                    Magic = Magic - 4 - iMove
                End If
            End If

            If CharFacing = 2 Then 'Down
                PositionMap = Mid(Map(CharY + 6 + iMove), CharX + 8, 1) & Mid(Map2(CharY + 6 + iMove), CharX + 8, 1)
                If CheckWalk(PositionMap) Then
                    ' Mid(Map(CharY + 4), CharX + 3, 1) = "G"
                    'Mid(Map(CharY + 2), CharX + 3, 1) = "#"
                    CharY = CharY + iMove
                    Magic = Magic - 4 - iMove
                End If
            End If

            If CharFacing = 3 Then 'Right
                PositionMap = Mid(Map(CharY + 6), CharX + 8 + iMove, 1) & Mid(Map2(CharY + 6), CharX + 8 + iMove, 1)
                If CheckWalk(PositionMap) Then
                    CharX = CharX + iMove
                    Magic = Magic - 4 - iMove
                End If
            End If

            If CharFacing = 4 Then 'Left
                PositionMap = Mid(Map(CharY + 6), CharX + 8 - iMove, 1) & Mid(Map2(CharY + 6), CharX + 8 - iMove, 1)
                If CheckWalk(PositionMap) Then
                    CharX = CharX - iMove
                    Magic = Magic - 4 - iMove
                End If
            End If
        End If
    End Sub
    Public Sub Make_GrassGrow()
        Dim PositionMap As String
        If Magic > 4 Then
            PositionMap = Mid(Map(iNewy + 6), iNewx + 8, 1) & Mid(Map2(iNewy + 6), iNewx + 8, 1)
            If PositionMap = sGrow Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 2, 1)
                Magic = Magic - 4
                Exit Sub
            ElseIf PositionMap = sGrowDoor Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 2, 1)
                Magic = Magic - 4
                Exit Sub
            End If
            Select Case CharFacing
                Case 1 'up
                    PositionMap = Mid(Map(CharY + 5), CharX + 8, 1) & Mid(Map2(CharY + 5), CharX + 8, 1)
                    If PositionMap = sGrowDoor Then
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sGrow Then
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 2 'down
                    PositionMap = Mid(Map(CharY + 7), CharX + 8, 1) & Mid(Map2(CharY + 7), CharX + 8, 1)
                    If PositionMap = sGrowDoor Then
                        Mid(Map(CharY + 7), CharX + 8, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sGrow Then
                        Mid(Map(CharY + 7), CharX + 8, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 3                    ' Right
                    PositionMap = Mid(Map(CharY + 6), CharX + 9, 1) & Mid(Map2(CharY + 6), CharX + 9, 1)
                    If PositionMap = sGrowDoor Then
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sGrow Then
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 4 ' Left
                    PositionMap = Mid(Map(CharY + 6), CharX + 7, 1) & Mid(Map2(CharY + 6), CharX + 7, 1)
                    If PositionMap = sGrowDoor Then
                        Mid(Map(CharY + 6), CharX + 7, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sGrow Then
                        Mid(Map(CharY + 6), CharX + 7, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
            End Select
        End If
    End Sub
    Public Sub ReadTiles()
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        Dim strMap As String
        nTiles = New Collection
        Dim j As Integer
        Dim k As Integer
        Dim l As Integer
        Dim iCode1 As Integer
        Dim iCode2 As Integer
        Dim MYFILE As String = My.Application.Info.DirectoryPath & "\tiles\tiles2.csv"
        sCode = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        sCode = sCode & "abcdefghijklmnopqrstuvwxyz~!@#$%^&*()_+={},./<>?"
        '     MYFILE = App.Path & "\tiles2.csv"
        srFileReader = System.IO.File.OpenText(MYFILE)
        sInputLine = srFileReader.ReadLine()
        sInputLine = srFileReader.ReadLine()
        j = 1
        iCode1 = 1
        iCode2 = 1
        iTilecnt = 1
        '     iTileCnt = 0
        'Line Input #1, strMap
        Do While (Not sInputLine Is Nothing)
            cTile = New ClsTile
            strMap = sInputLine
            cTile.TileLet = Mid(sCode, iCode1, 1) & Mid(sCode, iCode2, 1)
            j = InStr(1, strMap, ",")
            k = InStr(j + 2, strMap, ",")
            l = InStr(k + 2, strMap, ",") 'Len(strmap)
            cTile.TileName = Mid(strMap, 1, j - 1)
            'If j + 2 = k Then
            '    tiles.OldLet = Mid(strMap, j + 1, 1)
            'Else
            '    tiles.OldLet = Chr(Mid(strMap, j + 1, 3))
            'End If
            cTile.TileType = UCase(Mid(strMap, k + 1, l - k - 1))
            cTile.MyTileCnt = iTilecnt
            cTile.TileAddName = UCase(Mid(strMap, l + 1, Len(strMap) - l))
            '         If tiles.AddName = "NONE" Then tiles.AddName = ""
            If UCase(cTile.TileName) = "GRASS" And UCase(cTile.TileName) = "WALK" Then SGrass = cTile.TileLet
            If UCase(cTile.TileName) = "GRASS" And UCase(cTile.TileType) = "WALK" Then
                sGrass2 = cTile.TileLet ' tiles.letter
                iGrassTile = cTile.MyTileCnt ' tiles.TileCnt
            End If
            If UCase(cTile.TileName) = "WEED" Then
                If UCase(cTile.TileType) = "NONE" Then sWeed = cTile.TileLet
            End If
            If UCase(cTile.TileName) = "BUNNY" Then
                sBunny = cTile.TileLet ' tiles.letter
                iBunnyTile = cTile.MyTileCnt ' tiles.TileCnt
            End If
            If UCase(cTile.TileName) = "SWAMP" Then
                If UCase(cTile.TileType) = "NONE" Then sSwamp = cTile.TileLet
            End If
            If UCase(cTile.TileName) = "GROW" Then
                If UCase(cTile.TileType) = "NONE" Then sGrow = cTile.TileLet
            End If
            If UCase(cTile.TileName) = "WEED" Then
                If UCase(cTile.TileType) = "WEEDDOOR" Then sWeedDoor = cTile.TileLet
            End If
            If UCase(cTile.TileName) = "WALL" Then
                If UCase(cTile.TileType) = "WALLDOOR" Then
                    sWallDoor = cTile.TileLet
                End If
            End If
            If UCase(cTile.TileName) = "WALL" Then
                If UCase(cTile.TileType) = "WALLGRASS" Then sWallGrass = cTile.TileLet
            End If
            If UCase(cTile.TileName) = "JAR" Then
                If UCase(cTile.TileType) = "JAR" Then sJar = cTile.TileLet
            End If
            If UCase(cTile.TileName) = "CHEST" Then sChest = cTile.TileLet
            '         If UCase(tiles.Name) = "JAR" Then
            '             If UCase(tiles.Mytype) = "DOOR" Then sJarDoor = tiles.letter
            '         End If
            If UCase(cTile.TileType) = "TREEDOOR" Then sTreeDoor = cTile.TileLet
            If UCase(cTile.TileType) = "SWAMPDOOR" Then sSwampDoor = cTile.TileLet
            If UCase(cTile.TileType) = "GROWDOOR" Then sGrowDoor = cTile.TileLet
            If UCase(cTile.TileName) = "ROCKDOOR" Then sRockDoor = cTile.TileLet
            If UCase(cTile.TileName) = "STAIRS" Then sStairs = cTile.TileLet
            If UCase(cTile.TileName) = "DOOR" Then sDoor = cTile.TileLet
            If UCase(cTile.TileName) = "NONE" Then sNone = cTile.TileLet
            If UCase(cTile.TileName) = "TREE" Then
                If UCase(cTile.TileType) = "NONE" Then sTree = cTile.TileLet
            End If
            If UCase(cTile.TileName) = "Wall" Then
                If UCase(cTile.TileType) = "NONE" Then sWall = cTile.TileLet
            End If
            If UCase(cTile.TileName) = "ROCK" Then
                If UCase(cTile.TileType) = "NONE" Then sRock = cTile.TileLet
            End If
            nTiles.Add(cTile)
            iCode2 = iCode2 + 1
            iTilecnt = iTilecnt + 1

            If iCode2 > 80 Then
                iCode2 = 1
                iCode1 = iCode1 + 1
            End If
            sInputLine = srFileReader.ReadLine()
        Loop
        srFileReader.Close()
        Debug()
    End Sub
    Public Sub ReadTilesItem()
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        Dim strMap As String
        nTiles = New Collection
        Dim j As Integer
        Dim k As Integer
        Dim l As Integer
        sImaster = ""
        Dim iCode1 As Integer
        Dim iCode2 As Integer
        Dim MYFILE As String = My.Application.Info.DirectoryPath & "\tiles\tiles2.csv"
        sCode = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        sCode = sCode & "abcdefghijklmnopqrstuvwxyz~!@#$%^&*()_+={},./<>?"
        '     MYFILE = App.Path & "\tiles2.csv"
        srFileReader = System.IO.File.OpenText(MYFILE)
        sInputLine = srFileReader.ReadLine()
        sInputLine = srFileReader.ReadLine()
        j = 1
        iCode1 = 1
        iCode2 = 1
        iTilecnt = 1
        '     iTileCnt = 0
        'Line Input #1, strMap
        Do While (Not sInputLine Is Nothing)
            cTile = New ClsTile
            strMap = sInputLine
            cTile.TileLet = Mid(sCode, iCode1, 1) & Mid(sCode, iCode2, 1)

            j = InStr(1, strMap, ",")
            k = InStr(j + 2, strMap, ",")
            l = InStr(k + 2, strMap, ",") 'Len(strmap)
            cTile.TileName = Mid(strMap, 1, j - 1)
            'If j + 2 = k Then
            '    tiles.OldLet = Mid(strMap, j + 1, 1)
            'Else
            '    tiles.OldLet = Chr(Mid(strMap, j + 1, 3))
            'End If
            cTile.TileType = UCase(Mid(strMap, k + 1, l - k - 1))
            cTile.MyTileCnt = iTilecnt
            cTile.TileAddName = UCase(Mid(strMap, l + 1, Len(strMap) - l))
            '         If tiles.AddName = "NONE" Then tiles.AddName = ""


            If cTile.TileType = "ITEM" Then
                nTiles.Add(cTile)
                sImaster = sImaster & cTile.TileLet
            End If
            iCode2 = iCode2 + 1
            iTilecnt = iTilecnt + 1

            If iCode2 > 80 Then
                iCode2 = 1
                iCode1 = iCode1 + 1
            End If
            sInputLine = srFileReader.ReadLine()
        Loop
        srFileReader.Close()
        Debug()
    End Sub
    Public Sub ReadMapFile(ByVal cMapfile As String)
        Dim srFileReader As System.IO.StreamReader
        Dim i As Integer
        Dim j As Integer
        Dim l As Integer
        Dim strMap As String
        Dim MYFILE As String
        Dim Myfilein As String
        Dim bMapSaved As Boolean
        Dim PositionMap As String
        itemHouseFound1 = False
        itemHouseFound2 = False
        itemHouseFound3 = False
        iBunny = 0
        For j = 1 To 90
            iJar(1, j) = 0
            iJar(2, j) = 0
        Next

        '  If iBunny = 0 Then
        '    bBunnyTimer = False
        '  Else
        '    bBunnyTimer = True
        '  End If
        iJarLast = 1
        j = Rnd() * 400
        'jquest = 0
        iJarCnt = 1 + (j Mod 4)
        '
        ' Save Map
        '
        If bLoadMap Then GoTo CreateCave
        If iMapReadIn > 0 And bPlayGame Then
            bMapSaved = False
            If iMapReadIn = 1 Then
                nSaveMap = New Collection
            Else
                For Each SaveMap In nSaveMap
                    If SaveMap.Name = sOldMapFile Then
                        SaveMap.StoreItem = sStoreOld
                        SaveMap.ChestItem = sChestOld
                        For i = 0 To 99
                            If Len(Map(i)) > 5 Then
                                SaveMap.SaveMap(i) = Map(i)
                                SaveMap.SaveMap2(i) = Map2(i)
                                SaveMap.SaveMap3(i) = Map3(i)
                                SaveMap.SaveMap4(i) = Map4(i)
                            End If
                        Next
                        bMapSaved = True
                        'If bDark Then DarkMapFile(TxtMap.Text)
                        Exit For
                    End If
                Next
            End If
            If bMapSaved = False Then
                SaveMap = New ClsSaveMap
                SaveMap.Clear()
                SaveMap.Name = sOldMapFile
                SaveMap.StoreItem = sStoreOld
                SaveMap.ChestItem = sChestOld
                For i = 0 To 99
                    If Len(Map(i)) > 5 Then
                        SaveMap.SaveMap(i) = Map(i)
                        SaveMap.SaveMap2(i) = Map2(i)
                        SaveMap.SaveMap3(i) = Map3(i)
                        SaveMap.SaveMap4(i) = Map4(i)
                    End If
                Next
                nSaveMap.Add(SaveMap)
            End If
            sOldMapFile = cMapfile
            For i = 0 To 99
                Map(i) = ""
                Map2(i) = ""
                Map3(i) = ""
                Map4(i) = ""
            Next
            For Each SaveMap In nSaveMap
                If SaveMap.Name = cMapfile Then
                    sStoreItems = SaveMap.StoreItem
                    For i = 0 To SaveMap.Count - 1
                        Map(i) = SaveMap.SaveMap(i)
                        Map2(i) = SaveMap.SaveMap2(i)
                        Map3(i) = SaveMap.SaveMap3(i)
                        Map4(i) = SaveMap.SaveMap4(i)
                    Next
                    iChestX = Mid(SaveMap.ChestItem, 1, 2)
                    iChestY = Mid(SaveMap.ChestItem, 3, 2)
                    sChestItems = Mid(SaveMap.ChestItem, 5, Len(SaveMap.ChestItem) - 4)
                    Exit Sub
                End If
            Next
        End If

        For i = 0 To 99
            Map(i) = ""
            Map2(i) = ""
            Map3(i) = ""
            Map4(i) = ""
        Next
        sOldMapFile = cMapfile
        iMapReadIn = iMapReadIn + 1
        Myfilein = My.Application.Info.DirectoryPath & cMapfile & "s.txt"
        MYFILE = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & ".1ap"
        i = 0
        srFileReader = System.IO.File.OpenText(MYFILE)
        strMap = srFileReader.ReadLine()
        Do While (Not strMap Is Nothing)
            If Len(strMap) > 5 Then
                Map(i) = Trim(strMap)
                strMap = srFileReader.ReadLine()
                Map2(i) = Trim(strMap)
            End If
            i = i + 1
            strMap = srFileReader.ReadLine()
        Loop
        srFileReader.Close()
        MYFILE = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & ".2ap"
        i = 0
        srFileReader = System.IO.File.OpenText(MYFILE)
        strMap = srFileReader.ReadLine()
        Do While (Not strMap Is Nothing)
            If Len(strMap) > 5 Then
                Map3(i) = Trim(strMap)
                strMap = srFileReader.ReadLine()
                Map4(i) = Trim(strMap)
                strMap = srFileReader.ReadLine()
            End If
            i = i + 1
        Loop
        srFileReader.Close()
        '
        ' Check for chest
        '
        iChest = 0
        If Trim(sChestItems) <> "" Then
            For i = 1 To 99
                If Len(Map(i)) > 5 Then
                    For j = 1 To Len(Map(i))
                        PositionMap = Mid(Map(i), j, 1) & Mid(Map2(i), j, 1)
                        If sChest = PositionMap Then
                            If iChest = 0 Then
                                iChest = 0
                            End If
                            iChest = iChest + 1
                            iChestX = j - 8
                            iChestY = i - 6
                        End If
                    Next
                End If
            Next
            l = 1
            If iChest > 0 Then l = 1 + ((200 * iChest * Rnd()) Mod iChest)
            iChest = 0
            For i = 1 To 99
                If Len(Map(i)) > 5 Then
                    For j = 1 To Len(Map(i))
                        PositionMap = Mid(Map(i), j, 1) & Mid(Map2(i), j, 1)
                        If sChest = PositionMap Then
                            iChest = iChest + 1
                            If l = iChest Then
                                iChestX = j - 8
                                iChestY = i - 6
                            End If
                        End If
                    Next
                End If
            Next
        End If
        '
        ' Create Cave
        '
CreateCave:
        bLoadMap = False
        If bDark = False Then Exit Sub
        For i = 0 To 99
            DarkMap(i) = Map(i)
            DarkMap2(i) = Map2(i)
        Next
        For i = 0 To 99
            Map(i) = ""
            Map2(i) = ""
            If Len(DarkMap(i)) > 0 Then
                For j = 1 To Len(DarkMap(i))
                    Map(i) = Map(i) & Mid(sNone, 1, 1)
                    Map2(i) = Map2(i) & Mid(sNone, 2, 1)
                Next
            End If
        Next

    End Sub
    Public Sub ReadDoorFile(ByVal cMapfile As String)
        Dim srFileReader As System.IO.StreamReader
        Dim cFile As String
        Dim iX As Integer
        Dim iY As Integer
        Dim iToX As Integer
        Dim iToY As Integer
        Dim sTag As String
        Dim cype As String
        Dim bDoor As Boolean
        Dim cMsg As String
        iChestX = 0
        iChestY = 0
        sChestItems = "   "
        bDoor = True
        cype = "DOOR"
        bDark = False
        bStore = False
        iWildLevel = 0
        cFile = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "d.txt"
        nDoors = New Collection
        ' Open cFile For Input As #1 ' Open file for input.
        srFileReader = System.IO.File.OpenText(cFile)
        'Do While Not EOF(1) ' Loop until end of file.
        ' Line Input #1, sTag ' Read data into two variables.
        sTag = srFileReader.ReadLine()
        sTag = srFileReader.ReadLine()
        Do While (Not sTag Is Nothing)
            If Mid(sTag, 1, 1) = "0" Then
                iX = Mid(sTag, 1, 4)
                iY = Mid(sTag, 5, 4)
                iToX = Mid(sTag, 9, 4)
                iToY = Mid(sTag, 13, 4)
                cMsg = Mid(sTag, 17, Len(sTag) - 16)
                doors = New ClsDoor
                If bDoor Then
                    doors.DooriX = iX
                    doors.DooriY = iY
                    doors.DooriToY = iToY
                    doors.DooriToX = iToX
                    doors.Name = cMsg
                    doors.Mytype = cype
                    nDoors.Add(doors)
                Else

                End If
            End If
            sTag = srFileReader.ReadLine()
        Loop
        srFileReader.Close()
        '
        '
        cFile = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "p.txt"
        srFileReader = System.IO.File.OpenText(cFile)
        sTag = srFileReader.ReadLine()
        If sTag = "CAVE" Then bDark = True
        If sTag = "STORE" Then bStore = True
        If Mid(sTag, 1, 4) = "WILD" Then iWildLevel = Mid(sTag, 5, 4)
        sTag = srFileReader.ReadLine()
        sStoreItems = ""
        If bStore Then sStoreItems = sTag
        sChestItems = ""
        sTag = srFileReader.ReadLine()
        If UCase(Mid(sTag, 1, 5)) = "CHEST" Then sChestItems = Trim(Mid(sTag, 7, Len(sTag) - 6))
        sTag = srFileReader.ReadLine()
        Do While (Not sTag Is Nothing)
            If Len(sTag) > 16 Then
                iToY = Mid(sTag, 13, 4)
                cMsg = Mid(sTag, 17, Len(sTag) - 16)
                doors = New ClsDoor
                iX = Mid(sTag, 1, 4)
                iY = Mid(sTag, 5, 4)
                doors.DooriX = iX
                doors.DooriY = iY
                doors.DooriToY = iY
                doors.DooriToX = iX
                doors.Name = cMsg
                doors.Mytype = "TALK"
                nDoors.Add(doors)
            End If
            sTag = srFileReader.ReadLine()
        Loop
        srFileReader.Close()
        '
        ' Fix
        '
        cFile = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "f.txt"
        srFileReader = System.IO.File.OpenText(cFile)
        sTag = srFileReader.ReadLine()
        sTag = srFileReader.ReadLine()
        Do While (Not sTag Is Nothing)
            'iToY = Mid(sTag, 13, 4)
            cMsg = Mid(sTag, 9, Len(sTag) - 8)
            doors = New ClsDoor
            iX = Mid(sTag, 1, 4)

            iY = Mid(sTag, 5, 4)
            doors.DooriX = iX
            doors.DooriY = iY
            doors.DooriToY = 0
            doors.DooriToX = 0
            doors.Name = cMsg
            doors.Mytype = "FIX"
            nDoors.Add(doors)
            sTag = srFileReader.ReadLine()
        Loop
        srFileReader.Close()
    End Sub
    Public Sub ReadSpeech(ByVal cMapfile As String)
        Dim srFileReader As System.IO.StreamReader
        Dim Tag As String
        Dim cFile As String
        Dim cMsg As String
        Dim i As Integer
        Dim iCnt As Integer
        Dim j As Integer
        Dim l As Integer
        Dim bSave As Boolean
        cFile = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & "s.txt"
        nSpeech = New Collection
        speech = New ClsSpeech
        speech.Clear()
        iCnt = 0
        ' Open cFile For Input As #1 ' Open file for input.
        i = 0
        'RichTextBox1.Text = ""
        srFileReader = System.IO.File.OpenText(cFile)
        Tag = srFileReader.ReadLine()
        Do While (Not Tag Is Nothing)
            Tag = Trim(Tag)
            If Mid(Tag, 1, 1) = "<" Then
                If bSave Then
                    nSpeech.Add(speech)
                End If
                speech = New ClsSpeech
                iCnt = 0
                speech.Clear()
                speech.RNumber = Mid(Tag, 2, 4)
                speech.MyType = "SPEECH"
                If UCase(Mid(Tag, 7, 1)) = "P" Then speech.MyType = "PENCE"
                If UCase(Mid(Tag, 7, 1)) = "T" Then speech.MyType = "THOUGHT"
                speech.StartQuest = "0 "
                speech.EndQuest = "0"
                speech.BeforeQuest = "0 "
                speech.QuestYes = "0"
                speech.QuestNo = "0"
                speech.Need = ""
                speech.NeedQty = 0
                speech.Give = ""
                speech.FixX = "0"
                speech.FixY = "0"
                speech.FixMap = "G"
                speech.BombQty = 0
                speech.GiveQty = 1
                speech.SayOnce = "N"
                speech.TakeAny = "N"
                speech.Status = ""
                speech.Badge = ""
                speech.PokeCure = "N"
                speech.PokeLevel = ""
                speech.Pokemon = ""
                bSave = True
            Else
                If InStr(1, Tag, ":") > 0 Then
                    j = InStr(1, Tag, ":")
                    speech.Name = Trim(Mid(Tag, 1, j))
                    speech.Talk = Mid(Tag, j + 1, Len(Tag) - j)
                    j = InStr(1, Tag, "#")
                    If j > 0 Then speech.Talk = Replace(speech.Talk, "#", strChrName)
                ElseIf InStr(1, Tag, "=") Then
                    ' j = Len(ClsSpeech.Name)
                    'Tag = Replace(Tag, "@", Mid(ClsSpeech.Name, 1, j - 1))
                    speech.Question(iCnt) = Tag
                    iCnt = iCnt + 1
                ElseIf UCase(Mid(Tag, 1, 7)) = "SQUEST!" Then
                    speech.StartQuest = Right(Tag, Len(Tag) - 7)
                    ' jquest = Val(ClsSpeech.DoQuest)
                ElseIf UCase(Mid(Tag, 1, 7)) = "EQUEST!" Then
                    speech.EndQuest = Right(Tag, Len(Tag) - 7)
                ElseIf UCase(Mid(Tag, 1, 7)) = "BQUEST!" Then
                    speech.BeforeQuest = Right(Tag, Len(Tag) - 7)
                ElseIf UCase(Mid(Tag, 1, 8)) = "SAYONCE!" Then
                    speech.SayOnce = "Y"
                ElseIf UCase(Mid(Tag, 1, 8)) = "TAKEANY!" Then
                    speech.TakeAny = "Y"
                ElseIf UCase(Mid(Tag, 1, 8)) = "NEEDQTY!" Then
                    speech.NeedQty = Val(Right(Tag, Len(Tag) - 8))
                ElseIf UCase(Mid(Tag, 1, 5)) = "NEED!" Then
                    speech.Need = UCase(Right(Tag, Len(Tag) - 5))
                    If speech.NeedQty = 0 Then speech.NeedQty = 1
                ElseIf UCase(Mid(Tag, 1, 7)) = "QUESTN!" Then
                    speech.QuestName = UCase(Right(Tag, Len(Tag) - 7))
                ElseIf UCase(Mid(Tag, 1, 5)) = "GIVE!" Then
                    speech.Give = UCase(Right(Tag, Len(Tag) - 5))
                ElseIf UCase(Mid(Tag, 1, 8)) = "POKEMON!" Then
                    speech.Pokemon = UCase(Right(Tag, Len(Tag) - 8))
                    l = 1
                ElseIf UCase(Mid(Tag, 1, 10)) = "POKELEVEL!" Then
                    speech.PokeLevel = UCase(Right(Tag, Len(Tag) - 10))
                ElseIf UCase(Mid(Tag, 1, 9)) = "POKECURE!" Then
                    speech.PokeCure = "Y"
                ElseIf UCase(Mid(Tag, 1, 6)) = "BADGE!" Then
                    cMsg = UCase(Right(Tag, Len(Tag) - 6))
                    speech.Badge = Mid(cMsg, 6, Len(cMsg) - 5)
                ElseIf UCase(Mid(Tag, 1, 8)) = "GIVEQTY!" Then
                    speech.GiveQty = Val(Right(Tag, Len(Tag) - 8))
                ElseIf UCase(Mid(Tag, 1, 9)) = "QUESTYES!" Then
                    speech.QuestYes = Val(Right(Tag, Len(Tag) - 9))
                ElseIf UCase(Mid(Tag, 1, 8)) = "QUESTNO!" Then
                    speech.QuestNo = Val(Right(Tag, Len(Tag) - 8))
                ElseIf UCase(Mid(Tag, 1, 8)) = "BOMBQTY!" Then
                    speech.BombQty = Val(Right(Tag, Len(Tag) - 8))
                ElseIf UCase(Mid(Tag, 1, 5)) = "FIXX!" Then
                    j = Val(Right(Tag, Len(Tag) - 5)) + 3
                    speech.FixX = j
                ElseIf UCase(Mid(Tag, 1, 5)) = "FIXY!" Then
                    j = Val(Right(Tag, Len(Tag) - 5)) + 3
                    speech.FixY = j
                ElseIf UCase(Mid(Tag, 1, 7)) = "FIXMAP!" Then
                    speech.FixMap = UCase(Right(Tag, Len(Tag) - 7))
                End If
            End If
            Tag = srFileReader.ReadLine()
        Loop
        srFileReader.Close()
        nSpeech.Add(speech)
    End Sub
    Public Sub Jar(ByVal iX As Integer, ByVal iY As Integer)
        Dim j As Integer
        Dim RandomNumber As Integer
        Form1.LblJar.Visible = True
        Form1.LblJar.Text = "The Jar is Empty" & iJarCnt
        RandomNumber = Int(Rnd() * 3.999)
        '    bRun = False
        '   ' FrmMake.Frame2.Visible = False
        If iJarCnt < 0 Then Exit Sub

        For j = 1 To iJarLast
            If iJar(1, j) = iX And iJar(2, j) = iY Then
                Exit Sub
            End If
        Next j
        iJar(1, iJarLast) = iX
        iJar(2, iJarLast) = iY
        iJarLast = iJarLast + 1
        If RandomNumber = 1 Then
            If itemHouseFound1 = False Then
                CharFacing = 5
                Item = 1
                Wood = Wood + 1
                Form1.LblJar.Text = "You found some wood"
                itemHouseFound1 = True
                iJarCnt = iJarCnt - 1
                CharJar = 122
            Else
                Form1.LblJar.Text = "Jar Empty"
            End If
        End If
        '
        '
        If RandomNumber = 2 Then
            If itemHouseFound2 = False Then
                CharFacing = 5
                Item = 2
                Coin = Coin + 1
                Form1.LblJar.Text = "You found a coin"
                itemHouseFound2 = True
                iJarCnt = iJarCnt - 1
                CharJar = 125
            Else
                Form1.LblJar.Text = "Jar Empty"
            End If
        End If
        '
        '
        '
        If RandomNumber = 3 Then
            If itemHouseFound3 = False Then
                CharFacing = 5
                Item = 3
                Magic = Magic + 10
                Form1.LblJar.Text = "You found some magic"
                itemHouseFound3 = True
                iJarCnt = iJarCnt - 1
                CharJar = 123
            Else
                Form1.LblJar.Text = "Jar Empty"
            End If
        End If
        'DrawIt
    End Sub
    Public Sub BombWall()
        'Dim MFixX As Integer
        Dim PositionMap As String
        Dim PositionMap2 As String
        ' Dim strMap As String
        iDamage = 0
        If Bomb > 0 Then
            Bomb = Bomb - 1
            PositionMap = Mid(Map(iNewy + 6), iNewx + 8, 1) & Mid(Map2(iNewy + 6), iNewx + 8, 1)
            If PositionMap = sWallDoor Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 2, 1)
                Exit Sub
            ElseIf PositionMap = sWallGrass Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 2, 1)
                Exit Sub
                'ElseIf PositionMap = Chr(21) Then
                '    MFixX = CharX + 3
                '    strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "#" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
                '    Map(CharY + 2) = strMap
                'ElseIf PositionMap = Chr(22) Then
                '    MFixX = CharX + 3
                '    strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "M" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
                '    Map(CharY + 2) = strMap
            ElseIf PositionMap = sWall Then
                iDamage = 1 + Rnd() * 6
                Exit Sub
            End If
            '    If PositionMap = "p" Then
            '      MFixX = CharX + 3
            '      strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "?" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
            '      Map(CharY + 2) = strMap
            '    End If
            Select Case CharFacing
                Case 1 'up
                    PositionMap = Mid(Map(CharY + 5), CharX + 8, 1) & Mid(Map2(CharY + 5), CharX + 8, 1)
                    If PositionMap = sWallDoor Then
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(sStairs, 2, 1)
                    ElseIf PositionMap = sWallGrass Then
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(SGrass, 2, 1)
                        'ElseIf PositionMap = Chr(21) Then
                        '    MFixX = CharX + 3
                        '    strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "#" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
                        '    Map(CharY + 2) = strMap
                        'ElseIf PositionMap = Chr(22) Then
                        '    MFixX = CharX + 3
                        '    strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "M" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
                        '    Map(CharY + 2) = strMap
                    ElseIf PositionMap = sWall Then
                        iDamage = 1 + Rnd() * 6
                    End If
                Case 2 'down
                    PositionMap = Mid(Map(CharY + 7), CharX + 8, 1) & Mid(Map2(CharY + 7), CharX + 8, 1)
                    If PositionMap = sWallDoor Then
                        Mid(Map(CharY + 7), CharX + 8, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(sStairs, 2, 1)
                    ElseIf PositionMap = sWallGrass Then
                        Mid(Map(CharY + 7), CharX + 8, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(SGrass, 2, 1)
                        'ElseIf PositionMap = Chr(21) Then
                        '    MFixX = CharX + 3
                        '    strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "#" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
                        '    Map(CharY + 2) = strMap
                        'ElseIf PositionMap = Chr(22) Then
                        '    MFixX = CharX + 3
                        '    strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "M" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
                        '    Map(CharY + 2) = strMap
                    ElseIf PositionMap = sWall Then
                        iDamage = 1 + Rnd() * 6
                    End If
                Case 3                    ' Right
                    PositionMap = Mid(Map(CharY + 6), CharX + 9, 1) & Mid(Map2(CharY + 6), CharX + 9, 1)
                    If PositionMap = sWallDoor Then
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(sStairs, 2, 1)
                    ElseIf PositionMap = sWallGrass Then
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(SGrass, 2, 1)
                        'ElseIf PositionMap = Chr(21) Then
                        '    MFixX = CharX + 3
                        '    strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "#" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
                        '    Map(CharY + 2) = strMap
                        'ElseIf PositionMap = Chr(22) Then
                        '    MFixX = CharX + 3
                        '    strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "M" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
                        '    Map(CharY + 2) = strMap
                    ElseIf PositionMap = sWall Then
                        iDamage = 1 + Rnd() * 6
                    End If
                Case 4 ' Left
                    PositionMap = Mid(Map(CharY + 6), CharX + 7, 1) & Mid(Map2(CharY + 6), CharX + 7, 1)
                    If PositionMap = sWallDoor Then
                        Mid(Map(CharY + 6), CharX + 7, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(sStairs, 2, 1)
                    ElseIf PositionMap = sWallGrass Then
                        Mid(Map(CharY + 6), CharX + 7, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(SGrass, 2, 1)
                        'ElseIf PositionMap = Chr(21) Then
                        '    MFixX = CharX + 3
                        '    strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "#" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
                        '    Map(CharY + 2) = strMap
                        'ElseIf PositionMap = Chr(22) Then
                        '    MFixX = CharX + 3
                        '    strMap = Mid(Map(CharY + 2), 1, MFixX - 1) & "M" & Mid(Map(CharY + 2), MFixX + 1, Len(Map(MFixY)) - MFixX)
                        '    Map(CharY + 2) = strMap
                    ElseIf PositionMap = sWall Then
                        iDamage = 1 + Rnd() * 6
                    End If
            End Select

        End If
        '
        '
        '    

    End Sub
    Public Sub Make_Spell_Light()
        Dim PositionMap As String
        Dim PositionMap2 As String
        Dim iTot As Integer
        iTot = Magic + SAVE_Candle
        If iTot > 1 Then
            If CharFacing = 1 Then 'Up
                ' PositionMap = Mid(Map(CharY + 2), CharX + 3, 1) & Mid(Map2(CharY + 2), CharX + 3, 1)
                PositionMap = Mid(Map(CharY + 5), CharX + 8, 1) & Mid(Map2(CharY + 5), CharX + 8, 1)
                If PositionMap = sNone Then
                    Mid(Map(CharY + 5), CharX + 8, 1) = Mid(DarkMap(CharY + 5), CharX + 8, 1)
                    Mid(Map(CharY + 4), CharX + 8, 1) = Mid(DarkMap(CharY + 4), CharX + 8, 1)
                    Mid(Map(CharY + 6), CharX + 9, 1) = Mid(DarkMap(CharY + 6), CharX + 9, 1)
                    Mid(Map(CharY + 6), CharX + 7, 1) = Mid(DarkMap(CharY + 6), CharX + 7, 1)
                    Mid(Map(CharY + 5), CharX + 9, 1) = Mid(DarkMap(CharY + 5), CharX + 9, 1)
                    Mid(Map(CharY + 5), CharX + 7, 1) = Mid(DarkMap(CharY + 5), CharX + 7, 1)
                    Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(DarkMap2(CharY + 5), CharX + 8, 1)
                    Mid(Map2(CharY + 4), CharX + 8, 1) = Mid(DarkMap2(CharY + 4), CharX + 8, 1)
                    Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(DarkMap2(CharY + 6), CharX + 9, 1)
                    Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(DarkMap2(CharY + 6), CharX + 7, 1)
                    Mid(Map2(CharY + 5), CharX + 9, 1) = Mid(DarkMap2(CharY + 5), CharX + 9, 1)
                    Mid(Map2(CharY + 5), CharX + 7, 1) = Mid(DarkMap2(CharY + 5), CharX + 7, 1)
                    If SAVE_Candle > 0 Then
                        SAVE_Candle = SAVE_Candle - 2
                        'If SAVE_Candle = 0 Then strInventory = Replace(strInventory, "$", "")
                    Else
                        Magic = Magic - 2
                    End If
                End If
            End If

            If CharFacing = 2 Then 'Down
                ' PositionMap = Mid(Map(CharY + 4), CharX + 3, 1) & Mid(Map2(CharY + 4), CharX + 3, 1)
                PositionMap = Mid(Map(CharY + 7), CharX + 8, 1) & Mid(Map2(CharY + 7), CharX + 8, 1)
                If PositionMap = sNone Then
                    Mid(Map(CharY + 7), CharX + 8, 1) = Mid(DarkMap(CharY + 7), CharX + 8, 1)
                    Mid(Map(CharY + 8), CharX + 8, 1) = Mid(DarkMap(CharY + 8), CharX + 8, 1)
                    Mid(Map(CharY + 6), CharX + 9, 1) = Mid(DarkMap(CharY + 6), CharX + 9, 1)
                    Mid(Map(CharY + 6), CharX + 7, 1) = Mid(DarkMap(CharY + 6), CharX + 7, 1)
                    Mid(Map(CharY + 7), CharX + 9, 1) = Mid(DarkMap(CharY + 7), CharX + 9, 1)
                    Mid(Map(CharY + 7), CharX + 7, 1) = Mid(DarkMap(CharY + 7), CharX + 7, 1)
                    Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(DarkMap2(CharY + 7), CharX + 8, 1)
                    Mid(Map2(CharY + 8), CharX + 8, 1) = Mid(DarkMap2(CharY + 8), CharX + 8, 1)
                    Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(DarkMap2(CharY + 6), CharX + 9, 1)
                    Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(DarkMap2(CharY + 6), CharX + 7, 1)
                    Mid(Map2(CharY + 7), CharX + 9, 1) = Mid(DarkMap2(CharY + 7), CharX + 9, 1)
                    Mid(Map2(CharY + 7), CharX + 7, 1) = Mid(DarkMap2(CharY + 7), CharX + 7, 1)
                    PositionMap2 = Mid(Map(27), 35, 1) & Mid(Map2(27), 35, 1)
                    If SAVE_Candle > 0 Then
                        SAVE_Candle = SAVE_Candle - 2
                        'If SAVE_Candle = 0 Then strInventory = Replace(strInventory, "$", "")
                    Else
                        Magic = Magic - 2
                    End If
                End If
            End If

            If CharFacing = 3 Then 'Right
                'PositionMap = Mid(Map(CharY + 3), CharX + 4, 1) & Mid(Map2(CharY + 3), CharX + 4, 1)
                PositionMap = Mid(Map(CharY + 6), CharX + 9, 1) & Mid(Map2(CharY + 6), CharX + 9, 1)
                If PositionMap = sNone Then
                    Mid(Map(CharY + 5), CharX + 8, 1) = Mid(DarkMap(CharY + 5), CharX + 8, 1)
                    Mid(Map(CharY + 7), CharX + 8, 1) = Mid(DarkMap(CharY + 7), CharX + 8, 1)
                    Mid(Map(CharY + 6), CharX + 9, 1) = Mid(DarkMap(CharY + 6), CharX + 9, 1)
                    Mid(Map(CharY + 6), CharX + 10, 1) = Mid(DarkMap(CharY + 6), CharX + 10, 1)
                    Mid(Map(CharY + 5), CharX + 9, 1) = Mid(DarkMap(CharY + 5), CharX + 9, 1)
                    Mid(Map(CharY + 7), CharX + 9, 1) = Mid(DarkMap(CharY + 7), CharX + 9, 1)
                    Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(DarkMap2(CharY + 5), CharX + 8, 1)
                    Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(DarkMap2(CharY + 7), CharX + 8, 1)
                    Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(DarkMap2(CharY + 6), CharX + 9, 1)
                    Mid(Map2(CharY + 6), CharX + 10, 1) = Mid(DarkMap2(CharY + 6), CharX + 10, 1)
                    Mid(Map2(CharY + 5), CharX + 9, 1) = Mid(DarkMap2(CharY + 5), CharX + 9, 1)
                    Mid(Map2(CharY + 7), CharX + 9, 1) = Mid(DarkMap2(CharY + 7), CharX + 9, 1)
                    If SAVE_Candle > 0 Then
                        SAVE_Candle = SAVE_Candle - 2
                        ' If SAVE_Candle = 0 Then strInventory = Replace(strInventory, "$", "")
                    Else
                        Magic = Magic - 2
                    End If
                End If
            End If

            If CharFacing = 4 Then 'Left
                ' PositionMap = Mid(Map(CharY + 3), CharX + 2, 1) & Mid(Map2(CharY + 3), CharX + 2, 1)
                PositionMap = Mid(Map(CharY + 6), CharX + 7, 1) & Mid(Map2(CharY + 6), CharX + 7, 1)
                If PositionMap = sNone Then
                    Mid(Map(CharY + 5), CharX + 8, 1) = Mid(DarkMap(CharY + 5), CharX + 8, 1)
                    Mid(Map(CharY + 7), CharX + 8, 1) = Mid(DarkMap(CharY + 7), CharX + 8, 1)
                    Mid(Map(CharY + 6), CharX + 7, 1) = Mid(DarkMap(CharY + 6), CharX + 7, 1)
                    Mid(Map(CharY + 6), CharX + 6, 1) = Mid(DarkMap(CharY + 6), CharX + 6, 1)
                    Mid(Map(CharY + 5), CharX + 7, 1) = Mid(DarkMap(CharY + 5), CharX + 7, 1)
                    Mid(Map(CharY + 7), CharX + 7, 1) = Mid(DarkMap(CharY + 7), CharX + 7, 1)
                    Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(DarkMap2(CharY + 5), CharX + 8, 1)
                    Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(DarkMap2(CharY + 7), CharX + 8, 1)
                    Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(DarkMap2(CharY + 6), CharX + 7, 1)
                    Mid(Map2(CharY + 6), CharX + 6, 1) = Mid(DarkMap2(CharY + 6), CharX + 6, 1)
                    Mid(Map2(CharY + 5), CharX + 7, 1) = Mid(DarkMap2(CharY + 5), CharX + 7, 1)
                    Mid(Map2(CharY + 7), CharX + 7, 1) = Mid(DarkMap2(CharY + 7), CharX + 7, 1)
                    If SAVE_Candle > 0 Then
                        SAVE_Candle = SAVE_Candle - 2
                        ' If SAVE_Candle = 0 Then strInventory = Replace(strInventory, "$", "")
                    Else
                        Magic = Magic - 2
                    End If
                End If
            End If
        Else
            'If strMyForm = "FrmMake" Then
            '    FrmMake.TxtSpeech.Visible = True
            '    FrmMake.Frame2.Visible = False
            '    FrmMake.TxtSpeech.Text = "You need more magic to make your spells."
            'Else
            '    frmGame.TxtSpeech.Visible = True
            '    frmGame.TxtSpeech.Text = "You have no magic, you need to get some more to make your spells."
            'End If
        End If

    End Sub
    Public Sub Make_Spell_Axe()
        Dim PositionMap As String
        If Magic > 4 Then
            PositionMap = Mid(Map(iNewy + 6), iNewx + 8, 1) & Mid(Map2(iNewy + 6), iNewx + 8, 1)
            If PositionMap = sTree Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 2, 1)
                Magic = Magic - 4
                Exit Sub
            ElseIf PositionMap = sTreeDoor Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 2, 1)
                Magic = Magic - 4
                Exit Sub
            End If
            Select Case CharFacing
                Case 1 'up
                    PositionMap = Mid(Map(CharY + 5), CharX + 8, 1) & Mid(Map2(CharY + 5), CharX + 8, 1)
                    If PositionMap = sTreeDoor Then
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sTree Then
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 2 'down
                    PositionMap = Mid(Map(CharY + 7), CharX + 8, 1) & Mid(Map2(CharY + 7), CharX + 8, 1)
                    If PositionMap = sTreeDoor Then
                        Mid(Map(CharY + 7), CharX + 8, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sTree Then
                        Mid(Map(CharY + 7), CharX + 8, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 3                    ' Right
                    PositionMap = Mid(Map(CharY + 6), CharX + 9, 1) & Mid(Map2(CharY + 6), CharX + 9, 1)
                    If PositionMap = sTreeDoor Then
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sTree Then
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 4 ' Left
                    PositionMap = Mid(Map(CharY + 6), CharX + 7, 1) & Mid(Map2(CharY + 6), CharX + 7, 1)
                    If PositionMap = sTreeDoor Then
                        Mid(Map(CharY + 6), CharX + 7, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sTree Then
                        Mid(Map(CharY + 6), CharX + 7, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
            End Select
        End If
    End Sub
    Public Sub Make_FillSwamp()
        Dim PositionMap As String
        If Magic > 4 Then
            PositionMap = Mid(Map(iNewy + 6), iNewx + 8, 1) & Mid(Map2(iNewy + 6), iNewx + 8, 1)
            If PositionMap = sSwamp Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 2, 1)
                Magic = Magic - 4
                Exit Sub
            ElseIf PositionMap = sSwampDoor Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 2, 1)
                Magic = Magic - 4
                Exit Sub
            End If
            Select Case CharFacing
                Case 1 'up
                    PositionMap = Mid(Map(CharY + 5), CharX + 8, 1) & Mid(Map2(CharY + 5), CharX + 8, 1)
                    If PositionMap = sSwampDoor Then
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sSwamp Then
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 2 'down
                    PositionMap = Mid(Map(CharY + 7), CharX + 8, 1) & Mid(Map2(CharY + 7), CharX + 8, 1)
                    If PositionMap = sSwampDoor Then
                        Mid(Map(CharY + 7), CharX + 8, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sSwamp Then
                        Mid(Map(CharY + 7), CharX + 8, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 3                    ' Right
                    PositionMap = Mid(Map(CharY + 6), CharX + 9, 1) & Mid(Map2(CharY + 6), CharX + 9, 1)
                    If PositionMap = sSwampDoor Then
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sSwamp Then
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 4 ' Left
                    PositionMap = Mid(Map(CharY + 6), CharX + 7, 1) & Mid(Map2(CharY + 6), CharX + 7, 1)
                    If PositionMap = sSwampDoor Then
                        Mid(Map(CharY + 6), CharX + 7, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sSwamp Then
                        Mid(Map(CharY + 6), CharX + 7, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
            End Select
        End If
    End Sub
    Public Sub Make_Spell_Destroy()
        Dim PositionMap As String
        If Magic > 4 Then
            PositionMap = Mid(Map(iNewy + 6), iNewx + 8, 1) & Mid(Map2(iNewy + 6), iNewx + 8, 1)
            If PositionMap = sRock Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 2, 1)
                Magic = Magic - 4
                Exit Sub
            ElseIf PositionMap = sRockDoor Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 2, 1)
                Magic = Magic - 4
                Exit Sub
            End If
            Select Case CharFacing
                Case 1 'up
                    PositionMap = Mid(Map(CharY + 5), CharX + 8, 1) & Mid(Map2(CharY + 5), CharX + 8, 1)
                    If PositionMap = sRockDoor Then
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sRock Then
                        Mid(Map(CharY + 5), CharX + 8, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 2 'down
                    PositionMap = Mid(Map(CharY + 7), CharX + 8, 1) & Mid(Map2(CharY + 7), CharX + 8, 1)
                    If PositionMap = sRockDoor Then
                        Mid(Map(CharY + 7), CharX + 8, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sRock Then
                        Mid(Map(CharY + 7), CharX + 8, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 3                    ' Right
                    PositionMap = Mid(Map(CharY + 6), CharX + 9, 1) & Mid(Map2(CharY + 6), CharX + 9, 1)
                    If PositionMap = sRockDoor Then
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sRock Then
                        Mid(Map(CharY + 6), CharX + 9, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
                Case 4 ' Left
                    PositionMap = Mid(Map(CharY + 6), CharX + 7, 1) & Mid(Map2(CharY + 6), CharX + 7, 1)
                    If PositionMap = sRockDoor Then
                        Mid(Map(CharY + 6), CharX + 7, 1) = Mid(sStairs, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(sStairs, 2, 1)
                        Magic = Magic - 4
                    ElseIf PositionMap = sRock Then
                        Mid(Map(CharY + 6), CharX + 7, 1) = Mid(SGrass, 1, 1)
                        Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(SGrass, 2, 1)
                        Magic = Magic - 4
                    End If
            End Select
        End If
    End Sub
    Public Sub Make_Spell_Cut()
        Dim PositionMap As String
        If Magic > 4 Then
            PositionMap = Mid(Map(iNewy + 6), iNewx + 8, 1) & Mid(Map2(iNewy + 6), iNewx + 8, 1)
            If PositionMap = sWeed Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(SGrass, 2, 1)
                Magic = Magic - 4
                Exit Sub
            ElseIf PositionMap = sWeedDoor Then
                Mid(Map(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 1, 1)
                Mid(Map2(iNewy + 6), iNewx + 8, 1) = Mid(sStairs, 2, 1)
                Magic = Magic - 4
                Exit Sub
            End If
        End If
        Select Case CharFacing
            Case 1 'up
                PositionMap = Mid(Map(CharY + 5), CharX + 8, 1) & Mid(Map2(CharY + 5), CharX + 8, 1)
                If PositionMap = sWeedDoor Then
                    Mid(Map(CharY + 5), CharX + 8, 1) = Mid(sStairs, 1, 1)
                    Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(sStairs, 2, 1)
                    Magic = Magic - 4
                ElseIf PositionMap = sWeed Then
                    Mid(Map(CharY + 5), CharX + 8, 1) = Mid(SGrass, 1, 1)
                    Mid(Map2(CharY + 5), CharX + 8, 1) = Mid(SGrass, 2, 1)
                    Magic = Magic - 4
                End If
            Case 2 'down
                PositionMap = Mid(Map(CharY + 7), CharX + 8, 1) & Mid(Map2(CharY + 7), CharX + 8, 1)
                If PositionMap = sWeedDoor Then
                    Mid(Map(CharY + 7), CharX + 8, 1) = Mid(sStairs, 1, 1)
                    Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(sStairs, 2, 1)
                    Magic = Magic - 4
                ElseIf PositionMap = sWeed Then
                    Mid(Map(CharY + 7), CharX + 8, 1) = Mid(SGrass, 1, 1)
                    Mid(Map2(CharY + 7), CharX + 8, 1) = Mid(SGrass, 2, 1)
                    Magic = Magic - 4
                End If
            Case 3                    ' Right
                PositionMap = Mid(Map(CharY + 6), CharX + 9, 1) & Mid(Map2(CharY + 6), CharX + 9, 1)
                If PositionMap = sWeedDoor Then
                    Mid(Map(CharY + 6), CharX + 9, 1) = Mid(sStairs, 1, 1)
                    Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(sStairs, 2, 1)
                    Magic = Magic - 4
                ElseIf PositionMap = sWeed Then
                    Mid(Map(CharY + 6), CharX + 9, 1) = Mid(SGrass, 1, 1)
                    Mid(Map2(CharY + 6), CharX + 9, 1) = Mid(SGrass, 2, 1)
                    Magic = Magic - 4
                End If
            Case 4 ' Left
                PositionMap = Mid(Map(CharY + 6), CharX + 7, 1) & Mid(Map2(CharY + 6), CharX + 7, 1)
                If PositionMap = sWeedDoor Then
                    Mid(Map(CharY + 6), CharX + 7, 1) = Mid(sStairs, 1, 1)
                    Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(sStairs, 2, 1)
                    Magic = Magic - 4
                ElseIf PositionMap = sWeed Then
                    Mid(Map(CharY + 6), CharX + 7, 1) = Mid(SGrass, 1, 1)
                    Mid(Map2(CharY + 6), CharX + 7, 1) = Mid(SGrass, 2, 1)
                    Magic = Magic - 4
                End If
        End Select
    End Sub
    Public Sub SaveGame()
        Dim bMapSaved As Boolean
        Dim sFileName As String
        Dim sOut As String
        Dim sOut2 As String
        Dim i As Integer

        'SAVE_MapLoaded = MapLoaded
        Dim value As String = My.Application.Info.DirectoryPath
        sFileName = value & "\" & strChrName & ".qst"
        Dim j As Integer
        Dim srFileWrite As New System.IO.StreamWriter(sFileName)
        srFileWrite.WriteLine(cMapFile)
        '
        If Magic < 0 Then Magic = 0
        sOut = Format(Pokeballs, "000") & Format(iBunnyCaught, "000") & Format(SAVE_Life, "000") & Format(SAVE_Candle, "000") & Format(Ticket, "000")
        srFileWrite.WriteLine(sOut)
        sOut = Format(Wood, "000") & Format(Magic, "000") & Format(Toast, "000") & Format(Coin, "000") & Format(Bomb, "000")
        srFileWrite.WriteLine(sOut)
        sOut = Format(CharX, "000") & Format(CharY, "000") & Format(CharFacing, "000")
        srFileWrite.WriteLine(sOut)
        '
        'srFileWrite.WriteLine(Pokeballs, SAVE_Life, iBunnyCaught, SAVE_MapLoaded, CharX, CharY, CharFacing, Wood, Coin, SpellAxe, SAVE_Candle)
        sOut2 = Mid(SpellAxe, 1, 1) & Mid(SpellCut, 1, 1) & Mid(SpellDestroy, 1, 1) & Mid(SpellFill, 1, 1) & Mid(SpellGrow, 1, 1) & Mid(SpellLight, 1, 1)
        srFileWrite.WriteLine(sOut2)
        srFileWrite.WriteLine(sInventory)
        For i = 1 To 90
            srFileWrite.WriteLine(Mquest(i))
            srFileWrite.WriteLine(MquestName(i))
            srFileWrite.WriteLine(sBadge(i))
        Next
        sOut = sBadge(1)
        bMapSaved = False
        If iMapReadIn = 1 Then
            nSaveMap = New Collection
        Else
            For Each SaveMap In nSaveMap
                If SaveMap.Name = sOldMapFile Then
                    SaveMap.StoreItem = sStoreOld
                    SaveMap.ChestItem = sChestOld
                    For i = 0 To 99
                        If Len(Map(i)) > 5 Then
                            SaveMap.SaveMap(i) = Map(i)
                            SaveMap.SaveMap2(i) = Map2(i)
                            SaveMap.SaveMap3(i) = Map3(i)
                            SaveMap.SaveMap4(i) = Map4(i)
                        End If
                    Next
                    bMapSaved = True
                    Exit For
                End If
            Next
        End If
        If bMapSaved = False Then
            SaveMap = New ClsSaveMap
            SaveMap.Clear()
            SaveMap.Name = sOldMapFile
            SaveMap.StoreItem = sStoreOld
            SaveMap.ChestItem = sChestOld
            For i = 0 To 99
                If Len(Map(i)) > 5 Then
                    SaveMap.SaveMap(i) = Map(i)
                    SaveMap.SaveMap2(i) = Map2(i)
                    SaveMap.SaveMap3(i) = Map3(i)
                    SaveMap.SaveMap4(i) = Map4(i)
                End If
            Next
            nSaveMap.Add(SaveMap)
        End If
        '
        For Each poko In nPoko
            sOut = poko.Name ', poko.Status, poko.Value, poko.Wins
            srFileWrite.WriteLine(sOut)
            sOut = poko.Level ', poko.Name, poko.Status, poko.Value, poko.Wins
            srFileWrite.WriteLine(sOut)
            sOut = poko.Status ', poko.Value, poko.Wins
            srFileWrite.WriteLine(sOut)
            sOut = poko.Value ', poko.Wins
            srFileWrite.WriteLine(sOut)
            sOut = poko.Wins
            srFileWrite.WriteLine(sOut)
        Next
        srFileWrite.WriteLine("END")
        sOut = Format(iMapReadIn, "000")
        srFileWrite.WriteLine(sOut)
        For Each SaveMap In nSaveMap
            srFileWrite.WriteLine(SaveMap.ChestItem)
            srFileWrite.WriteLine(SaveMap.StoreItem)
            srFileWrite.WriteLine(SaveMap.Name)
            sOut = Format(SaveMap.Count - 1, "000")
            srFileWrite.WriteLine(sOut)
            For i = 1 To SaveMap.Count - 1
                srFileWrite.WriteLine(SaveMap.SaveMap(i))
                srFileWrite.WriteLine(SaveMap.SaveMap2(i))
                srFileWrite.WriteLine(SaveMap.SaveMap3(i))
                srFileWrite.WriteLine(SaveMap.SaveMap4(i))
            Next
        Next
        srFileWrite.Close()
        MsgBox(strChrName & " - Game Saved")

    End Sub
    Public Sub Debug()
        Dim sFileName As String
        Dim sOut As String
        Dim sOut2 As String
        Dim i As Integer
        'SAVE_MapLoaded = MapLoaded
        Dim value As String = My.Application.Info.DirectoryPath
        sFileName = value & "\debug.txt"
        Dim j As Integer
        Dim srFileWrite As New System.IO.StreamWriter(sFileName)


        For Each cTile In nTiles
            sOut = cTile.TileName & " " & cTile.TileLet
            srFileWrite.WriteLine(sOut)
        Next

        srFileWrite.Close()
        ' MsgBox(strChrName & " - Game Saved")

    End Sub
    Public Sub LoadGame()
        Dim srFileReader As System.IO.StreamReader
        Dim bMapSaved As Boolean
        Dim cFile As String
        Dim sTag As String
        Dim sTagn As String
        Dim i As Integer
        Dim j As Integer
        Dim jMaps As Integer
        Dim sIn As String
        Dim sIn2 As String
        Dim pokoL As Integer
        Dim pokoV As Integer
        Dim pokoW As Integer
        Dim pokoN As String
        Dim pokoS As String
        iBadgecnt = 0
        cFile = My.Application.Info.DirectoryPath & "\" & strChrName & ".qst"
        'sOut = Format(Pokeballs, "000") & Format(iBunnyCaught, "000") & Format(SAVE_Life, "000") & Format(SAVE_Candle, "000") & Format(Ticket, "000")
        ' sOut = sOut & Format(Wood, "000") & Format(Magic, "000") & Format(Toast, "000") & Format(Coin, "000") & Format(Bomb, "000")
        ' sOut = sOut & Format(CharX, "000") & Format(CharY, "000") & Format(CharFacing, "000")
        '
        srFileReader = System.IO.File.OpenText(cFile)
        cMapFile = srFileReader.ReadLine()  '1
        sOldMapFile = cMapFile
        '
        '
        '
        'sOut = Format(Pokeballs, "000") & Format(iBunnyCaught, "000") & Format(SAVE_Life, "000") & Format(SAVE_Candle, "000") & Format(Ticket, "000")
        'srFileWrite.WriteLine(sOut)
        'sOut = Format(Wood, "000") & Format(Magic, "000") & Format(Toast, "000") & Format(Coin, "000") & Format(Bomb, "000")
        'srFileWrite.WriteLine(sOut)
        'sOut = Format(CharX, "000") & Format(CharY, "000") & Format(CharFacing, "000")
        'srFileWrite.WriteLine(sOut)
        '
        sIn = srFileReader.ReadLine()       '2
        Pokeballs = Val(Mid(sIn, 1, 3))
        iBunnyCaught = Val(Mid(sIn, 4, 3))
        SAVE_Life = Val(Mid(sIn, 7, 3))
        SAVE_Candle = Val(Mid(sIn, 10, 3))
        Ticket = Val(Mid(sIn, 13, 3))
        '
        sIn = srFileReader.ReadLine()       '2
        Wood = Val(Mid(sIn, 1, 3))
        Magic = Val(Mid(sIn, 4, 3))
        Toast = Val(Mid(sIn, 7, 3))
        Coin = Val(Mid(sIn, 10, 3))
        Bomb = Val(Mid(sIn, 13, 3))
        '
        sIn = srFileReader.ReadLine()
        CharX = Val(Mid(sIn, 1, 3))
        CharY = Val(Mid(sIn, 4, 3))
        CharFacing = Val(Mid(sIn, 7, 3))
        SpellCut = False
        SpellDestroy = False
        SpellFill = False
        SpellLight = False
        SpellAxe = False
        SpellGrow = False
        'sOut2 = Mid(SpellAxe, 1, 1) & Mid(SpellCut, 1, 1) & Mid(SpellDestroy, 1, 1) & Mid(SpellFill, 1, 1) & Mid(SpellGrow, 1, 1) & Mid(SpellLight, 1, 1)
        sIn2 = srFileReader.ReadLine()       '3
        sInventory = srFileReader.ReadLine()  '4
        j = InStr(1, UCase(sInventory), "CANDLE")
        If j > 0 And SAVE_Candle = 0 Then SAVE_Candle = 4
        If Mid(sIn2, 1, 1) = "T" Then SpellAxe = True
        If Mid(sIn2, 2, 1) = "T" Then SpellCut = True
        If Mid(sIn2, 3, 1) = "T" Then SpellDestroy = True
        If Mid(sIn2, 4, 1) = "T" Then SpellFill = True
        If Mid(sIn2, 5, 1) = "T" Then SpellGrow = True
        If Mid(sIn2, 6, 1) = "T" Then SpellLight = True
        For i = 1 To 90
            Mquest(i) = srFileReader.ReadLine()
            MquestName(i) = srFileReader.ReadLine()
            sBadge(i) = srFileReader.ReadLine()
            If sBadge(i) <> "" Then iBadgecnt = iBadgecnt + 1
        Next
        sTagn = sBadge(1)
        nPoko = New Collection
        For i = 1 To 50
            poko = New ClsPoko
            pokoN = srFileReader.ReadLine()
            poko.Name = pokoN
            If poko.Name = "END" Then GoTo ReadMap
            pokoL = srFileReader.ReadLine()
            poko.Level = pokoL
            pokoS = srFileReader.ReadLine()
            poko.Status = pokoS
            pokoV = srFileReader.ReadLine()
            poko.Value = pokoV
            pokoW = srFileReader.ReadLine()
            poko.Wins = pokoW
            poko.Max = poko.Level * 7
            nPoko.Add(poko)
        Next
ReadMap:
        nSaveMap = New Collection
        'sOut = Format(iMapReadIn, "000")
        iMapReadIn = srFileReader.ReadLine()
        For jMaps = 1 To iMapReadIn
            SaveMap = New ClsSaveMap
            SaveMap.Clear()
            sTag = srFileReader.ReadLine()
            SaveMap.ChestItem = sTag
            sTag = srFileReader.ReadLine()
            SaveMap.StoreItem = sTag
            sTag = srFileReader.ReadLine()
            SaveMap.Name = sTag
            If SaveMap.Name = cMapFile Then
                sStoreOld = SaveMap.StoreItem
                sChestOld = SaveMap.ChestItem
            End If
            'Input #1, j
            j = Val(srFileReader.ReadLine())
            For i = 1 To j
                sTag = srFileReader.ReadLine()
                SaveMap.SaveMap(i) = sTag
                sTag = srFileReader.ReadLine()
                SaveMap.SaveMap2(i) = sTag
                sTag = srFileReader.ReadLine()
                SaveMap.SaveMap3(i) = sTag
                sTag = srFileReader.ReadLine()
                SaveMap.SaveMap4(i) = sTag
                If SaveMap.Name = cMapFile Then
                    Map(i) = SaveMap.SaveMap(i)
                    Map2(i) = SaveMap.SaveMap2(i)
                    Map3(i) = SaveMap.SaveMap3(i)
                    Map4(i) = SaveMap.SaveMap4(i)
                End If

            Next
            i = SaveMap.Count
            nSaveMap.Add(SaveMap)
        Next
        srFileReader.Close()
        iChestX = Val(Mid(sChestOld, 1, 2))
        iChestY = Val(Mid(sChestOld, 2, 2))
        sChestItems = ""
        If Len(sChestOld) > 5 Then sChestItems = Mid(sChestOld, 5, Len(sChestOld) - 4)
        MsgBox(strChrName & " - Game Loaded")
        ' sTag = srFileReader.ReadLine()
        'If SpellLight Then LblLight.BackColor = LblGreen.BackColor
        'If SpellDestroy Then FrmMake3.LblDestroy.BackColor = FrmMake3.LblGreen.BackColor
        'If SpellAxe Then FrmMake3.LblAxe.BackColor = FrmMake3.LblGreen.BackColor
        'If SpellCut Then FrmMake3.LblCut.BackColor = FrmMake3.LblGreen.BackColor
        'If SpellFill Then FrmMake3.LblFill.BackColor = FrmMake3.LblGreen.BackColor
        'If SpellGrow Then FrmMake3.LblGrow.BackColor = FrmMake3.LblGreen.BackColor
        'If Spell1 Then FrmMake3.Lbl1.BackColor = FrmMake3.LblGreen.BackColor
        bMapSaved = True
    End Sub
    Public Sub DarkMapFile(ByVal cMapfile As String)
        Dim i As Integer
        Dim MYFILE As String
        Dim strMap As String
        Dim srFileReader As System.IO.StreamReader

        MYFILE = My.Application.Info.DirectoryPath & "\Maps\" & cMapfile & ".1ap"
        i = 0
        srFileReader = System.IO.File.OpenText(MYFILE)
        strMap = srFileReader.ReadLine()
        Do While (Not strMap Is Nothing)
            If Len(strMap) > 5 Then
                DarkMap(i) = Trim(strMap)
                strMap = srFileReader.ReadLine()
                DarkMap2(i) = Trim(strMap)
            End If
            i = i + 1
            strMap = srFileReader.ReadLine()
        Loop
        srFileReader.Close()
        'Open MYFILE For Input As #1
        '     Do While Not EOF(1) ' Loop until end of file.
        '      Line Input #1, strMap
        '         If Len(strMap) > 5 Then
        '             DarkMap(i) = Trim(strMap)
        '         Line Input #1, strMap
        '             DarkMap2(i) = Trim(strMap)
        '         End If
        '         i = i + 1
        '     Loop

    End Sub
End Module

